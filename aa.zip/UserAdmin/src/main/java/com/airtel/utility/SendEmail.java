package main.java.com.airtel.utility;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail {

	public static void main(String[] args) {

		String to = "portal.development@airtel.com";

		String from = "B0097268";

		Properties properties = System.getProperties();

		properties.setProperty("mail.smtp.host", from);
		properties.put("mail.transport.protocol", "smtp");
		properties.put("mail.smtp.host", "syslogl1.bharti.com");
		properties.put("mail.smtp.port", "25");
		properties.put("mail.smtp.auth", "false");
		Authenticator authenticator = new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(
						"portal.development@airtel.com", "i3{^t{~N");
			}
		};

		// Session session = Session.getDefaultInstance(properties,
		// authenticator);
		Session session = Session.getDefaultInstance(properties);
		System.out.println(session);

		try {

			MimeMessage message = new MimeMessage(session);
			System.out.println(message);

			message.setFrom(new InternetAddress(from));

			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));

			message.setSubject("This is the Subject Line!");

			message.setText("This is testing message");

			Transport.send(message);
			System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}

	public static boolean sendMail(String to, String msg,String from) {
		Properties properties = System.getProperties();

		properties.setProperty("mail.smtp.host", from);
		properties.put("mail.transport.protocol", "smtp");
		properties.put("mail.smtp.host", "172.30.1.7");
		properties.put("mail.smtp.port", "25");
		properties.put("mail.smtp.auth", "false");
		Session session = Session.getDefaultInstance(properties);
		try {

			MimeMessage message = new MimeMessage(session);
			System.out.println(message);

			message.setFrom(new InternetAddress(from));
		

			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));

			message.setSubject("User Admin Portal Request");

		//	message.setText(msg);
			message.setContent(msg, "text/html");
			

			Transport.send(message);
			System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
		return true;
	}
}