package main.java.com.airtel.utility;

public class StringUtility {
	static String str;

	static public String getString(String[] s) {
		StringBuilder builder = new StringBuilder();
		if (s == null)
			return null;
		else {
			for (String str : s) {
				builder.append(str).append(",");
			}
			return builder.substring(0, builder.length() - 1).toString();
		}
	}

	static public String checkNUll(String str) {
		System.out.println("inside check");
		if (str == null) {
			System.out.println("inside if block");
			System.out.println("inside if block ends");
			return str;
		} else {
			System.out.println("inside else block");
			return str;
		}

	}
	static public String getStringForNotNull(String[] s) {
		StringBuilder builder = new StringBuilder();
		if (s == null)
			return " ";
		else {
			for (String str : s) {
				builder.append(str).append(",");
			}
			return builder.substring(0, builder.length() - 1).toString();
		}
	}
	static public String checkNUllForNms(String str) {
		System.out.println("inside check");
		if (str == null) {
			return str;
		} else {
			System.out.println("inside else block");
			return " ,"+str;
		}

	}
	static public String checkNUllForSpace(String str) {
		
		if (str == null) {
		
			return "";
		} else {
			return str+" ,";
		}

	}
	static public String[] getArrayString(String s)
	{
		StringBuilder builder = new StringBuilder();
		if (s == null)
			return " ".split(",");
	
	else {
		for (String str : s.split(",")) {
			builder.append(" "+str).append(" /").append("");
		}
		return builder.substring(0, builder.length() - 1).split(",");
	}

}
	
}
