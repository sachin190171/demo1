package main.java.com.airtel.utility;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DataConnection {

	DataSource dataSource;

	public DataConnection() {
		// try {
		// Context initContext = new InitialContext();
		// Context envContext = (Context) initContext.lookup("java:/comp/env");
		// dataSource = (DataSource) envContext.lookup("jdbc/airteldb");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

	}

	static public DataConnection getDataConnectionObject() {
		return new DataConnection();
	}

	public Connection getConnection() {
		Connection con = null;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/airteldb", "root", "mysql");
			// con = dataSource.getConnection();
			System.out.println(con);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public void closeConnection() {
		try {
			System.out.println("data closemethod is empty");
			// if (con != null)
			// con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
