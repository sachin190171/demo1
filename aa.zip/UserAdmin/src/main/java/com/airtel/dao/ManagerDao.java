package main.java.com.airtel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import main.java.com.airtel.model.Manager;
import main.java.com.airtel.utility.DataConnection;
import main.java.com.airtel.utility.PasswordEncDe;

public class ManagerDao implements IManagerDao {
	//Connection con;
	Statement st;
	ResultSet rs;
	PreparedStatement psmt;
	boolean b;
	Manager manager = new Manager();
	DataConnection data = new DataConnection();

	public boolean addManager(Manager man) {
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "INSERT INTO manager"
					+ "(olm_id, mgr_fname, mgr_lname,mgr_fullname, email_id, department, password, admin_status, isDeleted"
					+ ") VALUES" + "(?,?,?,?,?,?,?,?,?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, man.getOlmId());
			psmt.setString(2, man.getFirstName());
			psmt.setString(3, man.getLastName());
			psmt.setString(4, man.getFullName());
			psmt.setString(5, man.getEmailId());
			psmt.setString(6, man.getDepartment());
			psmt.setString(7, man.getPassword());
			psmt.setInt(8, 0);
			psmt.setInt(9, 0);
			psmt.executeUpdate();
			String sql = "INSERT INTO users"
					+ "(uuid, olm_id, password, rm_status, role, isDeleted )values(?,?,?,?,?,?)";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, man.getFirstName() + man.getOlmId());
			psmt.setString(2, man.getOlmId());
			psmt.setString(3, man.getPassword());
			psmt.setInt(4, 0);
			psmt.setInt(5, 0);
			psmt.setInt(6, 0);
			psmt.executeUpdate();
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		}

	}

	public boolean checkId(String id) {
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from manager where olm_id  = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			System.out.println(rs);
			b = rs.next();
			System.out.println(b);
			if (b == true)
				return false;
			else
				return true;

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		}

	}

	public Manager getMamagerDetails(String id) {
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from manager where olm_id  = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			while (rs.next()) {
				manager.setFirstName(rs.getString("mgr_fname"));
				manager.setLastName(rs.getString("mgr_lname"));
				manager.setOlmId(rs.getString("olm_id"));
				manager.setEmailId(rs.getString("email_id"));
				manager.setDepartment(rs.getString("department"));
				manager.setFullName(rs.getString("mgr_fullname"));
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		}
		return manager;
	}

	public List<Manager> getAllManagerList(int status) {
		Connection con = null;
		List<Manager> list = new LinkedList<Manager>();
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from users where rm_status  = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {

				String olm = rs.getString("olm_id");
				String sql = "select * from manager where olm_id  = ?";
				psmt = con.prepareStatement(sql);
				psmt.setString(1, olm);
				ResultSet rs1 = psmt.executeQuery();
				while (rs1.next()) {
					Manager manag = new Manager();
					manag.setOlmId(rs.getString("olm_id"));
					manag.setFirstName(rs1.getString("mgr_fname"));
					manag.setLastName(rs1.getString("mgr_lname"));
					manag.setFullName(rs1.getString("mgr_fullname"));
					manag.setOlmId(rs1.getString("olm_id"));
					manag.setDepartment(rs1.getString("department"));
					manag.setEmailId(rs1.getString("email_id"));
					list.add(manag);
					manag = null;
				}

			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		}

		return list;
	}

	public boolean activeManager(String status, String olm) {
		Connection con = null;
		try {

			con = data.getConnection();
			int i;
			if (status.equals("pending")) {
				i = 4;
			} else
				i = 1;
			con.setAutoCommit(false);
			String query = "update manager set admin_status = ? where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			psmt.setString(2, olm);
			psmt.executeUpdate();
			System.out.println("status update in manager tabel");
			String sql = "update users set rm_status= ? where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, i);
			psmt.setString(2, olm);
			psmt.executeUpdate();
			con.commit();
			System.out.println("status update in user table");

			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		}

	}

	public boolean mgrPwdChange(String olm, String oldPwd, String newPwd) {
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update users set password = ? where olm_id = ? && password= ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, PasswordEncDe.EncryptText(newPwd));
			psmt.setString(2, olm);
			psmt.setString(3, PasswordEncDe.EncryptText(oldPwd));
			int i = psmt.executeUpdate();
			System.out.println(i);
			con.commit();
			System.out.println("password change in users table sucessfully");
			if (i == 1)
				return true;
			else
				return false;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		}

	}
	public int addMgrForEnteredAlready(String id) {

		Connection con = null;
		int status = 13;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from manager where olm_id  = ?  ";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			while (rs.next()) {
				status = rs.getInt("admin_status");
			}
			System.out.println(status);

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		}

		return status;
	}

	public boolean addManagerForRejected(Manager man, String olm) {
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);

			String delQuery = "delete from users where olm_id = ?";
			psmt = con.prepareStatement(delQuery);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			System.out.println("user delete from user tabel");

			String delQueryFromMan = "delete from manager where olm_id = ?";
			psmt = con.prepareStatement(delQueryFromMan);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			System.out.println("user delete from manager tabel");
			System.out.println("Now again rejected record insert ");

			String query = "INSERT INTO manager"
					+ "(olm_id, mgr_fname, mgr_lname,mgr_fullname, email_id, department, password, admin_status, isDeleted"
					+ ") VALUES" + "(?,?,?,?,?,?,?,?,?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, man.getOlmId());
			psmt.setString(2, man.getFirstName());
			psmt.setString(3, man.getLastName());
			psmt.setString(4, man.getFullName());
			psmt.setString(5, man.getEmailId());
			psmt.setString(6, man.getDepartment());
			psmt.setString(7, man.getPassword());
			psmt.setInt(8, 0);
			psmt.setInt(9, 0);
			psmt.executeUpdate();
			String sql = "INSERT INTO users"
					+ "(uuid, olm_id, password, rm_status, role, isDeleted )values(?,?,?,?,?,?)";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, man.getFirstName() + man.getOlmId());
			psmt.setString(2, man.getOlmId());
			psmt.setString(3, man.getPassword());
			psmt.setInt(4, 0);
			psmt.setInt(5, 0);
			psmt.setInt(6, 0);
			psmt.executeUpdate();
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		}

	}
	
}