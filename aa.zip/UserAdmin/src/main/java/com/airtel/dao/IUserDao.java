package main.java.com.airtel.dao;
import java.util.List;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.model.User;

public interface IUserDao {

	public boolean submit(NewUser user);
	public boolean add(NewUser user);
	public boolean addInModification(NewUser user);
	public boolean addInPassword(NewUser user,String uuid);
	public User validUser(String userName, String Pwd);
	public User validManager(String userName, String Pwd);
	public boolean validateId(String oid);
	public boolean validateIdForModification(String oid);
	public boolean validateIdForUserDelete(String oid);
	public boolean validateIdForUserPassword(String oid);
	public List<NewUser> getAllUserList(int status,String id);
	public List<MplsUser> getMplsUserList(int status,String id);

	public List<NewUser> getAllUserListFromPassword(String  olm,int mstatus);
	public List<MplsUser> getMplsUserListFromPassword(String  olm,int mstatus);

	public List<NewUser> getAllUserListFromPasswordForSys(int  mst,int mstatus);
	public List<NewUser> getAllUserListFromDeleted(int status,String id);
	public List<MplsUser> getMplsUserListFromDeleted(int status,String id);

	public List<NewUser> getAllUserListFromModified(int status,String id);
	public List<MplsUser> getMplsUserListFromModified(int status,String id);

	public List<NewUser> getAllUserListFromDeletedForSystem(int mstatus,int hstatus,int dst);
	public List<NewUser> getAllUserListForAdmin(int status,int mgrStatus);
	public List<NewUser> getModifiedUserListForAdmin(int status,int mgrStatus);
	public List<NewUser> getAllMisData(String reason,String from ,String to);
	public List<NewUser> getAllMisData(String from ,String to);
	public List<NewUser> getAllMisDataForPwd(String from ,String to);
	public void deleteAndEnter(NewUser user,String olm);
	public NewUser getNewUser(String id);
	public MplsUser getNewMplsUser(String id);

	public boolean validateIdForIdStatus(String oid);
	public NewUser getNewUserForModification(String id);
	public NewUser getNewUserForPasswordReset(String id);	
	public NewUser getNewUserForPasswordResetByManager(String id);
	public NewUser getNewUserForDelete(String id);
	public boolean activeUserByManager(String status,String olm);
	public boolean deleteUserByManager(String status,String olm);
	public boolean modifiedUserByManager(String status,String olm);
	public boolean activeUserByAdmin(String status,String olm,String name);
	public boolean activeModifiedUserByAdmin(String status,String olm,String name);
	public boolean activeUserBySystem(String hstatus,String olm,String name,String nms,String rticket);
	public boolean changePassword(String hstatus,String olm,String name,int mgrst,String nms,String rticket,String password);
	public boolean changePasswordByManager(String hstatus,String olm,String uuid);
	public boolean modifiedUserBySystem(String hstatus,String olm,String name,String nms,String rticket,String uuid);
	public boolean DeletedUserBySystem(String hstatus,String olm,String name,String nms,String rticket);
	public List<NewUser> getAllUserListForSystem(int mgrStatus,int adStatus,int heStatus);
	public List<NewUser> getModifiedUserListForSystem(int mgrStatus,int adStatus,int heStatus);
	
	public boolean submitTacCreReq(TacUser user);
	
	public boolean submitMplsCreReq(MplsUser user);

	public boolean checkTacUserOlmID(String olm);

	public boolean checkMplsUserOlmID(String olm);

	
	public boolean submitTacModifiedReq(TacUser user);

	public boolean submitTacdeleteReq(TacUser user);

	public List<TacUser> getAllTacCrateUser(int st, String id);

	public List<TacUser> getAllTacModification(int st, String id);
	public List<MplsUser> getAllMplsModification(int st, String id);

	public List<TacUser> getAllTacDeletion(int st, String id);
	public List<MplsUser> getAllMplsDeletion(int st, String id);

	public List<TacUser> getAllTacCrateUserForHOD(int st, String id, int hst,
			String table);
	
	public List<MplsUser> getAllMplsCrateUserForHOD(int st, String id, int hst,
			String table);
	
	public List<MplsUser> getAllMplsCreateUser(int st, String id);

	public List<MplsUser> getAllMplsCreateHODUser(int st, String id);


	public List<TacUser> getAllTacCrateUserForSystem(int st, int hst, int sst);

	public List<MplsUser> getAllMplsCrateUserForSystem(int st, int hst, int sst);

	public List<TacUser> getAllTacModificationSystem(int st, int hst, int sst);

	public List<MplsUser> getAllMplsModificationSystem(int st, int hst, int sst);

	public List<TacUser> getAllTacDeletionSystem(int st, int sst);

	public List<MplsUser> getAllMplsDeletionSystem(int st, int sst);

	public List<TacUser> getAllTacPwdSystem(int mst, int sst);

	public List<MplsUser> getAllMplsPwdSystem(int mst, int sst);

	public TacUser getUser(String olm, String table);

	public MplsUser getMplsUser(String olm, String table);

	public boolean updateTacUserForManager(String status, String olm,
			String mgrname, String rights, String table);

	public boolean updateMplsUserForManager(String status, String olm,
			String mgrname, String rights, String table);

	public boolean updateTacUserForHOD(String status, String olm,
			String mgrname, String table);

	public boolean updateMplsUserForHOD(String status, String olm,
			String mgrname, String table);

	public boolean updateTacUserForSystem(String status, String olm,
			String sysname, String ticket, String pwd);

	public boolean updateMplsUserForSystem(String status, String olm,
			String sysname, String ticket, String pwd);

	public boolean updateTacUserModForSystem(String status, String olm,
			String sysname, String ticket, String pwd);

	public boolean updateMplsUserModForSystem(String status, String olm,
			String sysname, String ticket, String pwd);


	public boolean updateTacUserDelForSystem(String status, String olm,
			String sysname, String ticket);

	public boolean updateMplsUserDelForSystem(String status, String olm,
			String sysname, String ticket);

	public TacUser getUserForTacDeletion(String olm);

	public MplsUser getUserForMplsDeletion(String olm);

	public boolean updateTacUserDelForManager(int status, String olm);
	public boolean updateMplsUserDelForManager(int status, String olm);

	public boolean enterTacPwdreset(String uid, TacUser user);

	public List<TacUser> getAllTacPwdReset(int status, String id);

	public List<MplsUser> getAllMplsPwdReset(int status, String id);

	public TacUser getTacPwdReset(String id);

	public MplsUser getMplsPwdReset(String id);

	public boolean approvalTacPwdResetmgr(String uid, int status, String olm);

	public boolean approvalMplsPwdResetmgr(String uid, int status, String olm);

	public boolean updateTacUserPwdResetSystem(String status, String olm,
			String name, String ticket, String pwd);

	public boolean updateMplsUserPwdResetSystem(String status, String olm,
			String name, String ticket, String pwd);

	public boolean checkUidForTacSystem(String uid);

	public boolean checkForTacDelSystem(String uid);

	public boolean checkForTacCreationSystem(String olm);

	public boolean checkForMplsCreationSystem(String olm);

	
	public boolean checkIdForTacCreationSystem(String olm);

	public boolean checkIdForMplsCreationSystem(String olm);

	public boolean addAndDeleteForTacModSystem(String olm);

	public boolean checkForTacModSystem(String olm);

	public boolean checkIdForTacModificationSystem(String olm);

	public boolean checkIdForMplsModificationSystem(String olm);

	public boolean checkIdForTaDeletionSystem(String olm);

	public boolean checkIdForMplsDeletionSystem(String olm);

	public String findMgrEmailId(String dept, String mgr);
////////////////////////////////////////////////////////////////////////////////////////
	public boolean checkForMplsModSystem(String olm);
	public boolean addAndDeleteForMplsModSystem(String olm);
	public boolean submitMplsdeleteReq(MplsUser user);

	public boolean submitMplsModifiedReq(MplsUser user);
	public boolean checkForMplsDelSystem(String uid);
	public boolean checkUidForMplsSystem(String uid);
	public boolean enterMplsPwdreset(String uid, MplsUser user);

	////////////////////////////////////////////////////////////////////////////////////

}
