package main.java.com.airtel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.model.User;
import main.java.com.airtel.utility.DataConnection;
import main.java.com.airtel.utility.PasswordEncDe;
import main.java.com.airtel.utility.SendEmail;
import main.java.com.airtel.utility.StringUtility;

public class UserDao implements IUserDao {

	// Connection con = null;
	Statement st;
	ResultSet rs;
	PreparedStatement psmt;
	static String str;
	String mgr_id = null;
	String mgr_nam = null;
	// NewUser user = new NewUser();
	DataConnection data = new DataConnection();
	Calendar cal = Calendar.getInstance();

	public boolean submit(NewUser user) {
		String mgr_olmid;
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			str = StringUtility.getString(user.getApplicationAccess());
			str = StringUtility.checkNUll(str);
			mgr_olmid = getManagerId(user.getManager(), user.getState());
			System.out.println(mgr_olmid);
			String query = "INSERT INTO newuser"
					+ "(uuid, first_name, last_name, street_name, state, manager, requestfor, ustype, user_id, email_id, c_number, u_belongs, ut_name, vd_details, reason, "
					+ "designation, purpose, app_access, eci, alcatel, huawei, ciena, nortel, tejas, adr, mgr_id, userolm_id, mgr_status, admin_status, os, date,ref_id"
					+ ") VALUES"
					+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getUuid());
			psmt.setString(2, user.getFirst_name());
			psmt.setString(3, user.getLast_name());
			psmt.setString(4, user.getStreet_name());
			psmt.setString(5, user.getState());
			psmt.setString(6, user.getManager());
			psmt.setString(7, user.getRequestfor());
			psmt.setString(8, user.getUstype());
			psmt.setString(9, user.getOlm_id());
			psmt.setString(10, user.getEmail_id());
			psmt.setString(11, user.getC_number());
			psmt.setString(12, user.getU_belongs());
			psmt.setString(13, user.getUt_name());
			psmt.setString(14, user.getVd_details());
			psmt.setString(15, user.getReason());
			psmt.setString(16, user.getDesignation());
			psmt.setString(17, user.getPurpose());
			psmt.setString(18, StringUtility.checkNUll(StringUtility
					.getString(user.getApplicationAccess())));
			psmt.setString(19, StringUtility.checkNUll(StringUtility
					.getString(user.getEci())));
			psmt.setString(20, StringUtility.checkNUll(StringUtility
					.getString(user.getAlcatel())));
			psmt.setString(21, StringUtility.checkNUll(StringUtility
					.getString(user.getHuawei())));
			psmt.setString(22, StringUtility.checkNUll(StringUtility
					.getString(user.getCiena())));
			psmt.setString(23, StringUtility.checkNUll(StringUtility
					.getString(user.getNortel())));
			psmt.setString(24, StringUtility.checkNUll(StringUtility
					.getString(user.getTejas())));
			psmt.setString(25, StringUtility.checkNUll(StringUtility
					.getString(user.getAdr())));
			psmt.setString(26, mgr_olmid);
			psmt.setString(27, user.getOlm_id());
			psmt.setInt(28, 0);
			psmt.setInt(29, 0);
			psmt.setString(30, user.getOs());
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(31, timestamp);
			psmt.setString(32, user.getRef_id());
			psmt.executeUpdate();
			con.commit();

			System.out.println("inside user entry block");
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	public boolean add(NewUser user) {
		String mgr_olmid;
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			mgr_olmid = getManagerId(user.getManager(), user.getState());
			System.out.println(mgr_olmid);
			String query = "INSERT INTO deleteduser"
					+ "(olm_id, fname, lname, location, e_mail, number, sec_company, designation, request_for, type, belongs, purpose, department, manager_name, mgr_olm_id, "
					+ "vendor_name, vendor_type, mgr_status, helpdesk_status,date"
					+ ") VALUES" + "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, user.getFirst_name());
			psmt.setString(3, user.getLast_name());
			psmt.setString(4, user.getStreet_name());
			psmt.setString(5, user.getEmail_id());
			psmt.setString(6, user.getC_number());
			psmt.setString(7, user.getUt_name());
			psmt.setString(8, user.getDesignation());
			psmt.setString(9, user.getRequestfor());
			psmt.setString(10, user.getUstype());
			psmt.setString(11, user.getU_belongs());
			psmt.setString(12, user.getPurpose());
			psmt.setString(13, user.getState());
			psmt.setString(14, user.getManager());
			psmt.setString(15, mgr_olmid);
			psmt.setString(16, user.getVd_details());
			psmt.setString(17, user.getVendor());
			psmt.setInt(18, 0);
			psmt.setInt(19, 0);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(20, timestamp);
			psmt.executeUpdate();
			con.commit();
			data.closeConnection();
			System.out.println("inside user entry block");
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	public boolean addInModification(NewUser user) {
		String mgr_olmid;
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			str = StringUtility.getString(user.getApplicationAccess());
			str = StringUtility.checkNUll(str);
			System.out.println("hello");
			System.out.println(str);
			System.out.println("hello world");
			mgr_olmid = getManagerId(user.getManager(), user.getState());
			System.out.println(mgr_olmid);
			String query = "INSERT INTO modifieduser"
					+ "(uuid, first_name, last_name, street_name, state, manager, requestfor, ustype, user_id, email_id, c_number, u_belongs, ut_name, vd_details, reason, "
					+ "designation, purpose, app_access, eci, alcatel, huawei, ciena, nortel, tejas, adr, mgr_id, userolm_id, mgr_status, admin_status, os, date,ref_id"
					+ ") VALUES"
					+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getUuid());
			psmt.setString(2, user.getFirst_name());
			psmt.setString(3, user.getLast_name());
			psmt.setString(4, user.getStreet_name());
			psmt.setString(5, user.getState());
			psmt.setString(6, user.getManager());
			psmt.setString(7, user.getRequestfor());
			psmt.setString(8, user.getUstype());
			psmt.setString(9, user.getOlm_id());
			psmt.setString(10, user.getEmail_id());
			psmt.setString(11, user.getC_number());
			psmt.setString(12, user.getU_belongs());
			psmt.setString(13, user.getUt_name());
			psmt.setString(14, user.getVd_details());
			psmt.setString(15, user.getReason());
			psmt.setString(16, user.getDesignation());
			psmt.setString(17, user.getPurpose());
			psmt.setString(18, StringUtility.checkNUll(StringUtility
					.getString(user.getApplicationAccess())));
			psmt.setString(19, StringUtility.checkNUll(StringUtility
					.getString(user.getEci())));
			psmt.setString(20, StringUtility.checkNUll(StringUtility
					.getString(user.getAlcatel())));
			psmt.setString(21, StringUtility.checkNUll(StringUtility
					.getString(user.getHuawei())));
			psmt.setString(22, StringUtility.checkNUll(StringUtility
					.getString(user.getCiena())));
			psmt.setString(23, StringUtility.checkNUll(StringUtility
					.getString(user.getNortel())));
			psmt.setString(24, StringUtility.checkNUll(StringUtility
					.getString(user.getTejas())));
			psmt.setString(25, StringUtility.checkNUll(StringUtility
					.getString(user.getAdr())));
			psmt.setString(26, mgr_olmid);
			System.out.println("while check value");
			psmt.setString(27, user.getOlm_id());
			psmt.setInt(28, 0);
			psmt.setInt(29, 0);
			psmt.setString(30, user.getOs());
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(31, timestamp);
			psmt.setString(32, user.getRef_id());
			psmt.executeUpdate();
			con.commit();
			System.out.println("inside user entry block");
			data.closeConnection();

		} catch (Exception e) {
			try {
				con.rollback();
				return false;
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	public void deleteAndEnter(NewUser user, String olm) {
		Connection con = null;
		String sql1 = "insert into premodifieduser (select * from modifieduser where userolm_id = ?)";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql1);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			System.out.println("insert into premodified table");
			con.commit();
			con.close();
			Connection conn = data.getConnection();
			conn.setAutoCommit(false);
			String Sql = "delete from modifieduser where userolm_id = ?";
			psmt = conn.prepareStatement(Sql);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			conn.commit();
			System.out.println("now new modified record insertion");
			addInModification(user);

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean addInPassword(NewUser user, String uuid) {
		Connection con = null;

		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String mgr_id = getManagerId(user.getManager(), user.getState());
			String query = "INSERT INTO password"
					+ "(olm_id, app_access, eci, alcatel, huawei, ciena, nortel, tejas, adr,mgr_olm_id,department,uuid,date,nms_id,pwd_reset_nms,email"
					+ ") VALUES" + "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, StringUtility.checkNUll(StringUtility
					.getString(user.getApplicationAccess())));
			psmt.setString(3, StringUtility.checkNUll(StringUtility
					.getString(user.getEci())));
			psmt.setString(4, StringUtility.checkNUll(StringUtility
					.getString(user.getAlcatel())));
			psmt.setString(5, StringUtility.checkNUll(StringUtility
					.getString(user.getHuawei())));
			psmt.setString(6, StringUtility.checkNUll(StringUtility
					.getString(user.getCiena())));
			psmt.setString(7, StringUtility.checkNUll(StringUtility
					.getString(user.getNortel())));
			psmt.setString(8, StringUtility.checkNUll(StringUtility
					.getString(user.getTejas())));
			psmt.setString(9, StringUtility.checkNUll(StringUtility
					.getString(user.getAdr())));
			psmt.setString(10, mgr_id);
			psmt.setString(11, user.getState());
			psmt.setString(12, uuid);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(13, timestamp);
			psmt.setString(14, user.getNms_id());
			psmt.setString(15, user.getNms());
			psmt.setString(16, user.getEmail_id());
			psmt.executeUpdate();
			con.commit();
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	public User validUser(String userName, String pwd) {
		User user = new User();
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			st = con.createStatement();
			String sql = "SELECT * FROM userroles WHERE username = " + " '"
					+ userName + "' " + " && password =" + pwd;
			rs = st.executeQuery(sql);

			while (rs.next()) {
				// user.setRole(rs.getString("role"));
				user.setUserName(rs.getString("username"));
				user.setPassword(rs.getString("password"));

			}
			con.commit();
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	public String getManagerId(String name, String depart) {
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "select * from manager where mgr_fullname = ? && department like ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, name);
			psmt.setString(2, "%"+depart+"%");
			rs = psmt.executeQuery();

			while (rs.next()) {
				mgr_id = rs.getString("olm_id");

			}
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return mgr_id;
	}

	public User validManager(String userName, String pwd) {
		Connection con = null;
		User user = new User();
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "SELECT * FROM users WHERE olm_id = ? && password = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, userName);
			psmt.setString(2, PasswordEncDe.EncryptText(pwd));

			rs = psmt.executeQuery();

			while (rs.next()) {
				user.setRm_status(rs.getInt("rm_status"));
				user.setUserName(rs.getString("olm_id"));
				System.out.println(PasswordEncDe.DecryptText(rs
						.getString("password")));
				user.setPassword(PasswordEncDe.DecryptText(rs
						.getString("password")));
				user.setRole(rs.getInt("role"));

			}
			con.commit();
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	public boolean validateId(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from newuser where userolm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("userolm_id");
			}
			if (olm.equals(oid)) {
				System.out.println("if block when olm found");
				String olmid = " ";
				String query = "select * from newuser where userolm_id = ? &&(mgr_status = 2||admin_status = 2 || helpdesk_status=2)";
				psmt = con.prepareStatement(query);
				psmt.setString(1, oid);
				rs = psmt.executeQuery();
				while (rs.next()) {

					olmid = rs.getString("userolm_id");
				}
				if (oid.equals(olmid)) {
					System.out.println("olm found but pending ");
					String query1 = "delete  from newuser where userolm_id = ?";
					psmt = con.prepareStatement(query1);
					psmt.setString(1, oid);
					psmt.executeUpdate();
					con.commit();
					return false;

				} else {
					System.out
							.println("Inside else block when olmid already present");
					return true;
				}
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	public boolean validateIdForModification(String oid) {
		String olm = " ";
		Connection con = null;
		try {
			System.out.println("inside try block");
			con = data.getConnection();
			System.out.println(con);
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from modifieduser where userolm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();

			while (rs.next()) {

				olm = rs.getString("userolm_id");
			}
			if (olm.equals(oid))
				return true;
			else
				return false;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	public boolean validateIdForUserDelete(String oid) {
		String olm = " ";
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "select * from deleteduser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid))
				return true;
			else
				return false;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	public boolean validateIdForUserPassword(String oid) {
		String olm = " ";
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "select * from password where uuid = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid)) {
				String query = "DELETE FROM PASSWORD WHERE uuid  = ?";
				psmt = con.prepareStatement(query);
				psmt.setString(1, oid);
				psmt.executeUpdate();
				con.commit();
				return true;
			} else {
				con.commit();
				return false;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	public List<NewUser> getAllUserList(int status, String id) {
		List<NewUser> list = new LinkedList<NewUser>();
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from newuser where mgr_status  = ? && mgr_id = ? && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));

				list.add(user);
				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	
	
	

	public List<MplsUser> getMplsUserList(int status, String id) {
		List<MplsUser> list = new LinkedList<MplsUser>();
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from mplsuser where mgr_status  = ? && mgr_olm_id = ? && is_deleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setContact(rs.getString("cno"));
				user.setRights(rs.getString("rights"));
				list.add(user);

			
				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	
	public List<NewUser> getAllUserListFromPassword(String olm, int mstatus) {
		List<NewUser> list = new LinkedList<NewUser>();
		Connection con = null;
		String nms="";
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from password where mgr_olm_id  = ? && mgr_status = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, olm);
			psmt.setInt(2, mstatus);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setOlm_id(rs.getString("olm_id"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("alcatel"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("huawei"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("ciena"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("nortel"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));

				list.add(user);
				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	public List<MplsUser> getMplsUserListFromPassword(String olm, int mstatus) {
		List<MplsUser> list = new LinkedList<MplsUser>();
		Connection con = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from mplspwduser where mgr_olm_id  = ? && mgr_status = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, olm);
			psmt.setInt(2, mstatus);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setContact(rs.getString("cno"));
				user.setRights(rs.getString("rights"));
				list.add(user);

			user = null;
		}

	} catch (Exception e) {
		try {
			con.rollback();
		} catch (SQLException ignored) {
			e.printStackTrace();
		}

		e.printStackTrace();

	} finally {
		try {
			if (con != null)
				con.close();

		} catch (SQLException ignored) {
		}

	}

	return list;

}
	
	public List<NewUser> getAllUserListFromPasswordForSys(int st, int mstatus) {
		List<NewUser> list = new LinkedList<NewUser>();
		Connection con = null;
		String nms="";
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from password where help_desk_status  = ? && mgr_status = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, st);
			psmt.setInt(2, mstatus);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setRticket(rs.getString("rticket"));
				user.setOlm_id(rs.getString("olm_id"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("alcatel"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("huawei"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("ciena"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("nortel"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));

				list.add(user);
				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	public List<NewUser> getAllUserListFromModified(int status, String id) {
		List<NewUser> list = new LinkedList<NewUser>();
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from modifieduser where mgr_status  = ? && mgr_id = ? && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));

				list.add(user);
				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}





public List<MplsUser> getMplsUserListFromModified(int status, String id) {
		List<MplsUser> list = new LinkedList<MplsUser>();
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from mplsmoduser where mgr_status  = ? && mgr_olm_id = ? && is_deleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();

				while (rs.next()) {
					MplsUser user = new MplsUser();
					user.setFname(rs.getString("fname"));
					user.setLname(rs.getString("lname"));
					user.setOlm_id(rs.getString("olm_id"));
					user.setDept(rs.getString("dept"));
					user.setMgrname(rs.getString("mgr_name"));
					user.setEmail(rs.getString("email"));
					user.setContact(rs.getString("cno"));
					user.setRights(rs.getString("rights"));
					list.add(user);

				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	
	
	
	public List<NewUser> getAllUserListFromDeleted(int status, String id) {
		List<NewUser> list = new LinkedList<NewUser>();
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from deleteduser where mgr_status  = ? && mgr_olm_id = ? && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				NewUser user = new NewUser();
				user.setOlm_id(rs.getString("olm_id"));
				user.setFirst_name(rs.getString("fname"));
				user.setLast_name(rs.getString("lname"));
				user.setState(rs.getString("designation"));
				user.setEmail_id(rs.getString("e_mail"));
				user.setC_number(rs.getString("number"));

				list.add(user);
				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	public List<MplsUser> getMplsUserListFromDeleted(int status, String id) {
		List<MplsUser> list = new LinkedList<MplsUser>();
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from mplsdeluser where mgr_status  = ? && mgr_olm_id = ? && is_deleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();

				while (rs.next()) {
					MplsUser user = new MplsUser();
					user.setFname(rs.getString("fname"));
					user.setLname(rs.getString("lname"));
					user.setOlm_id(rs.getString("olm_id"));
					user.setDept(rs.getString("dept"));
					user.setMgrname(rs.getString("mgr_name"));
					user.setEmail(rs.getString("email"));
					user.setContact(rs.getString("cno"));
					user.setRights(rs.getString("rights"));
					list.add(user);

				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	

	public List<NewUser> getAllUserListFromDeletedForSystem(int status, int id,int dst) {
		List<NewUser> list = new LinkedList<NewUser>();
		Connection con = null;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from deleteduser where mgr_status  = ? && helpdesk_status = ? && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setInt(2, id);
			psmt.setInt(3, dst);
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				NewUser user = new NewUser();
				user.setOlm_id(rs.getString("olm_id"));
				user.setFirst_name(rs.getString("fname"));
				user.setLast_name(rs.getString("lname"));
				user.setState(rs.getString("designation"));
				user.setEmail_id(rs.getString("e_mail"));
				user.setC_number(rs.getString("number"));
				user.setManager(rs.getString("manager_name"));

				list.add(user);
				user = null;
			}

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	public NewUser getNewUser(String id) {
		Connection con = null;
		NewUser user = new NewUser();
		try {
			con = data.getConnection();
			System.out.println("connection value" + con);
			con.setAutoCommit(false);
			String query = "select * from newuser where userolm_id  = ? && isdeleted = 0";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			System.out.println("Result set value==>" + rs);
			while (rs.next()) {
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setStreet_name(rs.getString("street_name"));
				user.setManager(rs.getString("mgr_id"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setManager(rs.getString("manager"));
				user.setRequestfor(rs.getString("requestfor"));
				user.setUstype(rs.getString("ustype"));
				user.setUser_id(rs.getString("user_id"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));
				user.setU_belongs(rs.getString("u_belongs"));
				user.setUt_name(rs.getString("ut_name"));
				user.setVd_details(rs.getString("vd_details"));
				user.setReason(rs.getString("reason"));
				user.setDesignation(rs.getString("designation"));
				user.setPurpose(rs.getString("purpose"));
				user.setOs(rs.getString("os"));
				int status = rs.getInt("mgr_status");
				if (status == 1)
					user.setMgr_status("Approved");
				else if (status == 2)
					user.setMgr_status("Rejected By " + rs.getString("manager"));
				else
					user.setMgr_status("Not Approved");
				int adStatus = rs.getInt("admin_status");
				if (adStatus == 1)
					user.setAdmin_status("Approved");
				else if (adStatus == 2)
					user.setAdmin_status("Rejected By "
							+ rs.getString("adname"));
				else
					user.setAdmin_status("Not Approved");
				int hStatus = rs.getInt("helpdesk_status");
				if (hStatus == 1)
					user.setHelp_status("Approved");
				else if (hStatus == 2) {
					user.setHelp_status("Rejected By " + rs.getString("hname"));
				} else if (hStatus == 3) {
					user.setHelp_status("In Progress By "
							+ rs.getString("hname"));

				} else
					user.setHelp_status("Not Approved");
				user.setApplicationAccess(StringUtility.getArrayString(rs
						.getString("app_access")));
				user.setEci(StringUtility.getArrayString((rs.getString("eci"))));
				user.setAlcatel(StringUtility.getArrayString(rs
						.getString("alcatel")));
				user.setHuawei(StringUtility.getArrayString(rs
						.getString("huawei")));
				user.setCiena(StringUtility.getArrayString(rs
						.getString("ciena")));
				user.setNortel(StringUtility.getArrayString(rs
						.getString("nortel")));
				user.setTejas(StringUtility.getArrayString(rs
						.getString("tejas")));
				user.setAdr(StringUtility.getArrayString(rs.getString("adr")));
				user.setMgr_date(rs.getString("mgr_date"));
				user.setAdmin_date(rs.getString("admin_date"));
				user.setSystem_date(rs.getString("system_date"));
				user.setNms(rs.getString("account_created"));
				user.setRef_id(rs.getString("ref_id"));

			}
			con.commit();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return user;
	}
/////////////////////////////////////////////////////////////VIEW DETAILS/////////////////
	public MplsUser getNewMplsUser(String id) {
		
		System.out.println(" >>>>>>>>>>>>>> CHECK THE VALUE OF ID HERE>>>"+id);
		Connection con = null;
		MplsUser user = new MplsUser();
		try {
			con = data.getConnection();
			System.out.println("connection value" + con);
			con.setAutoCommit(false);
			String query = "select * from mplsuser where olm_id  = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			System.out.println("Result set value==>" + rs);
			while (rs.next()) {
				user.setOlm_id(rs.getString("olm_id"));
				user.setRef_id(rs.getString("ref_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setRights(rs.getString("rights"));
				user.setHod(rs.getString("hod_name"));
				user.setVendor(rs.getString("vendor"));
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setLocation(rs.getString("locn"));
				user.setContact(rs.getString("cno"));
				user.setEmail(rs.getString("email"));
				user.setDesig(rs.getString("desg"));
				user.setHost(rs.getString("host_name"));
				user.setIp(rs.getString("ip"));
				user.setCat(rs.getString("cat"));
				user.setSumm(rs.getString("summ"));
				
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else if (rs.getInt("mgr_status") == 2) {
				user.setMgr_status("Not Approved");
				//	user.setMgr_status("Rejected By " + rs.getString("manager"));
				}
				
				
				if (rs.getInt("hod_status") == 1) {
					user.setHod_status("Approved");
				} else if (rs.getInt("hod_status") == 2) {
					user.setHod_status("Not Approved");
				}
				

				if (rs.getInt("mpls_status") == 1) {
					user.setMpls_status("Created");
				} else if (rs.getInt("mpls_status") == 3) {
					user.setMpls_status("IN Progress");
				} else if (rs.getInt("mpls_status") == 2) {
					user.setMpls_status("Rejected");
				}
				
				user.setMgr_time(rs.getString("mgr_time"));
				user.setHod_time(rs.getString("hod_time"));
				user.setMpls_time(rs.getString("mpls_time"));
				user.setPwd(rs.getString("updated_pwd"));
			}
			con.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return user;
	}
	
	
	///////////////VIEW DETAILS END /////////////////////////////////////////
	
	
	
	public NewUser getNewUserForModification(String id) {
		Connection con = null;
		NewUser user = new NewUser();
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from modifieduser where userolm_id  = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			while (rs.next()) {
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setStreet_name(rs.getString("street_name"));
				user.setManager(rs.getString("mgr_id"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setManager(rs.getString("manager"));
				user.setRequestfor(rs.getString("requestfor"));
				user.setUstype(rs.getString("ustype"));
				user.setUser_id(rs.getString("user_id"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));
				user.setU_belongs(rs.getString("u_belongs"));
				user.setUt_name(rs.getString("ut_name"));
				user.setVd_details(rs.getString("vd_details"));
				user.setReason(rs.getString("reason"));
				user.setDesignation(rs.getString("designation"));
				user.setPurpose(rs.getString("purpose"));
				user.setOs(rs.getString("os"));
				int status = rs.getInt("mgr_status");
				System.out.println("MANAGER status inside modified user activation");
				System.out.println(status);
				if (status == 1)
					user.setMgr_status("Approved");
				else if (status == 2)
					user.setMgr_status("Rejected By " + rs.getString("manager"));
				else
					user.setMgr_status("Not Approved");
				int adStatus = rs.getInt("admin_status");
				System.out.println(adStatus);
				if (adStatus == 1)
					user.setAdmin_status("Approved");
				else if (adStatus == 2)
					user.setAdmin_status("Rejected By "
							+ rs.getString("adname"));
				else
					user.setAdmin_status("Not Approved");
				int hStatus = rs.getInt("helpdesk_status");
				if (hStatus == 1)
					user.setHelp_status("Approved");
				else if (hStatus == 2) {
					user.setHelp_status("Rejected By " + rs.getString("hname"));
				} else if (hStatus == 3) {
					user.setHelp_status("In Progress By "
							+ rs.getString("hname"));

				} else
					user.setHelp_status("Not Approved");
				user.setApplicationAccess(StringUtility.getArrayString(rs
						.getString("app_access")));
				user.setEci(StringUtility.getArrayString((rs.getString("eci"))));
				user.setAlcatel(StringUtility.getArrayString(rs
						.getString("alcatel")));
				user.setHuawei(StringUtility.getArrayString(rs
						.getString("huawei")));
				user.setCiena(StringUtility.getArrayString(rs
						.getString("ciena")));
				user.setNortel(StringUtility.getArrayString(rs
						.getString("nortel")));
				user.setTejas(StringUtility.getArrayString(rs
						.getString("tejas")));
				user.setAdr(StringUtility.getArrayString(rs.getString("adr")));
				user.setMgr_date(rs.getString("mgr_date"));
				user.setAdmin_date(rs.getString("admin_date"));
				user.setSystem_date(rs.getString("system_date"));
				user.setNms(rs.getString("account_created"));
				user.setRef_id(rs.getString("ref_id"));

			}
			con.commit();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	public NewUser getNewUserForPasswordReset(String id) {
		Connection con = null;
		NewUser user = new NewUser();
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from password where uuid  = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			while (rs.next()) {
				user.setUuid(rs.getString("uuid"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setNms_id(rs.getString("nms_id"));
				int hStatus = rs.getInt("help_desk_status");
				if (hStatus == 1)
					user.setHelp_status("Approved");
				else if (hStatus == 2) {
					user.setHelp_status("Not Approved");
				} else if (hStatus == 3) {
					user.setHelp_status("In Progress By "
							+ rs.getString("hname"));
				} else
					user.setHelp_status("Not Approved");
				int mStatus = rs.getInt("mgr_status");
				if (mStatus == 1)
					user.setMgr_status("Approved");
				else if (mStatus == 2) {
					user.setMgr_status("Not Approved");
				} else if (mStatus == 3) {
					user.setMgr_status("In Progress By "
							+ rs.getString("hname"));
				} else
					user.setMgr_status("Not Approved");
				user.setApplicationAccess(StringUtility.getArrayString(rs
						.getString("app_access")));
				user.setEci(StringUtility.getArrayString((rs.getString("eci"))));
				user.setAlcatel(StringUtility.getArrayString(rs
						.getString("alcatel")));
				user.setHuawei(StringUtility.getArrayString(rs
						.getString("huawei")));
				user.setCiena(StringUtility.getArrayString(rs
						.getString("ciena")));
				user.setNortel(StringUtility.getArrayString(rs
						.getString("nortel")));
				user.setTejas(StringUtility.getArrayString(rs
						.getString("tejas")));
				user.setAdr(StringUtility.getArrayString(rs.getString("adr")));
				user.setMgr_date(rs.getString("mgr_date"));
				user.setSystem_date(rs.getString("system_date"));
				user.setNms(rs.getString("pwd_reset_nms"));
				user.setPassword(rs.getString("password"));

			}
			con.commit();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	public boolean validateIdForIdStatus(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from newuser where userolm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("userolm_id");
			}
			if (olm.equals(oid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	public NewUser getNewUserForPasswordResetByManager(String id) {
		Connection con = null;
		NewUser user = new NewUser();
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from password where uuid  = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			while (rs.next()) {
				user.setUuid(rs.getString("uuid"));
				user.setNms_id(rs.getString("nms_id"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setEmail_id(rs.getString("email"));
				int hStatus = rs.getInt("help_desk_status");
				if (hStatus == 1)
					user.setHelp_status("Approved");
				else if (hStatus == 2) {
					user.setHelp_status("Rejected By " + rs.getString("hname"));
				} else if (hStatus == 3) {
					user.setHelp_status("In Progress By "
							+ rs.getString("hname"));
				} else
					user.setHelp_status("Not Approved");
				user.setApplicationAccess(StringUtility.getArrayString(rs
						.getString("app_access")));
				user.setEci(StringUtility.getArrayString((rs.getString("eci"))));
				user.setAlcatel(StringUtility.getArrayString(rs
						.getString("alcatel")));
				user.setHuawei(StringUtility.getArrayString(rs
						.getString("huawei")));
				user.setCiena(StringUtility.getArrayString(rs
						.getString("ciena")));
				user.setNortel(StringUtility.getArrayString(rs
						.getString("nortel")));
				user.setTejas(StringUtility.getArrayString(rs
						.getString("tejas")));
				user.setAdr(StringUtility.getArrayString(rs.getString("adr")));

			}
			con.commit();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	public NewUser getNewUserForDelete(String id) {
		Connection con = null;
		NewUser user = new NewUser();
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from deleteduser where olm_id  = ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			while (rs.next()) {
				user.setOlm_id(rs.getString("olm_id"));
				user.setFirst_name(rs.getString("fname"));
				user.setLast_name(rs.getString("lname"));
				user.setStreet_name(rs.getString("location"));
				user.setManager(rs.getString("mgr_olm_id"));
				user.setEmail_id(rs.getString("e_mail"));
				user.setC_number(rs.getString("number"));
				user.setUt_name(rs.getString("sec_company"));
				user.setDesignation(rs.getString("designation"));
				user.setRequestfor(rs.getString("request_for"));
				user.setUstype(rs.getString("type"));
				user.setU_belongs(rs.getString("belongs"));
				user.setPurpose(rs.getString("purpose"));
				user.setState(rs.getString("department"));
				user.setManager(rs.getString("manager_name"));
				user.setVd_details(rs.getString("vendor_name"));
				user.setVendor(rs.getString("vendor_type"));
				int status = rs.getInt("mgr_status");
				if (status == 1)
					user.setMgr_status("Approved");
				else if (status == 2)
					user.setMgr_status("Rejected By " + rs.getString("manager"));
				else
					user.setMgr_status("Not Approved");
				int hStatus = rs.getInt("helpdesk_status");
				if (hStatus == 1)
					user.setHelp_status("Approved");
				else if (hStatus == 2) {
					user.setHelp_status("Rejected By " + rs.getString("hname"));
				} else if (hStatus == 3) {
					user.setHelp_status("In Progress By "
							+ rs.getString("hname"));
				} else
					user.setHelp_status("Not Approved");
				user.setMgr_date(rs.getString("mgr_date"));
				user.setSystem_date(rs.getString("system_date"));
				user.setNms(rs.getString("account_deleted"));
			}
			con.commit();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	public boolean activeUserByManager(String status, String olm) {
		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;

		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update newuser set mgr_status = ?,mgr_date= ? where userolm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);

			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.executeUpdate();
			System.out.println("status update in newuser tabel");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

	}

	public boolean deleteUserByManager(String status, String olm) {
		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;

		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update deleteduser set mgr_status = ? ,mgr_date = ?where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.executeUpdate();
			System.out.println("status update in deleteduser tabel");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

	}

	public boolean modifiedUserByManager(String status, String olm) {
		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;

		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update modifieduser set mgr_status = ?,mgr_date = ? where userolm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.executeUpdate();
			System.out.println("status update in deleteduser tabel");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}

	}

	public List<NewUser> getAllUserListForAdmin(int status, int mgrStatus) {
		Connection con = null;
		List<NewUser> list = new LinkedList<NewUser>();
		String nms="";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from newuser where admin_status  = ? && mgr_status = ? && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setInt(2, mgrStatus);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));
				user.setManager(rs.getString("manager"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("alcatel"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("huawei"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("ciena"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("nortel"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));
				System.out.println(nms);
				list.add(user);
				user = null;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return list;
	}

	public List<NewUser> getModifiedUserListForAdmin(int status, int mgrStatus) {
		Connection con = null;
		List<NewUser> list = new LinkedList<NewUser>();
		String nms="";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from modifieduser where admin_status  = ? && mgr_status = ? && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, status);
			psmt.setInt(2, mgrStatus);
			psmt.setInt(3, 0);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));
				user.setManager(rs.getString("manager"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("alcatel"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("huawei"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("ciena"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("nortel"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));
				System.out.println(nms);
				list.add(user);
				user = null;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return list;
	}

	public List<NewUser> getAllMisData(String reason, String from, String to) {
		Connection con = null;
		List<NewUser> list = new LinkedList<NewUser>();
		String query = null;
		String nms="";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			if (reason.equals("Creation")) {
				query = "SELECT * FROM newuser WHERE helpdesk_status =1 AND DATE >= ? AND  DATE <= ?";
			}
			if (reason.equals("Modification")) {
				query = "SELECT * FROM modifieduser WHERE helpdesk_status =1 AND DATE >= ? AND  DATE <= ?";
			}
			psmt = con.prepareStatement(query);
			psmt.setString(1, from);
			psmt.setString(2, to);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));
				user.setManager(rs.getString("manager"));
				user.setDate(rs.getString("date"));
				user.setRticket(rs.getString("rticket"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("alcatel"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("huawei"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("ciena"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("nortel"));
				nms = nms

				+ StringUtility.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));
				System.out.println(nms);
				list.add(user);
				user = null;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return list;

	}

	public List<NewUser> getAllMisData(String from, String to) {
		Connection con = null;
		List<NewUser> list = new LinkedList<NewUser>();
		String query = null;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			query = "SELECT * FROM deleteduser WHERE helpdesk_status =1 AND DATE >= ? AND  DATE <= ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, from);
			psmt.setString(2, to);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setFirst_name(rs.getString("fname"));
				user.setLast_name(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setState(rs.getString("department"));
				user.setEmail_id(rs.getString("e_mail"));
				user.setC_number(rs.getString("number"));
				user.setManager(rs.getString("manager_name"));
				user.setDate(rs.getString("date"));
				user.setRticket(rs.getString("rticket"));
				list.add(user);
				user = null;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return list;

	}

	public List<NewUser> getAllMisDataForPwd(String from, String to) {
		Connection con = null;
		List<NewUser> list = new LinkedList<NewUser>();
		String query = null;
		String nms = "";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("from date==>"+from);
			System.out.println("to date==>"+to);
			query = "SELECT * FROM password WHERE help_desk_status =1 AND DATE >= ? AND  DATE <= ?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, from);
			psmt.setString(2, to);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {

				NewUser user = new NewUser();
				user.setOlm_id(rs.getString("olm_id"));
				user.setNms_id(rs.getString("nms_id"));
				user.setState(rs.getString("department"));
				user.setMgr_id(rs.getString("mgr_olm_id"));
				user.setUuid(rs.getString("uuid"));
				user.setDate(rs.getString("date"));
				user.setRticket(rs.getString("rticket"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("alcatel"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("huawei"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("ciena"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("nortel"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));

				list.add(user);
				user = null;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return list;

	}

	public boolean activeUserByAdmin(String status, String olm, String name) {
		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;

		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update newuser set admin_status = ?,adname = ?,admin_date = ? where userolm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			psmt.setString(2, name);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(3, timestamp);
			psmt.setString(4, olm);
			psmt.executeUpdate();
			System.out.println("status update in newuser tabel");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean activeModifiedUserByAdmin(String status, String olm,
			String name) {
		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;

		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update modifieduser set admin_status = ?,adname = ?,admin_date = ? where userolm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			psmt.setString(2, name);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(3, timestamp);
			psmt.setString(4, olm);
			psmt.executeUpdate();
			System.out.println("status update in newuser tabel");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean activeUserBySystem(String hstatus, String olm, String name,
			String nms,String rticket) {
		Connection con = null;
		int i;
		if (hstatus.equals("approve")) {
			i = 1;
		} else if (hstatus.equals("progress")) {
			i = 3;
		} else if (hstatus.equals("rejected")) {
			i = 2;
		} else
			i = 0;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update newuser set helpdesk_status = ?,hname = ?,account_created = ? ,system_date = ?,rticket=? where userolm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			psmt.setString(2, name);
			psmt.setString(3, nms);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(4, timestamp);
			psmt.setString(5, rticket);
			psmt.setString(6, olm);
			psmt.executeUpdate();
			System.out.println("help desk person name" + name);
			System.out.println("status update in newuser tabel");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean changePassword(String hstatus, String olm, String name,
			int mgrst, String nms,String rticket,String password) {
		Connection con = null;
		int i;
		if (hstatus.equals("approve")) {
			i = 1;
		} else if (hstatus.equals("progress")) {
			i = 3;
		} else if (hstatus.equals("rejected")) {
			i = 2;
		} else
			i = 0;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update password set help_desk_status = ?,hname = ?,system_date = ? ,pwd_reset_nms=? ,rticket=?,password=? where uuid = ? && mgr_status = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			psmt.setString(2, name);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(3, timestamp);
			psmt.setString(4, nms);
			psmt.setString(5, rticket);
			psmt.setString(6, password);
			psmt.setString(7, olm);
			psmt.setInt(8, mgrst);
			psmt.executeUpdate();
			System.out.println("help desk person name" + name);
			System.out.println("status update in newuser tabel");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean changePasswordByManager(String hstatus, String olm,
			String uuid) {
		Connection con = null;
		int i;
		if (hstatus.equals("approve")) {
			i = 1;
		} else if (hstatus.equals("progress")) {
			i = 3;
		} else if (hstatus.equals("rejected")) {
			i = 2;
		} else
			i = 0;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update password set mgr_status = ?,mgr_date = ? where olm_id = ? && uuid = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.setString(4, uuid);
			psmt.executeUpdate();
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean modifiedUserBySystem(String hstatus, String olm,
			String name, String nms,String rticket,String uuid) {
		Connection con = null;
		int i;
		if (hstatus.equals("approve")) {
			i = 1;
		} else if (hstatus.equals("progress")) {
			i = 3;
		} else if (hstatus.equals("rejected")) {
			i = 2;
		} else
			i = 0;
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update modifieduser set helpdesk_status = ?,hname = ?,system_date = ?,account_created = ? ,rticket = ? where userolm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			psmt.setString(2, name);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(3, timestamp);
			psmt.setString(4, nms);
			psmt.setString(5, rticket);
			psmt.setString(6, olm);
			psmt.executeUpdate();
			System.out.println("help desk person name" + name);
			System.out.println("status update in newuser tabel");
			if (i == 1) {
				String query1 = "insert into previousmodified(select * from newuser where userolm_id = ?)";
				psmt = con.prepareStatement(query1);
				psmt.setString(1, olm);
				psmt.executeUpdate();
				System.out
						.println("delete modified user inside new user table after system help desk approval.");
				String sqlquery = "delete  from newuser where userolm_id = ?";
				psmt = con.prepareStatement(sqlquery);
				psmt.setString(1, olm);
				psmt.executeUpdate();
				
				
				String sqlquery1 = "delete  from newuser where uuid = ?";
				psmt = con.prepareStatement(sqlquery1);
				psmt.setString(1, uuid);
				psmt.executeUpdate();
				System.out
						.println("Enter modified user inside new user table after system help desk approval.");
				String sql = "insert into newuser(select * from modifieduser where userolm_id = ?)";
				psmt = con.prepareStatement(sql);
				psmt.setString(1, olm);
				psmt.executeUpdate();
				con.commit();
			}
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean DeletedUserBySystem(String hstatus, String olm, String name,
			String nms,String rticket) {
		Connection con = null;
		int i;
		if (hstatus.equals("approve")) {
			i = 1;
		} else if (hstatus.equals("progress")) {
			i = 3;
		} else if (hstatus.equals("rejected")) {
			i = 0;
		} else
			i = 0;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update newuser set isdeleted = ? where userolm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			psmt.setString(2, olm);
			psmt.executeUpdate();
			System.out.println("status update in newuser tabel");
			String query1 = "update deleteduser set isdeleted = ?, helpdesk_status = ?,system_date = ?,account_deleted = ?,rticket = ?,hname = ? where olm_id = ?";
			psmt = con.prepareStatement(query1);
			psmt.setInt(1, i);
			psmt.setInt(2, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(3, timestamp);
			psmt.setString(4, nms);
			psmt.setString(5, rticket);
			psmt.setString(6, name);
			psmt.setString(7, olm);
			psmt.executeUpdate();
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
	}

	public List<NewUser> getAllUserListForSystem(int mgrStatus, int adStatus,
			int heStatus) {
		Connection con = null;
		List<NewUser> list = new LinkedList<NewUser>();
		String nms="";
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from newuser where mgr_status = ? && admin_status  = ? && helpdesk_status = ?  && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, mgrStatus);
			psmt.setInt(2, adStatus);
			psmt.setInt(3, heStatus);
			psmt.setInt(4, 0);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));
				user.setManager(rs.getString("manager"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("alcatel"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("huawei"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("ciena"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("nortel"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));
				list.add(user);
				user = null;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return list;
	}

	public List<NewUser> getModifiedUserListForSystem(int mgrStatus,
			int adStatus, int heStatus) {
		Connection con = null;
		List<NewUser> list = new LinkedList<NewUser>();
		String nms;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "select * from modifieduser where mgr_status = ? && admin_status  = ? && helpdesk_status = ?  && isdeleted = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, mgrStatus);
			psmt.setInt(2, adStatus);
			psmt.setInt(3, heStatus);
			psmt.setInt(4, 0);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				NewUser user = new NewUser();
				user.setUuid(rs.getString("uuid"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setOlm_id(rs.getString("userolm_id"));
				user.setState(rs.getString("state"));
				user.setEmail_id(rs.getString("email_id"));
				user.setC_number(rs.getString("c_number"));
				user.setManager(rs.getString("manager"));
				nms = StringUtility.checkNUllForSpace(rs
						.getString("app_access"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("eci"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("alcatel"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("huawei"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("ciena"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs
								.getString("nortel"));
				nms = nms
						+ StringUtility
								.checkNUllForSpace(rs.getString("tejas"));
				nms = nms
						+ StringUtility.checkNUllForSpace(rs.getString("adr"));
				if(nms.length()>2)
				user.setNms(nms.substring(0, nms.length() - 1));
				list.add(user);
				user = null;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();

			} catch (SQLException ignored) {
			}

		}
		return list;
	}
	public String getHodId(String name) {
		Connection con = null;
		String hodid = "";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "select * from hod where name = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, name);

			rs = psmt.executeQuery();

			while (rs.next()) {
				hodid = rs.getString("olmid");

			}
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return hodid;
	}
	
	public boolean submitTacCreReq(TacUser user) {
		Connection con;
		con = data.getConnection();
		String hodid = "";
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		if (user.getRights().equals("Write"))
			hodid = getHodId(user.getHod());
		String query = "insert into tacuser (olm_id,ref_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,rights,hod_name,hod_olm_id,vendor,fname,lname,locn,cno,email,desg,host_name,ip,cat,summ)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, user.getRef_id());
			psmt.setString(3, user.getRequest());
			psmt.setString(4, user.getUsType());
			psmt.setString(5, user.getUsBelong());
			psmt.setString(6, user.getPurpose());
			psmt.setString(7, user.getAcReqType());
			psmt.setString(8, user.getDept());
			psmt.setString(9, user.getMgrname());
			psmt.setString(10, mgr_olmid);
			psmt.setString(11, user.getRights());
			psmt.setString(12, user.getHod());
			psmt.setString(13, hodid);
			psmt.setString(14, user.getVendor());
			psmt.setString(15, user.getFname());
			psmt.setString(16, user.getLname());
			psmt.setString(17, user.getLocation());
			psmt.setString(18, user.getContact());
			psmt.setString(19, user.getEmail());
			psmt.setString(20, user.getDesig());
			psmt.setString(21, user.getHost());
			psmt.setString(22, user.getIp());
			psmt.setString(23, user.getCat());
			psmt.setString(24, user.getSumm());
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();
				return false;
			} catch (Exception e1) {
				e1.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	public boolean submitMplsCreReq(MplsUser user) {
		Connection con;
		con = data.getConnection();
		String hodid = "";
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		if (user.getRights().contains("Write"))
			hodid = getHodId(user.getHod());
		String query = "insert into mplsuser (olm_id,ref_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,rights,hod_name,hod_olm_id,vendor,fname,lname,locn,cno,email,desg,host_name,ip,cat,summ)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, user.getRef_id());
			psmt.setString(3, user.getRequest());
			psmt.setString(4, user.getUsType());
			psmt.setString(5, user.getUsBelong());
			psmt.setString(6, user.getPurpose());
			psmt.setString(7, user.getAcReqType());
			psmt.setString(8, user.getDept());
			psmt.setString(9, user.getMgrname());
			psmt.setString(10, mgr_olmid);
			psmt.setString(11, user.getRights());
			psmt.setString(12, user.getHod());
			psmt.setString(13, hodid);
			psmt.setString(14, user.getVendor());
			psmt.setString(15, user.getFname());
			psmt.setString(16, user.getLname());
			psmt.setString(17, user.getLocation());
			psmt.setString(18, user.getContact());
			psmt.setString(19, user.getEmail());
			psmt.setString(20, user.getDesig());
			psmt.setString(21, user.getHost());
			psmt.setString(22, user.getIp());
			psmt.setString(23, user.getCat());
			psmt.setString(24, user.getSumm());
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();
				return false;
			} catch (Exception e1) {
				e1.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	
	
	
	
	
	public boolean submitTacModifiedReq(TacUser user) {
		Connection con;
		con = data.getConnection();
		String hodid = "";
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		if (user.getRights().equals("Write"))
			hodid = getHodId(user.getHod());
		String query = "insert into tacmoduser (olm_id,ref_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,rights,hod_name,hod_olm_id,vendor,fname,lname,locn,cno,email,desg,host_name,ip,cat,summ,form_time)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, user.getRef_id());
			psmt.setString(3, user.getRequest());
			psmt.setString(4, user.getUsType());
			psmt.setString(5, user.getUsBelong());
			psmt.setString(6, user.getPurpose());
			psmt.setString(7, user.getAcReqType());
			psmt.setString(8, user.getDept());
			psmt.setString(9, user.getMgrname());
			psmt.setString(10, mgr_olmid);
			psmt.setString(11, user.getRights());
			psmt.setString(12, user.getHod());
			psmt.setString(13, hodid);
			psmt.setString(14, user.getVendor());
			psmt.setString(15, user.getFname());
			psmt.setString(16, user.getLname());
			psmt.setString(17, user.getLocation());
			psmt.setString(18, user.getContact());
			psmt.setString(19, user.getEmail());
			psmt.setString(20, user.getDesig());
			psmt.setString(21, user.getHost());
			psmt.setString(22, user.getIp());
			psmt.setString(23, user.getCat());
			psmt.setString(24, user.getSumm());
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(25, timestamp);
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();
				return false;
			} catch (Exception e1) {
				e1.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	
	public boolean submitTacdeleteReq(TacUser user) {
		Connection con;
		con = data.getConnection();
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		String query = "insert into tacdeluser (olm_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,desg,email)values(?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, user.getRequest());
			psmt.setString(3, user.getUsType());
			psmt.setString(4, user.getUsBelong());
			psmt.setString(5, user.getPurpose());
			psmt.setString(6, user.getAcReqType());
			psmt.setString(7, user.getDept());
			psmt.setString(8, user.getMgrname());
			psmt.setString(9, mgr_olmid);
			psmt.setString(10, user.getDesig());
			psmt.setString(11, user.getEmail());
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();

			} catch (Exception e1) {
				e1.printStackTrace();

			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	
	public boolean checkTacUserOlmID(String olm) {
		Connection con = data.getConnection();
		String olmid = "";
		String query = "select * from tacuser where olm_id  = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, olm);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				olmid = rs.getString("olm_id");
			}
			if (olmid.equalsIgnoreCase(olm))
				return true;
			else
				return false;
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}


	public boolean checkMplsUserOlmID(String olm) {
		Connection con = data.getConnection();
		String olmid = "";
		String query = "select * from mplsuser where olm_id  = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, olm);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				olmid = rs.getString("olm_id");
			}
			if (olmid.equalsIgnoreCase(olm))
				return true;
			else
				return false;
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}
	public List<MplsUser> getAllMplsCreateUser(int st, String id) {
		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplsuser where mgr_olm_id = ? && mgr_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setInt(2, st);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;
	}

	public List<MplsUser> getAllMplsCreateHODUser(int st, String id) {
		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplsuser where mgr_olm_id = ? && mgr_status = ? && rights like '%Write%' ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setInt(2, st);
	//		psmt.setString(3, "Write");

			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;
	}

	
	
	public List<TacUser> getAllTacCrateUser(int st, String id) {
		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacuser where mgr_olm_id = ? && mgr_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setInt(2, st);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;
	}

	
	public TacUser getUser(String olm, String table) {
		Connection con = data.getConnection();
		TacUser user = new TacUser();
		String sql = "select * from " + table + " where olm_id=?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				user.setOlm_id(rs.getString("olm_id"));
				user.setRef_id(rs.getString("ref_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setRights(rs.getString("rights"));
				user.setHod(rs.getString("hod_name"));
				user.setVendor(rs.getString("vendor"));
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setLocation(rs.getString("locn"));
				user.setContact(rs.getString("cno"));
				user.setEmail(rs.getString("email"));
				user.setDesig(rs.getString("desg"));
				user.setHost(rs.getString("host_name"));
				user.setIp(rs.getString("ip"));
				user.setCat(rs.getString("cat"));
				user.setSumm(rs.getString("summ"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else if (rs.getInt("mgr_status") == 2) {
					user.setMgr_status("Not Approved");
				}
				if (rs.getInt("hod_status") == 1) {
					user.setHod_status("Approved");
				} else if (rs.getInt("hod_status") == 2) {
					user.setHod_status("Not Approved");
				}
				if (rs.getInt("tac_status") == 1) {
					user.setTac_status("Created");
				} else if (rs.getInt("tac_status") == 3) {
					user.setTac_status("IN Progress");
				} else if (rs.getInt("tac_status") == 2) {
					user.setTac_status("Rejected");
				}
				user.setMgr_time(rs.getString("mgr_time"));
				user.setHod_time(rs.getString("hod_time"));
				user.setTac_time(rs.getString("tac_time"));
				user.setPwd(rs.getString("updated_pwd"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return user;
	}
//////////////////////////////////////////////
	
	public MplsUser getMplsUser(String olm, String table) {
		Connection con = data.getConnection();
		MplsUser user = new MplsUser();
		String sql = "select * from " + table + " where olm_id=?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				user.setOlm_id(rs.getString("olm_id"));
				user.setRef_id(rs.getString("ref_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setRights(rs.getString("rights"));
				user.setHod(rs.getString("hod_name"));
				user.setVendor(rs.getString("vendor"));
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setLocation(rs.getString("locn"));
				user.setContact(rs.getString("cno"));
				user.setEmail(rs.getString("email"));
				user.setDesig(rs.getString("desg"));
				user.setHost(rs.getString("host_name"));
				user.setIp(rs.getString("ip"));
				user.setCat(rs.getString("cat"));
				user.setSumm(rs.getString("summ"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else if (rs.getInt("mgr_status") == 2) {
					user.setMgr_status("Not Approved");
				}
				if (rs.getInt("hod_status") == 1) {
					user.setHod_status("Approved");
				} else if (rs.getInt("hod_status") == 2) {
					user.setHod_status("Not Approved");
				}
				if (rs.getInt("mpls_status") == 1) {
					user.setMpls_status("Created");
				} else if (rs.getInt("mpls_status") == 3) {
					user.setMpls_status("IN Progress");
				} else if (rs.getInt("mpls_status") == 2) {
					user.setMpls_status("Rejected");
				}
				user.setMgr_time(rs.getString("mgr_time"));
				user.setHod_time(rs.getString("hod_time"));
				user.setMpls_time(rs.getString("mpls_time"));
				user.setPwd(rs.getString("updated_pwd"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	
	//////////////////////
	
	public boolean updateTacUserForManager(String status, String olm,
			String mgrname, String rights, String table) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;
		try {
			String email1 = "Ishwar1.Pandav@airtel.com";
			con = data.getConnection();
			con.setAutoCommit(false);
			if (rights.equalsIgnoreCase("Read")) {
				String query = "update "
						+ table
						+ " set mgr_status = ?,mgr_time = ?,hod_status = ?,hod_time = ? where olm_id = ?";
				psmt = con.prepareStatement(query);
				psmt.setInt(1, i);
				java.sql.Timestamp timestamp = new java.sql.Timestamp(
						new java.util.Date().getTime());
				psmt.setTimestamp(2, timestamp);
				psmt.setInt(3, i);
				psmt.setTimestamp(4, timestamp);
				psmt.setString(5, olm);
				String msg = "Hi<br>";
				msg += "<br><b>You have a Tacacs Account Creation/Modification request in your bin. </b><br>";
				msg += "<br>";
				msg += "<br>Thank you";
				msg += "<br>Portal Development Team";
				msg += "<br>PH: 0124-4381378";
				SendEmail.sendMail(email1, msg, olm);

				psmt.executeUpdate();
				System.out.println("status update in tacuser table");
				con.commit();
			} else {
				String hodolm = findHodId(olm, table);
				String email = findHodEmailId(hodolm);
				String query = "update " + table
						+ " set mgr_status = ?,mgr_time = ? where olm_id = ?";
				psmt = con.prepareStatement(query);
				psmt.setInt(1, i);
				java.sql.Timestamp timestamp = new java.sql.Timestamp(
						new java.util.Date().getTime());
				psmt.setTimestamp(2, timestamp);
				psmt.setString(3, olm);
				psmt.executeUpdate();
				String msg = "Hi<br>";
				msg += "<br><b>You have a Tacacs Account Creation/Modification request in your bin. </b><br>";
				msg += "<br>";
				msg += "<br>Thank you";
				msg += "<br>Portal Development Team";
				msg += "<br>PH: 0124-4381378";
				SendEmail.sendMail(email, msg, olm);
				System.out.println("status update in tacuser table");
				con.commit();

			}
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}
//////////////////////////////////////////////////////////
	public boolean updateMplsUserForManager(String status, String olm,
			String mgrname, String rights, String table) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;
		try {
			String email1 = "divya.verma@airtel.com";
			con = data.getConnection();
			con.setAutoCommit(false);
			if (rights.equalsIgnoreCase("Read")) {
				String query = "update "
						+ table
						+ " set mgr_status = ?,mgr_time = ?,hod_status = ?,hod_time = ? where olm_id = ?";
				psmt = con.prepareStatement(query);
				psmt.setInt(1, i);
				java.sql.Timestamp timestamp = new java.sql.Timestamp(
						new java.util.Date().getTime());
				psmt.setTimestamp(2, timestamp);
				psmt.setInt(3, i);
				psmt.setTimestamp(4, timestamp);
				psmt.setString(5, olm);
				String msg = "Hi<br>";
				msg += "<br><b>You have a MPLS Account Creation/Modification request in your bin. </b><br>";
				msg += "<br>";
				msg += "<br>Thank you";
				msg += "<br>Portal Development Team";
				msg += "<br>PH: 0124-4381378";
				SendEmail.sendMail(email1, msg, olm);

				psmt.executeUpdate();
				System.out.println("status update in mplsuser table");
				con.commit();
			} else {
				String hodolm = findHodId(olm, table);
				String email = findHodEmailId(hodolm);
				String query = "update " + table
						+ " set mgr_status = ?,mgr_time = ? where olm_id = ?";
				psmt = con.prepareStatement(query);
				psmt.setInt(1, i);
				java.sql.Timestamp timestamp = new java.sql.Timestamp(
						new java.util.Date().getTime());
				psmt.setTimestamp(2, timestamp);
				psmt.setString(3, olm);
				psmt.executeUpdate();
				String msg = "Hi<br>";
				msg += "<br><b>You have a MPLS Account Creation/Modification request in your bin. </b><br>";
				msg += "<br>";
				msg += "<br>Thank you";
				msg += "<br>Portal Development Team";
				msg += "<br>PH: 0124-4381378";
				SendEmail.sendMail(email, msg, olm);
				System.out.println("status update in MPLSuser table");
				con.commit();

			}
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}

	///////////////////////////////////////
	
	public boolean updateTacUserForHOD(String status, String olm,
			String mgrname, String table) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;

		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update " + table
					+ " set hod_status = ?,hod_time = ? where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.executeUpdate();
			System.out.println("status update in tacuser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}
	public boolean updateMplsUserForHOD(String status, String olm,
			String mgrname, String table) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else
			i = 1;

		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update " + table
					+ " set hod_status = ?,hod_time = ? where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.executeUpdate();
			System.out.println("status update in mplsuser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}

	
	
	public List<TacUser> getAllTacCrateUserForHOD(int st, String id, int hst,
			String table) {
		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from "
				+ table
				+ " where hod_olm_id = ? && mgr_status = ? && rights = ? && hod_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setInt(2, st);
			psmt.setString(3, "write");
			psmt.setInt(4, hst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	public List<MplsUser> getAllMplsCrateUserForHOD(int st, String id, int hst,
			String table) {
		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from "
				+ table
				+ " where hod_olm_id = ? && mgr_status = ? && rights like '%Write%' && hod_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setInt(2, st);
		//	psmt.setString(3, "Write");
			psmt.setInt(4, hst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	
	public List<TacUser> getAllTacCrateUserForSystem(int st, int hst, int sst) {

		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacuser where  mgr_status = ? && hod_status = ? && tac_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setInt(2, hst);
			psmt.setInt(3, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setContact(rs.getString("cno"));
				user.setRights(rs.getString("rights"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	public List<MplsUser> getAllMplsCrateUserForSystem(int st, int hst, int sst) {

		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplsuser where  mgr_status = ? && hod_status = ? && mpls_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setInt(2, hst);
			psmt.setInt(3, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setContact(rs.getString("cno"));
				user.setRights(rs.getString("rights"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	
	
	
	
	public boolean updateTacUserForSystem(String status, String olm,
			String sysname, String ticket, String pwd) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update tacuser set tac_status = ?,tac_time = ? ,tac_name = ? ,ticket = ?,updated_pwd=? where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, sysname);
			psmt.setString(4, ticket);
			psmt.setString(5, pwd);
			psmt.setString(6, olm);
			psmt.executeUpdate();
			System.out.println("status update in tacuser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
	}

	public boolean updateMplsUserForSystem(String status, String olm,
			String sysname, String ticket, String pwd) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update mplsuser set mpls_status = ?,mpls_time = ? ,mpls_name = ? ,ticket = ?,updated_pwd=? where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, sysname);
			psmt.setString(4, ticket);
			psmt.setString(5, pwd);
			psmt.setString(6, olm);
			psmt.executeUpdate();
			System.out.println("status update in mplsuser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
	}

	
	public List<TacUser> getAllTacModification(int st, String id) {

		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacmoduser where mgr_olm_id = ? && mgr_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setInt(2, st);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	public List<MplsUser> getAllMplsModification(int st, String id) {

		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplsmoduser where mgr_olm_id = ? && mgr_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setInt(2, st);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}
	
	
	public List<TacUser> getAllTacModificationSystem(int st, int hst, int sst) {

		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacmoduser where  mgr_status = ? && hod_status = ? && tac_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setInt(2, hst);
			psmt.setInt(3, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setContact(rs.getString("cno"));
				user.setRights(rs.getString("rights"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	public List<MplsUser> getAllMplsModificationSystem(int st, int hst, int sst) {

		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplsmoduser where  mgr_status = ? && hod_status = ? && mpls_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setInt(2, hst);
			psmt.setInt(3, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setContact(rs.getString("cno"));
				user.setRights(rs.getString("rights"));
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	public List<TacUser> getAllTacDeletionSystem(int st, int sst) {

		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacdeluser where  mgr_status = ? && tac_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setInt(2, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();

				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	public List<MplsUser> getAllMplsDeletionSystem(int st, int sst) {

		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplsdeluser where  mgr_status = ? && mpls_status = ?";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setInt(2, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();

				user.setOlm_id(rs.getString("olm_id"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				
				list.add(user);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return list;

	}

	
	public boolean updateTacUserModForSystem(String status, String olm,
			String sysname, String ticket, String pwd) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update tacmoduser set tac_status = ?,tac_time = ? ,tac_name = ? ,ticket = ?,updated_pwd=? where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, sysname);
			psmt.setString(4, ticket);
			psmt.setString(5, pwd);
			psmt.setString(6, olm);
			psmt.executeUpdate();
			System.out.println("status update in tacmoduser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}

	public boolean updateMplsUserModForSystem(String status, String olm,
			String sysname, String ticket, String pwd) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update mplsmoduser set mpls_status = ?,mpls_time = ? ,mpls_name = ? ,ticket = ?,updated_pwd=? where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, sysname);
			psmt.setString(4, ticket);
			psmt.setString(5, pwd);
			psmt.setString(6, olm);
			psmt.executeUpdate();
			System.out.println("status update in mplsmoduser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}
	
	public List<TacUser> getAllTacDeletion(int st, String id) {

		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacdeluser where mgr_status =? && mgr_olm_id=?";

		try {
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setString(2, id);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else {
					user.setMgr_status("Rejected");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return list;
	}
	public List<MplsUser> getAllMplsDeletion(int st, String id) {

		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplsdeluser where mgr_status =? && mgr_olm_id=?";

		try {
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, st);
			psmt.setString(2, id);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else {
					user.setMgr_status("Rejected");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return list;
	}

	
	public TacUser getUserForTacDeletion(String olm) {
		TacUser user = new TacUser();
		Connection con = data.getConnection();
		try {

			String sql = "select * from tacdeluser where olm_id=?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				user.setEmail(rs.getString("email"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else if(rs.getInt("mgr_status") == 2){
					user.setMgr_status("Rejected");
				}
				if (rs.getInt("tac_status") == 1) {
					user.setTac_status("Approved");
				} else if (rs.getInt("tac_status") == 2) {
					user.setTac_status("Rejected");
				} else if (rs.getInt("tac_status") == 3) {
					user.setTac_status("In Progress");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				user.setTac_time(rs.getString("tac_time"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	public MplsUser getUserForMplsDeletion(String olm) {
		MplsUser user = new MplsUser();
		Connection con = data.getConnection();
		try {

			String sql = "select * from mplsdeluser where olm_id=?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				user.setEmail(rs.getString("email"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else if(rs.getInt("mgr_status") == 2){
					user.setMgr_status("Rejected");
				}
				if (rs.getInt("mpls_status") == 1) {
					user.setMpls_status("Approved");
				} else if (rs.getInt("mpls_status") == 2) {
					user.setMpls_status("Rejected");
				} else if (rs.getInt("mpls_status") == 3) {
					user.setMpls_status("In Progress");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				user.setMpls_time(rs.getString("mpls_time"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return user;
	}

	
	public boolean updateTacUserDelForManager(int status, String olm) {
		Connection con = data.getConnection();

		try {
			String sql = "update tacdeluser set  mgr_status=?,mgr_time=? where mgr_olm_id=?";
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);

			psmt.setInt(1, status);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.executeUpdate();
			con.commit();
			System.out.println("commited");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}
	public boolean updateMplsUserDelForManager(int status, String olm) {
		Connection con = data.getConnection();

		try {
			String sql = "update mplsdeluser set  mgr_status=?,mgr_time=? where mgr_olm_id=?";
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);

			psmt.setInt(1, status);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, olm);
			psmt.executeUpdate();
			con.commit();
			System.out.println("commited");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}


	public boolean updateTacUserDelForSystem(String status, String olm,
			String sysname, String ticket) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update tacdeluser set tac_status = ?,tac_time = ? ,tac_name = ? ,ticket = ?where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, sysname);
			psmt.setString(4, ticket);
			psmt.setString(5, olm);
			psmt.executeUpdate();
			System.out.println("status update in tacdeluser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}

	public boolean updateMplsUserDelForSystem(String status, String olm,
			String sysname, String ticket) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update mplsdeluser set mpls_status = ?,mpls_time = ? ,mpls_name = ? ,ticket = ?where olm_id = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, sysname);
			psmt.setString(4, ticket);
			psmt.setString(5, olm);
			psmt.executeUpdate();
			System.out.println("status update in mplsdeluser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}

	
	public boolean enterTacPwdreset(String uid, TacUser user) {
		Connection con;
		con = data.getConnection();
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		String query = "insert into tacpwduser (uid,olm_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,desg,email)values(?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, uid);
			psmt.setString(2, user.getOlm_id());
			psmt.setString(3, user.getRequest());
			psmt.setString(4, user.getUsType());
			psmt.setString(5, user.getUsBelong());
			psmt.setString(6, user.getPurpose());
			psmt.setString(7, user.getAcReqType());
			psmt.setString(8, user.getDept());
			psmt.setString(9, user.getMgrname());
			psmt.setString(10, mgr_olmid);
			psmt.setString(11, user.getDesig());
			psmt.setString(12, user.getEmail());
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();

			} catch (Exception e1) {
				e1.printStackTrace();

			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;

	}

	
	public List<TacUser> getAllTacPwdReset(int status, String id) {

		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacpwduser where mgr_status =? && mgr_olm_id=?";

		try {
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setUid(rs.getString("uid"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else {
					user.setMgr_status("Rejected");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return list;

	}

	public List<MplsUser> getAllMplsPwdReset(int status, String id) {

		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplspwduser where mgr_status =? && mgr_olm_id=?";

		try {
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, status);
			psmt.setString(2, id);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setUid(rs.getString("uid"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else {
					user.setMgr_status("Rejected");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return list;

	}
	
	public TacUser getTacPwdReset(String id) {
		TacUser user = new TacUser();
		Connection con = data.getConnection();
		try {

			String sql = "select * from tacpwduser where uid=?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				user.setUid(rs.getString("uid"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				user.setEmail(rs.getString("email"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else if (rs.getInt("mgr_status") == 2) {
					user.setMgr_status("Rejected");
				}
				if (rs.getInt("tac_status") == 1) {
					user.setTac_status("Approved");
				} else if (rs.getInt("tac_status") == 2) {
					user.setTac_status("Rejected");
				} else if (rs.getInt("tac_status") == 3) {
					user.setTac_status("In Progress");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				user.setTac_time(rs.getString("tac_time"));
				user.setPwd(rs.getString("pwd"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return user;

	}
//////////////////////////////////////////////////////
	
	public MplsUser getMplsPwdReset(String id) {
		MplsUser user = new MplsUser();
		Connection con = data.getConnection();
		try {

			String sql = "select * from mplspwduser where uid=?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				user.setUid(rs.getString("uid"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				user.setEmail(rs.getString("email"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else if (rs.getInt("mgr_status") == 2) {
					user.setMgr_status("Rejected");
				}
				if (rs.getInt("mpls_status") == 1) {
					user.setMpls_status("Approved");
				} else if (rs.getInt("mpls_status") == 2) {
					user.setMpls_status("Rejected");
				} else if (rs.getInt("mpls_status") == 3) {
					user.setMpls_status("In Progress");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				user.setMpls_time(rs.getString("mpls_time"));
				user.setPwd(rs.getString("pwd"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return user;

	}
	//////////////////////////////////////////////

	public boolean approvalTacPwdResetmgr(String uid, int status, String olm) {
		Connection con = data.getConnection();

		try {
			String sql = "update tacpwduser set  mgr_status=?,mgr_time=? where uid=?";
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);

			psmt.setInt(1, status);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, uid);
			psmt.executeUpdate();
			con.commit();
			System.out.println("commited");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}
////////////////////////////////////////////////////////

	public boolean approvalMplsPwdResetmgr(String uid, int status, String olm) {
		Connection con = data.getConnection();

		try {
			String sql = "update mplspwduser set  mgr_status=?,mgr_time=? where uid=?";
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);

			psmt.setInt(1, status);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, uid);
			psmt.executeUpdate();
			con.commit();
			System.out.println("commited");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}
	////////////////////////////////////////////////

	public List<TacUser> getAllTacPwdSystem(int mst, int sst) {

		List<TacUser> list = new ArrayList<TacUser>();
		Connection con = data.getConnection();
		String sql = "select * from tacpwduser where mgr_status =? && tac_status=?";

		try {
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, mst);
			psmt.setInt(2, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				TacUser user = new TacUser();
				user.setUid(rs.getString("uid"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else {
					user.setMgr_status("Rejected");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return list;

	}

	public List<MplsUser> getAllMplsPwdSystem(int mst, int sst) {

		List<MplsUser> list = new ArrayList<MplsUser>();
		Connection con = data.getConnection();
		String sql = "select * from mplspwduser where mgr_status =? && mpls_status=?";

		try {
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, mst);
			psmt.setInt(2, sst);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				MplsUser user = new MplsUser();
				user.setUid(rs.getString("uid"));
				user.setOlm_id(rs.getString("olm_id"));
				user.setRequest(rs.getString("request"));
				user.setUsType(rs.getString("usr_type"));
				user.setUsBelong(rs.getString("u_belong"));
				user.setPurpose(rs.getString("purpose"));
				user.setAcReqType(rs.getString("access_req"));
				user.setDept(rs.getString("dept"));
				user.setMgrname(rs.getString("mgr_name"));
				user.setEmail(rs.getString("email"));
				user.setMgr_olm(rs.getString("mgr_olm_id"));
				user.setDesig(rs.getString("desg"));
				if (rs.getInt("mgr_status") == 1) {
					user.setMgr_status("Approved");
				} else {
					user.setMgr_status("Rejected");
				}

				user.setMgr_time(rs.getString("mgr_time"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return list;

	}

	
	public boolean updateTacUserPwdResetSystem(String status, String uid,
			String name, String ticket, String pwd) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update tacpwduser set tac_status = ?,tac_time = ? ,tac_name = ? ,ticket = ?,pwd=? where uid = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, name);
			psmt.setString(4, ticket);
			psmt.setString(5, pwd);
			psmt.setString(6, uid);
			psmt.executeUpdate();
			System.out.println("status update in tacpwduser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}

	public boolean updateMplsUserPwdResetSystem(String status, String uid,
			String name, String ticket, String pwd) {

		Connection con = null;
		int i;
		if (status.equals("rejected")) {
			i = 2;
		} else if (status.equals("approve"))
			i = 1;
		else
			i = 3;
		try {

			con = data.getConnection();
			con.setAutoCommit(false);
			String query = "update mplspwduser set mpls_status = ?,mpls_time = ? ,mpls_name = ? ,ticket = ?,pwd=? where uid = ?";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, i);
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(2, timestamp);
			psmt.setString(3, name);
			psmt.setString(4, ticket);
			psmt.setString(5, pwd);
			psmt.setString(6, uid);
			psmt.executeUpdate();
			System.out.println("status update in mplspwduser table");
			con.commit();
			return true;
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

	}
	
	public boolean checkUidForTacSystem(String uid) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from tacpwduser where uid = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, uid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("uid");
			}
			if (olm.equals(uid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}

	
	public boolean checkForTacDelSystem(String olm_id) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from tacdeluser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm_id);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(olm_id)) {
				System.out.println("if block when olm found");
				String olmid = " ";
				String query = "select * from tacdeluser where olm_id = ? &&(mgr_status = 2||tac_status=2)";
				psmt = con.prepareStatement(query);
				psmt.setString(1, olm);
				rs = psmt.executeQuery();
				while (rs.next()) {

					olmid = rs.getString("userolm_id");
				}
				if (olm.equals(olmid)) {
					System.out.println("olm found but pending ");
					String query1 = "delete  from tacdeluser where olm_id = ?";
					psmt = con.prepareStatement(query1);
					psmt.setString(1, olm);
					psmt.executeUpdate();
					con.commit();
					return false;

				} else {
					System.out
							.println("Inside else block when olmid already present");
					return true;
				}

			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}

	
	
	public boolean checkForTacCreationSystem(String olm_id) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from tacuser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm_id);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(olm_id)) {
				System.out.println("if block when olm found");
				String olmid = " ";
				String query = "select * from tacuser where olm_id = ? &&(mgr_status = 2||hod_status=2||tac_status=2)";
				psmt = con.prepareStatement(query);
				psmt.setString(1, olm);
				rs = psmt.executeQuery();
				while (rs.next()) {

					olmid = rs.getString("olm_id");
				}
				if (olm.equals(olmid)) {
					System.out.println("olm found but pending ");
					String query1 = "delete from tacuser where olm_id = ?";
					psmt = con.prepareStatement(query1);
					psmt.setString(1, olm);
					psmt.executeUpdate();
					con.commit();
					return false;

				} else {
					System.out
							.println("Inside else block when olmid already present");
					return true;
				}

			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}

	public boolean checkForMplsCreationSystem(String olm_id) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from mplsuser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm_id);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(olm_id)) {
				System.out.println("if block when olm found");
				String olmid = " ";
				String query = "select * from mplsuser where olm_id = ? &&(mgr_status = 2||hod_status=2||mpls_status=2)";
				psmt = con.prepareStatement(query);
				psmt.setString(1, olm);
				rs = psmt.executeQuery();
				while (rs.next()) {

					olmid = rs.getString("olm_id");
				}
				if (olm.equals(olmid)) {
					System.out.println("olm found but pending ");
					String query1 = "delete from mplsuser where olm_id = ?";
					psmt = con.prepareStatement(query1);
					psmt.setString(1, olm);
					psmt.executeUpdate();
					con.commit();
					return false;

				} else {
					System.out
							.println("Inside else block when olmid already present");
					return true;
				}

			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}

	
	public boolean checkForTacModSystem(String olm_id) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from tacmoduser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm_id);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(olm_id)) {
				System.out.println("if block when olm found");
				String olmid = " ";
				String query = "select * from tacmoduser where olm_id = ? &&(mgr_status = 2||hod_status=2||tac_status=2)";
				psmt = con.prepareStatement(query);
				psmt.setString(1, olm);
				rs = psmt.executeQuery();
				while (rs.next()) {

					olmid = rs.getString("olm_id");
				}
				if (olm.equals(olmid)) {
					System.out.println("olm found but pending ");
					String query1 = "delete from tacmoduser where olm_id = ?";
					psmt = con.prepareStatement(query1);
					psmt.setString(1, olm);
					psmt.executeUpdate();
					con.commit();
					return false;

				} else {
					System.out
							.println("Inside else block when olmid already present");
					return true;
				}

			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}


	public boolean addAndDeleteForTacModSystem(String olm) {

		Connection con = data.getConnection();
		String sql = "insert into tacpremoduser (select * from tacmoduser where olm_id = ?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			con.commit();
			Connection conn = data.getConnection();
			String sql1 = " delete from tacmoduser where olm_id = ?";
			psmt = conn.prepareStatement(sql1);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			conn.commit();

		} catch (Exception e) {

			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return true;

	}

	public boolean checkIdForTacCreationSystem(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from tacuser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	
	public boolean checkIdForMplsCreationSystem(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from mplsuser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	
	public boolean checkIdForTacModificationSystem(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from tacmoduser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	public boolean checkIdForMplsModificationSystem(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from mplsmoduser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	
	
	
	public boolean checkIdForTaDeletionSystem(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from tacdeluser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}


	public boolean checkIdForMplsDeletionSystem(String oid) {
		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from mplsdeluser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, oid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(oid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;
	}

	
	public String findMgrEmailId(String dept, String mgr) {
		Connection con = null;
		String email = "";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "select * from manager where mgr_fullname = ? && department like ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, mgr);
			psmt.setString(2, "%" + dept + "%");
			rs = psmt.executeQuery();

			while (rs.next()) {
				email = rs.getString("email_id");

			}
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return email;
	}

	public String findHodId(String olm, String table) {
		Connection con = null;
		String hod_id = "";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "select * from " + table + " where olm_id = ? ";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);

			rs = psmt.executeQuery();

			while (rs.next()) {
				hod_id = rs.getString("hod_olm_id");

			}
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return hod_id;
	}

	public String findHodEmailId(String olm) {
		Connection con = null;
		String email = "";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			String sql = "select * from manager where olm_id = ? ";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);

			rs = psmt.executeQuery();

			while (rs.next()) {
				email = rs.getString("email_id");

			}
			data.closeConnection();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return email;
	}

	

/////////////////////////////////////////////////////////////////////////////////////////////////////

	
	public boolean checkForMplsModSystem(String olm_id) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from mplsmoduser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm_id);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(olm_id)) {
				System.out.println("if block when olm found");
				String olmid = " ";
				String query = "select * from mplsmoduser where olm_id = ? &&(mgr_status = 2||hod_status=2||mpls_status=2)";
				psmt = con.prepareStatement(query);
				psmt.setString(1, olm);
				rs = psmt.executeQuery();
				while (rs.next()) {

					olmid = rs.getString("olm_id");
				}
				if (olm.equals(olmid)) {
					System.out.println("olm found but pending ");
					String query1 = "delete from mplsmoduser where olm_id = ?";
					psmt = con.prepareStatement(query1);
					psmt.setString(1, olm);
					psmt.executeUpdate();
					con.commit();
					return false;

				} else {
					System.out
							.println("Inside else block when olmid already present");
					return true;
				}

			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}

	
	public boolean addAndDeleteForMplsModSystem(String olm) {

		Connection con = data.getConnection();
		String sql = "insert into mplspremoduser (select * from mplsmoduser where olm_id = ?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			String sql1 = " delete from mplsmoduser where olm_id = ?";
			psmt = con.prepareStatement(sql1);
			psmt.setString(1, olm);
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {

			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();

		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return true;

	}
	
	
	public boolean submitMplsModifiedReq(MplsUser user) {
		Connection con;
		con = data.getConnection();
		String hodid = "";
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		if (user.getRights().contains("Write"))
			hodid = getHodId(user.getHod());
		String query = "insert into mplsmoduser (olm_id,ref_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,rights,hod_name,hod_olm_id,vendor,fname,lname,locn,cno,email,desg,host_name,ip,cat,summ,form_time)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, user.getRef_id());
			psmt.setString(3, user.getRequest());
			psmt.setString(4, user.getUsType());
			psmt.setString(5, user.getUsBelong());
			psmt.setString(6, user.getPurpose());
			psmt.setString(7, user.getAcReqType());
			psmt.setString(8, user.getDept());
			psmt.setString(9, user.getMgrname());
			psmt.setString(10, mgr_olmid);
			psmt.setString(11, user.getRights());
			psmt.setString(12, user.getHod());
			psmt.setString(13, hodid);
			psmt.setString(14, user.getVendor());
			psmt.setString(15, user.getFname());
			psmt.setString(16, user.getLname());
			psmt.setString(17, user.getLocation());
			psmt.setString(18, user.getContact());
			psmt.setString(19, user.getEmail());
			psmt.setString(20, user.getDesig());
			psmt.setString(21, user.getHost());
			psmt.setString(22, user.getIp());
			psmt.setString(23, user.getCat());
			psmt.setString(24, user.getSumm());
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					new java.util.Date().getTime());
			psmt.setTimestamp(25, timestamp);
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();
				return false;
			} catch (Exception e1) {
				e1.printStackTrace();
			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;
	}

	
	public boolean checkForMplsDelSystem(String olm_id) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from mplsdeluser where olm_id = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, olm_id);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("olm_id");
			}
			if (olm.equals(olm_id)) {
				System.out.println("if block when olm found");
				String olmid = " ";
				String query = "select * from mplsdeluser where olm_id = ? &&(mgr_status = 2||mpls_status=2)";
				psmt = con.prepareStatement(query);
				psmt.setString(1, olm);
				rs = psmt.executeQuery();
				while (rs.next()) {

					olmid = rs.getString("userolm_id");
				}
				if (olm.equals(olmid)) {
					System.out.println("olm found but pending ");
					String query1 = "delete  from mplsdeluser where olm_id = ?";
					psmt = con.prepareStatement(query1);
					psmt.setString(1, olm);
					psmt.executeUpdate();
					con.commit();
					return false;

				} else {
					System.out
							.println("Inside else block when olmid already present");
					return true;
				}

			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}

	
	public boolean submitMplsdeleteReq(MplsUser user) {
		Connection con;
		con = data.getConnection();
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		String query = "insert into mplsdeluser (olm_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,desg,email)values(?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, user.getOlm_id());
			psmt.setString(2, user.getRequest());
			psmt.setString(3, user.getUsType());
			psmt.setString(4, user.getUsBelong());
			psmt.setString(5, user.getPurpose());
			psmt.setString(6, user.getAcReqType());
			psmt.setString(7, user.getDept());
			psmt.setString(8, user.getMgrname());
			psmt.setString(9, mgr_olmid);
			psmt.setString(10, user.getDesig());
			psmt.setString(11, user.getEmail());
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();

			} catch (Exception e1) {
				e1.printStackTrace();

			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;
	}


	public boolean checkUidForMplsSystem(String uid) {

		Connection con = null;
		String olm = " ";
		try {
			con = data.getConnection();
			con.setAutoCommit(false);
			System.out.println("inside try block");
			String sql = "select * from mplspwduser where uid = ?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, uid);
			rs = psmt.executeQuery();
			while (rs.next()) {

				olm = rs.getString("uid");
			}
			if (olm.equals(uid)) {
				return true;
			} else {
				System.out.println("main else block");
				return false;
			}
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException ignored) {
				e.printStackTrace();
				return false;
			}

			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}
		return false;

	}


	public boolean enterMplsPwdreset(String uid, MplsUser user) {
		Connection con;
		con = data.getConnection();
		String mgr_olmid = getManagerId(user.getMgrname(), user.getDept());
		String query = "insert into mplspwduser (uid,olm_id,request,usr_type,u_belong,purpose,access_req,dept,mgr_name,mgr_olm_id,desg,email)values(?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			psmt.setString(1, uid);
			psmt.setString(2, user.getOlm_id());
			psmt.setString(3, user.getRequest());
			psmt.setString(4, user.getUsType());
			psmt.setString(5, user.getUsBelong());
			psmt.setString(6, user.getPurpose());
			psmt.setString(7, user.getAcReqType());
			psmt.setString(8, user.getDept());
			psmt.setString(9, user.getMgrname());
			psmt.setString(10, mgr_olmid);
			psmt.setString(11, user.getDesig());
			psmt.setString(12, user.getEmail());
			psmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			try {
				con.rollback();

			} catch (Exception e1) {
				e1.printStackTrace();

			}

			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
					con = null;
				}

			} catch (SQLException ignored) {
			}

		}

		return true;

	}

}



///////////////////////////////////////////////////////////////////////////////////////////////////////