package main.java.com.airtel.dao;

import java.util.List;

import main.java.com.airtel.model.Manager;

public interface IManagerDao {
	public boolean checkId(String id);
	public boolean addManager(Manager man);
	public Manager getMamagerDetails(String id);
	public List<Manager> getAllManagerList(int status);
	public boolean activeManager(String status,String olm);
	public boolean mgrPwdChange(String olm,String oldPwd,String newPwd);
	public int addMgrForEnteredAlready(String id);
	public boolean addManagerForRejected(Manager man,String olm);
	
	
}
