package main.java.com.airtel.service;

import java.util.List;

import main.java.com.airtel.dao.IManagerDao;
import main.java.com.airtel.dao.ManagerDao;
import main.java.com.airtel.model.Manager;

public class ManagerService implements IManagerService {
	IManagerDao mdao = new ManagerDao();

	public boolean submitManager(Manager manager) {
		return mdao.addManager(manager);

	}

	public boolean getOlm_id(String olm) {
		return mdao.checkId(olm);
	}

	public Manager getmanager(String id) {

		return mdao.getMamagerDetails(id);
	}

	public List<Manager> getAllManager(int status) {

		return mdao.getAllManagerList(status);
	}

	public boolean changeStatus(String status, String olm) {

		return mdao.activeManager(status, olm);
	}

	public boolean changeMgrPwd(String olm, String oldPwd, String newPwd) {

		return mdao.mgrPwdChange(olm, oldPwd, newPwd);
	}

	public int addMgrForActiveAndReject(String id) {

		return mdao.addMgrForEnteredAlready(id);
	}

	public boolean submitManagerForRejected(Manager manager, String olm) {
		return mdao.addManagerForRejected(manager, olm);

	}

}
