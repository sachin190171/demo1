package main.java.com.airtel.service;

import java.util.List;

import main.java.com.airtel.model.Manager;

public interface IManagerService {
	public boolean getOlm_id(String olm);
	public boolean submitManager(Manager manager);
	public Manager getmanager(String id);
	public List<Manager> getAllManager(int status);
	public boolean changeStatus (String status,String olm);
	public boolean changeMgrPwd(String olm,String oldPwd, String newPwd);
	public int addMgrForActiveAndReject(String Id);
	public boolean submitManagerForRejected(Manager manager,String olm);
}
