package main.java.com.airtel.service;

import java.util.List;

import main.java.com.airtel.dao.IUserDao;
import main.java.com.airtel.dao.UserDao;
import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.model.User;

public class UserService implements IUserService {

	IUserDao userDao = new UserDao();
	User user;

	public boolean addUser(NewUser user) {
		boolean b = userDao.submit(user);
		return b;

	}

	public List<NewUser> getMisData(String rfor, String from, String to) {
		return userDao.getAllMisData(rfor, from, to);

	}
	
	public List<NewUser> getMisData( String from, String to) {
		return userDao.getAllMisData(from, to);

	}
	
	public List<NewUser> getMisDataForPwd( String from, String to) {
		return userDao.getAllMisDataForPwd(from, to);

	}

	public void addUserInDeltionUser(NewUser user) {
		boolean b = userDao.add(user);

	}

	public boolean addUserInModification(NewUser user) {
		boolean b = userDao.addInModification(user);
		return b;

	}

	public boolean addUserInPasswordReset(NewUser user, String uuid) {
		boolean b = userDao.addInPassword(user, uuid);
		return b;

	}

	public User getUser(String uname, String pwd) {
		user = userDao.validUser(uname, pwd);
		return user;
	}

	public User getManager(String uname, String pwd) {
		user = userDao.validManager(uname, pwd);
		return user;
	}

	public boolean checkId(String id) {

		return userDao.validateId(id);
	}

	public boolean checkIdForModification(String id) {

		return userDao.validateIdForModification(id);
	}

	public boolean checkIdForUserDelete(String id) {

		return userDao.validateIdForUserDelete(id);
	}

	public boolean checkIdForUserPasswordReset(String id) {

		return userDao.validateIdForUserPassword(id);
	}

	public List<NewUser> getAllUser(int status, String id) {

		return userDao.getAllUserList(status, id);
	}

	///////////////////////
	public List<MplsUser> getAllMplsUser(int status, String id) {

		return userDao.getMplsUserList(status, id);
	}

	///////////////////////
	public List<NewUser> getAllUserListForPasswordReset(String id, int mgr_st) {

		return userDao.getAllUserListFromPassword(id, mgr_st);
	}
	public List<MplsUser> getMplsUserListForPasswordReset(String id, int mgr_st) {

		return userDao.getMplsUserListFromPassword(id, mgr_st);
	}

	public List<NewUser> getAllUserListForPasswordResetForSys(int sys,
			int mgr_st) {
		return userDao.getAllUserListFromPasswordForSys(sys, mgr_st);
	}

	public List<NewUser> getAllUserFromDeleted(int status, String id) {

		return userDao.getAllUserListFromDeleted(status, id);
	}
	public List<MplsUser> getMplsUserFromDeleted(int status, String id) {

		return userDao.getMplsUserListFromDeleted(status, id);
	}

	public List<NewUser> getAllUserFromModified(int status, String id) {

		return userDao.getAllUserListFromModified(status, id);
	}
	public List<MplsUser> getMplsUserFromModified(int status, String id) {

		return userDao.getMplsUserListFromModified(status, id);
	}

	public List<NewUser> getAllUserFromDeletedForSystem(int status, int id, int dst) {

		return userDao.getAllUserListFromDeletedForSystem(status, id, dst);
	}

	public NewUser getUserDetails(String id) {

		return userDao.getNewUser(id);
	}
	
	public MplsUser getMplsUserDetails(String id) {

		return userDao.getNewMplsUser(id);
	}
	public boolean checkIdForIdStatus(String id) {

		return userDao.validateIdForIdStatus(id);
	}
	
	public NewUser getUserStatusFromModification(String id) {

		return userDao.getNewUserForModification(id);
	}

	public NewUser getUserDetailsForDeletion(String id) {

		return userDao.getNewUserForDelete(id);
	}

	public NewUser getUserDetailsForModification(String id) {

		return userDao.getNewUserForModification(id);
	}

	public NewUser getUserDetailsForPasswordReset(String id) {

		return userDao.getNewUserForPasswordReset(id);
	}

	public void deleteExistingUserFromModification(NewUser user, String olm) {
		userDao.deleteAndEnter(user, olm);

	}

	public NewUser getUserDetailsForPasswordResetForManager(String id) {

		return userDao.getNewUserForPasswordResetByManager(id);
	}

	public boolean changeUserStatus(String status, String olm) {

		return userDao.activeUserByManager(status, olm);
	}

	public boolean changeUserStatusForDeletion(String status, String olm) {

		return userDao.deleteUserByManager(status, olm);
	}

	public boolean changeUserStatusForModification(String status, String olm) {

		return userDao.modifiedUserByManager(status, olm);
	}

	public List<NewUser> getAllUnactivatedUserForAdmin(int status, int MgrStatus) {

		return userDao.getAllUserListForAdmin(status, MgrStatus);
	}

	public List<NewUser> getAllModifiedUserForAdmin(int status, int MgrStatus) {

		return userDao.getModifiedUserListForAdmin(status, MgrStatus);
	}

	public boolean changeUserStatusForAdmin(String status, String olm,
			String name) {

		return userDao.activeUserByAdmin(status, olm, name);
	}

	public boolean modifiedUserStatusForAdmin(String status, String olm,
			String name) {

		return userDao.activeModifiedUserByAdmin(status, olm, name);
	}

	public List<NewUser> getAllUnactivatedUserForHelpDesk(int mgrStatus,
			int adStatus, int heStatus) {

		return userDao.getAllUserListForSystem(mgrStatus, adStatus, heStatus);
	}

	public List<NewUser> getAllModifiedUserForHelpDesk(int mgrStatus,
			int adStatus, int heStatus) {

		return userDao.getModifiedUserListForSystem(mgrStatus, adStatus,
				heStatus);
	}

	public boolean changeUserStatusForSystem(String status, String olm,
			String name,String nms,String rticket) {

		return userDao.activeUserBySystem(status, olm, name,nms,rticket);
	}

	public boolean changePasswordBySystem(String status, String olm,
			String name, int mgrst,String nms,String rticket,String password) {

		return userDao.changePassword(status, olm, name, mgrst,nms,rticket,password);
	}

	public boolean changePasswordByManager(String status, String olm,
			String uuid) {

		return userDao.changePasswordByManager(status, olm, uuid);
	}

	public boolean modifiedUserStatusForSystem(String status, String olm,
			String name,String nms,String rticket,String uuid) {

		return userDao.modifiedUserBySystem(status, olm, name,nms,rticket,uuid);
	}

	public boolean DeleteUserBySystem(String status, String olm, String name,String nms,String rticket) {

		return userDao.DeletedUserBySystem(status, olm, name,nms,rticket);
	}
	
	public boolean submitTacCreateRequest(TacUser user) {

		return userDao.submitTacCreReq(user);
	}

	public boolean submitMplsCreateRequest(MplsUser user) {

		return userDao.submitMplsCreReq(user);
	}
	
	
	public boolean submitTacModifiedRequest(TacUser user) {

		return userDao.submitTacModifiedReq(user);
	}

	
	public boolean submitTacDeletionRequest(TacUser user) {

		return userDao.submitTacdeleteReq(user);
	}

	
	public boolean checkTacUserOlm(String olm) {

		return userDao.checkTacUserOlmID(olm);
	}
	

	public boolean checkMplsUserOlm(String olm) {

		return userDao.checkMplsUserOlmID(olm);
	}

	
	public List<TacUser> getAllPendingTacCreation(int st, String id) {

		return userDao.getAllTacCrateUser(st, id);
	}


	
	public List<MplsUser> getAllPendingMplsCreation(int st, String id) {

		return userDao.getAllMplsCreateUser(st, id);
	}

	public List<MplsUser> getAllPendingMplsHODCreation(int st, String id) {

		return userDao.getAllMplsCreateHODUser(st, id);
	}
	public List<TacUser> getAllPendingTacCreationForAdmin(int st, String id) {

		return userDao.getAllTacCrateUser(st, id);
	}

	
	public List<TacUser> getAllPendingTacCreationForHOD(int st, String id,
			int hst, String table) {

		return userDao.getAllTacCrateUserForHOD(st, id, hst, table);
	}
	public List<MplsUser> getAllPendingMplsCreationForHOD(int st, String id,
			int hst, String table) {

		return userDao.getAllMplsCrateUserForHOD(st, id, hst, table);
	}

	
	public TacUser getUserForTacCreation(String olm, String table) {

		return userDao.getUser(olm, table);
	}
	public MplsUser getUserForMplsCreation(String olm, String table) {

		return userDao.getMplsUser(olm, table);
	}

	
	public boolean changeTacUserStatusForManager(String status, String olm,
			String name, String rights, String table) {

		return userDao
				.updateTacUserForManager(status, olm, name, rights, table);
	}


	public boolean changeMplsUserStatusForManager(String status, String olm,
			String name, String rights, String table) {

		return userDao
				.updateMplsUserForManager(status, olm, name, rights, table);
	}

	
	public boolean changeTacUserStatusForHOD(String status, String olm,
			String name, String table) {

		return userDao.updateTacUserForHOD(status, olm, name, table);
	}

	public boolean changeMplsUserStatusForHOD(String status, String olm,
			String name, String table) {

		return userDao.updateMplsUserForHOD(status, olm, name, table);
	}

	
	public List<TacUser> getAllPendingTacCreationForSystem(int st, int hid,
			int sst) {
		return userDao.getAllTacCrateUserForSystem(st, hid, sst);
	}

	public List<MplsUser> getAllPendingMplsCreationForSystem(int st, int hid,
			int sst) {
		return userDao.getAllMplsCrateUserForSystem(st, hid, sst);
	}
	
	public boolean changeTacUserStatusForSystem(String status, String olm,
			String name, String ticket,String pwd) {

		return userDao.updateTacUserForSystem(status, olm, name, ticket,pwd);
	}
	public boolean changeMplsUserStatusForSystem(String status, String olm,
			String name, String ticket,String pwd) {

		return userDao.updateMplsUserForSystem(status, olm, name, ticket,pwd);
	}

	
	public List<TacUser> getAllPendingTacModification(int st, String id) {
		return userDao.getAllTacModification(st, id);

	}
	public List<MplsUser> getAllPendingMplsModification(int st, String id) {
		return userDao.getAllMplsModification(st, id);

	}
	
	
	public List<TacUser> getAllPendingTacDeletion(int st, String id) {
		return userDao.getAllTacDeletion(st, id);

	}

	
	public List<MplsUser> getAllPendingMplsDeletion(int st, String id) {
		return userDao.getAllMplsDeletion(st, id);

	}

	
	public List<TacUser> getAllPendingTacModificationForSystem(int st, int hid,
			int sst) {
		return userDao.getAllTacModificationSystem(st, hid, sst);

	}
	

	public List<MplsUser> getAllPendingMplsModificationForSystem(int st, int hid,
			int sst) {
		return userDao.getAllMplsModificationSystem(st, hid, sst);

	}

	
	public boolean changeTacUserModStatusForSystem(String status, String olm,
			String name, String ticket,String pwd) {

		return userDao.updateTacUserModForSystem(status, olm, name, ticket,pwd);
	}
	public boolean changeMplsUserModStatusForSystem(String status, String olm,
			String name, String ticket,String pwd) {

		return userDao.updateMplsUserModForSystem(status, olm, name, ticket,pwd);
	}
	
	public boolean changeTacUserDelStatusForSystem(String status, String olm,
			String name, String ticket) {

		return userDao.updateTacUserDelForSystem(status, olm, name, ticket);
	}

	public boolean changeMplsUserDelStatusForSystem(String status, String olm,
			String name, String ticket) {

		return userDao.updateMplsUserDelForSystem(status, olm, name, ticket);
	}
	
	public TacUser getUserForTacDeletion(String olm) {

		return userDao.getUserForTacDeletion(olm);
	}

	public MplsUser getUserForMplsDeletion(String olm) {

		return userDao.getUserForMplsDeletion(olm);
	}
	
	public boolean updateTacUserDelForManager(String olm, int status) {

		return userDao.updateTacUserDelForManager(status, olm);
	}

	public boolean updateMplsUserDelForManager(String olm, int status) {

		return userDao.updateMplsUserDelForManager(status, olm);
	}

	
	public boolean getUserForTacDeletion(int status, String olm) {

		return false;
	}

	
	public List<TacUser> getAllPendingTacDeletionForSystem(int st, int sst) {
		return userDao.getAllTacDeletionSystem(st, sst);
	}

	public List<MplsUser> getAllPendingMplsDeletionForSystem(int st, int sst) {
		return userDao.getAllMplsDeletionSystem(st, sst);
	}

	
	public boolean submitTacPwdResetRequest(String uid, TacUser user) {
		return userDao.enterTacPwdreset(uid, user);
	}

	
	public List<TacUser> getAllPendingTacPwdReset(int status, String id) {

		return userDao.getAllTacPwdReset(status, id);
	}

	public List<MplsUser> getAllPendingMplsPwdReset(int status, String id) {

		return userDao.getAllMplsPwdReset(status, id);
	}

	
	public TacUser getUserForTacPwdReset(String uid) {

		return userDao.getTacPwdReset(uid);
	}
	

	public MplsUser getUserForMplsPwdReset(String uid) {

		return userDao.getMplsPwdReset(uid);
	}

	
	public boolean approvalTacPwdForManager(String uid, int status, String olm) {

		return userDao.approvalTacPwdResetmgr(uid, status, olm);
	}
	
	public boolean approvalMplsPwdForManager(String uid, int status, String olm) {

		return userDao.approvalMplsPwdResetmgr(uid, status, olm);
	}

	
	public List<TacUser> getAllPendingTacPwdForSystem(int mst, int sst) {

		return userDao.getAllTacPwdSystem(mst, sst);
	}

	public List<MplsUser> getAllPendingMplsPwdForSystem(int mst, int sst) {

		return userDao.getAllMplsPwdSystem(mst, sst);
	}

	
	public boolean updateTacUserPwdResetStatusForSystem(String status,
			String olm, String name, String ticket,String pwd) {

		return userDao.updateTacUserPwdResetSystem(status, olm, name, ticket,pwd);
	}

	public boolean updateMplsUserPwdResetStatusForSystem(String status,
			String olm, String name, String ticket,String pwd) {

		return userDao.updateMplsUserPwdResetSystem(status, olm, name, ticket,pwd);
	}
	
	public boolean checkUidForTacPwd(String uid) {

		return userDao.checkUidForTacSystem(uid);
	}
	

	
	public boolean checkUidForTacDel(String uid) {

		return userDao.checkForTacDelSystem(uid);
	}

	
	public boolean checkForTacCreation(String olm) {

		return userDao.checkForTacCreationSystem(olm);
	}
	

	public boolean checkForMplsCreation(String olm) {

		return userDao.checkForMplsCreationSystem(olm);
	}

	
	public boolean checkForTacModification(String olm) {

		return userDao.checkForTacModSystem(olm);
	}

	
	public boolean addanddeleteUserModTac(String olm) {
		
		return userDao.addAndDeleteForTacModSystem(olm);
	}
	
	
	public boolean checkIdForTacCreation(String olm) {

		return userDao.checkIdForTacCreationSystem(olm);
	}

	public boolean checkIdForMplsCreation(String olm) {

		return userDao.checkIdForMplsCreationSystem(olm);
	}
	public boolean checkIdForTacModification(String olm) {
		
		return userDao.checkIdForTacModificationSystem(olm);
	}
public boolean checkIdForMplsModification(String olm) {
		
		return userDao.checkIdForMplsModificationSystem(olm);
	}
	
	public boolean checkIdForTacDeletion(String olm) {
		
		return userDao.checkIdForTaDeletionSystem(olm);
	}

public boolean checkIdForMplsDeletion(String olm) {
		
		return userDao.checkIdForMplsDeletionSystem(olm);
	}

	
	public String getMgrEmailId(String dept, String mgr) {
		return userDao.findMgrEmailId(dept,mgr);
	}

/////////////////////////////////////////////////////////////////////////////////
	
	public boolean checkForMplsModification(String olm) {

		return userDao.checkForMplsModSystem(olm);
	}
	
	public boolean checkUidForMplsPwd(String uid) {

		return userDao.checkUidForMplsSystem(uid);
	}

	
	public boolean checkUidForMplsDel(String uid) {

		return userDao.checkForMplsDelSystem(uid);
	}
	
	public boolean addanddeleteUserModMpls(String olm) {
		
		return userDao.addAndDeleteForMplsModSystem(olm);
	}

	
	public boolean submitMplsModifiedRequest(MplsUser user) {

		return userDao.submitMplsModifiedReq(user);
	}

	
	public boolean submitMplsDeletionRequest(MplsUser user) {

		return userDao.submitMplsdeleteReq(user);
	}

	
	public boolean submitMplsPwdResetRequest(String uid, MplsUser user) {
		return userDao.enterMplsPwdreset(uid, user);
	}

	
}
