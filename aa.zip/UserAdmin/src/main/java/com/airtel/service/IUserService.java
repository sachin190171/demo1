package main.java.com.airtel.service;

import java.util.List;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.model.User;

public interface IUserService {

	public List<NewUser> getMisData(String action, String from, String to);

	public List<NewUser> getMisData(String from, String to);

	public List<NewUser> getMisDataForPwd(String from, String to);

	public boolean addUser(NewUser user);

	public void addUserInDeltionUser(NewUser user);

	public boolean addUserInModification(NewUser user);

	public boolean addUserInPasswordReset(NewUser user, String uuid);

	public User getUser(String uname, String pwd);

	public boolean checkId(String id);

	public boolean checkIdForModification(String id);

	public boolean checkIdForUserDelete(String id);

	public boolean checkIdForUserPasswordReset(String id);

	public User getManager(String uname, String pwd);

	public List<NewUser> getAllUser(int status, String id);

	public List<MplsUser> getAllMplsUser(int status, String id);

	public List<NewUser> getAllUserListForPasswordReset(String olm, int mgr_st);

	public List<MplsUser> getMplsUserListForPasswordReset(String olm, int mgr_st);

	public List<NewUser> getAllUserListForPasswordResetForSys(int sys,
			int mgr_st);

	public List<NewUser> getAllUserFromDeleted(int status, String id);

	public List<MplsUser> getMplsUserFromDeleted(int status, String id);

	public List<NewUser> getAllUserFromModified(int status, String id);

	public List<MplsUser> getMplsUserFromModified(int status, String id);

	public List<NewUser> getAllUserFromDeletedForSystem(int status, int id, int dst);

	public List<NewUser> getAllUnactivatedUserForAdmin(int status, int MgrStatus);

	public List<NewUser> getAllModifiedUserForAdmin(int status, int MgrStatus);

	public void deleteExistingUserFromModification(NewUser user, String olm);

	public NewUser getUserDetails(String id);

	public MplsUser getMplsUserDetails(String id);

	public boolean checkIdForIdStatus(String id);

	public NewUser getUserStatusFromModification(String id);

	public NewUser getUserDetailsForModification(String id);

	public NewUser getUserDetailsForPasswordReset(String id);

	public NewUser getUserDetailsForPasswordResetForManager(String id);

	public NewUser getUserDetailsForDeletion(String id);

	public boolean changeUserStatus(String status, String olm);

	public boolean changeUserStatusForDeletion(String status, String olm);

	public boolean changeUserStatusForModification(String status, String olm);

	public boolean changeUserStatusForAdmin(String status, String olm,
			String name);

	public boolean modifiedUserStatusForAdmin(String status, String olm,
			String name);

	public boolean changeUserStatusForSystem(String status, String olm,
			String name, String nms,String rticket);

	public boolean changePasswordBySystem(String status, String olm,
			String name, int mgrst, String nms,String remedyticket,String password);

	public boolean changePasswordByManager(String status, String olm,
			String uuid);

	public boolean modifiedUserStatusForSystem(String status, String olm,
			String name, String nms,String rticket,String uuid);

	public boolean DeleteUserBySystem(String status, String olm, String name,
			String nms,String rticket);

	public List<NewUser> getAllUnactivatedUserForHelpDesk(int mgrStatus,
			int adStatus, int heStatus);

	public List<NewUser> getAllModifiedUserForHelpDesk(int mgrStatus,
			int adStatus, int heStatus);
	
	public boolean checkTacUserOlm(String olm);

	public boolean checkMplsUserOlm(String olm);

	
	public boolean submitTacCreateRequest(TacUser user);

	public boolean submitMplsCreateRequest(MplsUser user);

	
	public boolean submitTacModifiedRequest(TacUser user);

	public boolean submitTacDeletionRequest(TacUser user);

	public List<TacUser> getAllPendingTacCreation(int st, String id);

	public List<TacUser> getAllPendingTacModification(int st, String id);
	public List<MplsUser> getAllPendingMplsModification(int st, String id);

	public List<TacUser> getAllPendingTacDeletion(int st, String id);

	public List<MplsUser> getAllPendingMplsDeletion(int st, String id);

	public List<MplsUser> getAllPendingMplsCreation(int st, String id);

	public List<MplsUser> getAllPendingMplsHODCreation(int st, String id);

	public List<TacUser> getAllPendingTacCreationForHOD(int st, String id,
			int hst, String table);

	public List<MplsUser> getAllPendingMplsCreationForHOD(int st, String id,
			int hst, String table);

	public List<TacUser> getAllPendingTacCreationForSystem(int st, int hid,
			int sst);

	public List<MplsUser> getAllPendingMplsCreationForSystem(int st, int hid,
			int sst);

	
	public List<TacUser> getAllPendingTacModificationForSystem(int st, int hid,
			int sst);

	public List<MplsUser> getAllPendingMplsModificationForSystem(int st, int hid,
			int sst);

	public List<TacUser> getAllPendingTacDeletionForSystem(int st, int sst);

	public List<MplsUser> getAllPendingMplsDeletionForSystem(int st, int sst);

	public List<TacUser> getAllPendingTacCreationForAdmin(int st, String id);

	public TacUser getUserForTacCreation(String olm, String table);

	public MplsUser getUserForMplsCreation(String olm, String table);

	public TacUser getUserForTacDeletion(String olm);

	public MplsUser getUserForMplsDeletion(String olm);

	public boolean changeTacUserStatusForManager(String status, String olm,
			String name, String rights, String table);

	public boolean changeMplsUserStatusForManager(String status, String olm,
			String name, String rights, String table);

	
	public boolean changeTacUserStatusForHOD(String status, String olm,
			String name, String table);

	public boolean changeMplsUserStatusForHOD(String status, String olm,
			String name, String table);

	public boolean changeTacUserStatusForSystem(String status, String olm,
			String name, String ticket, String pwd);

	public boolean changeMplsUserStatusForSystem(String status, String olm,
			String name, String ticket, String pwd);

	public boolean changeTacUserModStatusForSystem(String status, String olm,
			String name, String ticket, String pwd);

	public boolean changeMplsUserModStatusForSystem(String status, String olm,
			String name, String ticket, String pwd);

	public boolean changeTacUserDelStatusForSystem(String status, String olm,
			String name, String ticket);

	public boolean changeMplsUserDelStatusForSystem(String status, String olm,
			String name, String ticket);

	public boolean updateTacUserDelForManager(String olm, int status);
	public boolean updateMplsUserDelForManager(String olm, int status);

	public boolean getUserForTacDeletion(int status, String olm);

	public boolean submitTacPwdResetRequest(String uid, TacUser user);

	public List<TacUser> getAllPendingTacPwdReset(int status, String id);

	public List<MplsUser> getAllPendingMplsPwdReset(int status, String id);

	public TacUser getUserForTacPwdReset(String uid);

	public MplsUser getUserForMplsPwdReset(String uid);

	public boolean approvalTacPwdForManager(String uid, int status, String olm);


	public boolean approvalMplsPwdForManager(String uid, int status, String olm);

	public List<TacUser> getAllPendingTacPwdForSystem(int mst, int sst);

	public List<MplsUser> getAllPendingMplsPwdForSystem(int mst, int sst);

	public boolean updateTacUserPwdResetStatusForSystem(String status,
			String olm, String name, String ticket, String pwd);

	public boolean updateMplsUserPwdResetStatusForSystem(String status,
			String olm, String name, String ticket, String pwd);

	public boolean checkUidForTacPwd(String uid);

	public boolean checkUidForTacDel(String uid);

	public boolean checkForTacCreation(String olm);

	public boolean checkForMplsCreation(String olm);

	
	public boolean checkIdForTacCreation(String olm);

	public boolean checkIdForMplsCreation(String olm);

	public boolean checkForTacModification(String olm);

	public boolean addanddeleteUserModTac(String olm);

	public boolean checkIdForTacModification(String olm);

	public boolean checkIdForMplsModification(String olm);

	public boolean checkIdForTacDeletion(String olm);

	public boolean checkIdForMplsDeletion(String olm);

	public String getMgrEmailId(String dept, String mgr);
///////////////////////////////////////////////////////////////////////////////
	public boolean submitMplsPwdResetRequest(String uid, MplsUser user);

	public boolean checkForMplsModification(String olm);
	public boolean addanddeleteUserModMpls(String olm);
	public boolean checkUidForMplsDel(String uid);

	public boolean submitMplsModifiedRequest(MplsUser user);
	public boolean submitMplsDeletionRequest(MplsUser user);
	public boolean checkUidForMplsPwd(String uid);

	/////////////////////////////////////////////////////////////////
	
	
}
