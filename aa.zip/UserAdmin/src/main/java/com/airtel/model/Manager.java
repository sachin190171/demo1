package main.java.com.airtel.model;

public class Manager {
	

	String olmId;
	String firstName;
	String lastName;
	String emailId;
	String department;
	String password;
	String fullName;

	public String getOlmId() {
		return olmId;
	}

	public void setOlmId(String olmId) {
		this.olmId = olmId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {
		return "Manager [olmId=" + olmId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", emailId=" + emailId
				+ ", department=" + department + ", password=" + password + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((olmId == null) ? 0 : olmId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
	if(this.olmId==((Manager)obj).olmId)
		return false;
	else
		return true;
	}
	
	
}
