package main.java.com.airtel.model;

import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class Example implements Runnable {
	Example() {
	}

	public static void main(String[] args) {
		Example example = new Example();
		Thread th = new Thread(example);
		th.start();
	

		// System.out.println("result = " + scheduledFuture.get());

		// scheduledExecutorService.shutdown();
	}

	public void run() {

		ScheduledExecutorService scheduledExecutorService = Executors
				.newScheduledThreadPool(5);

		ScheduledFuture scheduledFuture = scheduledExecutorService.schedule(
				new Callable() {
					public Object call() throws Exception {
						System.out.println("Executed!");
						return "Called!";
					}
				}, 1, TimeUnit.SECONDS);
	}

}
