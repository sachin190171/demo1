package main.java.com.airtel.model;

public class MplsUser {

	String olm_id;
	String Ref_id;
	String request;
	String usType;
	String usBelong;
	String purpose;
	String acReqType;
	String dept;
	String mgrname;
	String rights;
	String hod;
	String vendor;
	String fname;
	String lname;
	String location;
	String contact;
	String email;
	String Desig;
	String host;
	String ip;
	String cat;
	String summ;
	String mgr_olm;
	String mgr_status;
	String mgr_time;
	String hod_status;
	String hod_time;
	String mpls_time;
	String mpls_status;
	String uid;
	String pwd;
	
	
	
	

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}


	public String getMpls_time() {
		return mpls_time;
	}

	public void setMpls_time(String mpls_time) {
		this.mpls_time = mpls_time;
	}

	public String getMpls_status() {
		return mpls_status;
	}

	public void setMpls_status(String mpls_status) {
		this.mpls_status = mpls_status;
	}

	public String getHod_status() {
		return hod_status;
	}

	public void setHod_status(String hod_status) {
		this.hod_status = hod_status;
	}

	public String getHod_time() {
		return hod_time;
	}

	public void setHod_time(String hod_time) {
		this.hod_time = hod_time;
	}

	public String getMgr_time() {
		return mgr_time;
	}

	public void setMgr_time(String mgr_time) {
		this.mgr_time = mgr_time;
	}

	public String getMgr_status() {
		return mgr_status;
	}

	public void setMgr_status(String mgr_status) {
		this.mgr_status = mgr_status;
	}

	public String getMgr_olm() {
		return mgr_olm;
	}

	public void setMgr_olm(String mgr_olm) {
		this.mgr_olm = mgr_olm;
	}

	public String getOlm_id() {
		return olm_id;
	}

	public void setOlm_id(String olm_id) {
		this.olm_id = olm_id;
	}

	public String getRef_id() {
		return Ref_id;
	}

	public void setRef_id(String ref_id) {
		Ref_id = ref_id;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getUsType() {
		return usType;
	}

	public void setUsType(String usType) {
		this.usType = usType;
	}

	public String getUsBelong() {
		return usBelong;
	}

	public void setUsBelong(String usBelong) {
		this.usBelong = usBelong;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getAcReqType() {
		return acReqType;
	}

	public void setAcReqType(String acReqType) {
		this.acReqType = acReqType;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getMgrname() {
		return mgrname;
	}

	public void setMgrname(String mgrname) {
		this.mgrname = mgrname;
	}

	public String getRights() {
		return rights;
	}

	public void setRights(String rights) {
		this.rights = rights;
	}

	public String getHod() {
		return hod;
	}

	public void setHod(String hod) {
		this.hod = hod;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDesig() {
		return Desig;
	}

	public void setDesig(String desig) {
		Desig = desig;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getSumm() {
		return summ;
	}

	public void setSumm(String summ) {
		this.summ = summ;
	}

}
