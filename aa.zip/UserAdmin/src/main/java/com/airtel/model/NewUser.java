package main.java.com.airtel.model;

public class NewUser {

	String uuid;
	String nms_id;
	String nms;
	String olm_id;
	String mgr_id;
	String mgr_status;
	String admin_status;
	String first_name;
	String last_name;
	String street_name;
	String state;
	String manager;
	String requestfor;
	String ustype;
	String user_id;
	String email_id;
	String c_number;
	String u_belongs;
	String ut_name;
	String vd_details;
	String designation;
	String purpose;
	String uName;
	String uPass;
	String Mail;
	String[] applicationAccess;
	String[] eci;
	String[] alcatel;
	String[] huawei;
	String[] ciena;
	String[] nortel;
	String[] tejas;
	String[] adr;
	String reason;
	String vendor;
	String help_status;
	String os;
	String helpname;
	String date;
	String mgr_date;
	String admin_date;
	String system_date;
	String rticket;
	String password;
	String ref_id;
	
	
	
	

	
	public String getRef_id() {
		return ref_id;
	}

	public void setRef_id(String ref_id) {
		this.ref_id = ref_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRticket() {
		return rticket;
	}

	public void setRticket(String rticket) {
		this.rticket = rticket;
	}

	public String getMgr_date() {
		return mgr_date;
	}

	public void setMgr_date(String mgr_date) {
		this.mgr_date = mgr_date;
	}

	public String getAdmin_date() {
		return admin_date;
	}

	public void setAdmin_date(String admin_date) {
		this.admin_date = admin_date;
	}

	public String getSystem_date() {
		return system_date;
	}

	public void setSystem_date(String system_date) {
		this.system_date = system_date;
	}

	public String getNms_id() {
		return nms_id;
	}

	public void setNms_id(String nms_id) {
		this.nms_id = nms_id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getHelpname() {
		return helpname;
	}

	public void setHelpname(String helpname) {
		this.helpname = helpname;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String getNms() {
		return nms;
	}

	public void setNms(String nms) {
		this.nms = nms;
	}

	public String getOlm_id() {
		return olm_id;
	}

	public void setOlm_id(String olm_id) {
		this.olm_id = olm_id;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getMgr_id() {
		return mgr_id;
	}

	public void setMgr_id(String mgr_id) {
		this.mgr_id = mgr_id;
	}

	public String getMgr_status() {
		return mgr_status;
	}

	public void setMgr_status(String mgr_status) {
		this.mgr_status = mgr_status;
	}

	public String getAdmin_status() {
		return admin_status;
	}

	public void setAdmin_status(String admin_status) {
		this.admin_status = admin_status;
	}

	public String[] getEci() {
		return eci;
	}

	public void setEci(String[] eci) {
		this.eci = eci;
	}

	public String[] getAlcatel() {
		return alcatel;
	}

	public void setAlcatel(String[] alcatel) {
		this.alcatel = alcatel;
	}

	public String[] getHuawei() {
		return huawei;
	}

	public void setHuawei(String[] huawei) {
		this.huawei = huawei;
	}

	public String[] getCiena() {
		return ciena;
	}

	public void setCiena(String[] ciena) {
		this.ciena = ciena;
	}

	public String[] getNortel() {
		return nortel;
	}

	public void setNortel(String[] nortel) {
		this.nortel = nortel;
	}

	public String[] getTejas() {
		return tejas;
	}

	public void setTejas(String[] tejas) {
		this.tejas = tejas;
	}

	public String[] getAdr() {
		return adr;
	}

	public void setAdr(String[] adr) {
		this.adr = adr;
	}

	public String[] getApplicationAccess() {
		return applicationAccess;
	}

	public void setApplicationAccess(String[] applicationAccess) {
		this.applicationAccess = applicationAccess;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getStreet_name() {
		return street_name;
	}

	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getRequestfor() {
		return requestfor;
	}

	public void setRequestfor(String requestfor) {
		this.requestfor = requestfor;
	}

	public String getUstype() {
		return ustype;
	}

	public void setUstype(String ustype) {
		this.ustype = ustype;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getC_number() {
		return c_number;
	}

	public void setC_number(String c_number) {
		this.c_number = c_number;
	}

	public String getU_belongs() {
		return u_belongs;
	}

	public void setU_belongs(String u_belongs) {
		this.u_belongs = u_belongs;
	}

	public String getUt_name() {
		return ut_name;
	}

	public void setUt_name(String ut_name) {
		this.ut_name = ut_name;
	}

	public String getVd_details() {
		return vd_details;
	}

	public void setVd_details(String vd_details) {
		this.vd_details = vd_details;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}
	

	public String getHelp_status() {
		return help_status;
	}

	public void setHelp_status(String help_status) {
		this.help_status = help_status;
	}

	public String getuPass() {
		return uPass;
	}

	public void setuPass(String uPass) {
		this.uPass = uPass;
	}

	public String getMail() {
		return Mail;
	}

	public void setMail(String mail) {
		Mail = mail;
	}

	

}
