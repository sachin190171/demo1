package main.java.com.airtel.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

public class User implements HttpSessionBindingListener{

	String uuid;
	String userName;
	String password;
	int role;
	int rm_status;

	public int getRm_status() {
		return rm_status;
	}

	public void setRm_status(int rm_status) {
		this.rm_status = rm_status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	private static Map<String, HttpSession> logins = new HashMap<String, HttpSession>();

	@Override
	public boolean equals(Object other) {
		return (other instanceof User) && (userName != null) ? userName
				.equals(((User) other).userName) : (other == this);
	}

	@Override
	public int hashCode() {
		return (userName != null) ? (this.getClass().hashCode() + userName
				.hashCode()) : super.hashCode();
	}

	
	public void valueBound(HttpSessionBindingEvent event) {
		User user = new User();
		HttpSession session = logins.remove(user.getUserName());
		System.out.println("inside user user name==>"+this.getUserName());
		if (session != null) {
			System.out.println("method call  in side here");
			session.invalidate();
		}
		System.out.println("value bound method call");
		logins.put(user.getUserName(), event.getSession());
		Set<String> set = logins.keySet();
		Iterator<String> itr = set.iterator();
		while(itr.hasNext())
		System.out.println("value of iteration=====>"+itr.next());

	}

	
	public void valueUnbound(HttpSessionBindingEvent arg0) {
		User user = new User();
		logins.remove(user.getUserName());

	}

}
