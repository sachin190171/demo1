package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

public class CheckUserApprovalController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	IUserService userService = new UserService();
	NewUser user = new NewUser();
	boolean b;

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession();
		System.out.println("CheckUserApproval controller called....");
		String olm = request.getParameter("olm");
		String status = request.getParameter("action");
		String tableName = request.getParameter("requestfor");
		System.out.println("status==>" + status);
		System.out.println("olm==>" + olm);
		if (olm == " ") {
			String str = "Please enter the olm id";
			request.setAttribute("error", str);
			System.out.println("inside if when olm is null");
			getServletContext().getRequestDispatcher("/checkstatus.jsp")
					.forward(request, response);
		}
		
		if(tableName==null){
			String str = "Please Select Respective Request Type...";
			request.setAttribute("errori", str);
			getServletContext().getRequestDispatcher("/checkstatus.jsp")
			.forward(request, response);
		}
		if (tableName.equals("Creation")) {
			boolean b = userService.checkIdForIdStatus(olm);
			if (b == true) {
				user = userService.getUserDetails(olm);
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/userApprovalView.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		if (tableName.equals("Modification")) {
			NewUser user = new NewUser();
			user = userService.getUserStatusFromModification(olm);
			System.out.println("value of user inside modification====>"
					+ user.getOlm_id());
			if (olm.equals(user.getOlm_id())) {
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/userApprovalView.jsp").forward(request,
						response);
			} else {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}

		}
		if (tableName.equals("Deletion")) {
			NewUser user = new NewUser();
			user = userService.getUserDetailsForDeletion(olm);
			System.out.println("value of user inside Deletion ====>"
					+ user.getOlm_id());
			if (olm.equals(user.getOlm_id())) {
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/userApprovalForDelete.jsp").forward(
						request, response);
			} else {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}

		}
		if (tableName.equals("Pwd")) {
			NewUser user = new NewUser();
			user = userService.getUserDetailsForPasswordReset(olm);
			System.out.println("value of user inside Password Reset ====>"
					+ user.getOlm_id());
			if (olm.equals(user.getUuid())) {
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/userApprovalForPassword.jsp").forward(
						request, response);
			} else {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}

		}
		if (tableName.equals("TACCreation")) {
			boolean b = userService.checkIdForTacCreation(olm);
			if (b == true) {
				TacUser user = userService.getUserForTacCreation(olm, "tacuser");
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewTacStatus.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		if (tableName.equals("TACModification")) {
			boolean b = userService.checkIdForTacModification(olm);
			if (b == true) {
				TacUser user = userService.getUserForTacCreation(olm, "tacmoduser");
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewTacStatus.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		if (tableName.equals("TACDeletion")) {
			boolean b = userService.checkIdForTacDeletion(olm);
			if (b == true) {
				TacUser user = userService.getUserForTacDeletion(olm);
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewTacUserDeletion.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		
		if (tableName.equals("TACPwd")) {
			boolean b = userService.checkUidForTacPwd(olm);
			if (b == true) {
				TacUser user = userService.getUserForTacPwdReset(olm);
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewTacUserPwdSystem.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}

		////////////////////////////////////////////// MPLS  STATUS /////////////////////////////
		if (tableName.equals("MPLSCreation")) {
			boolean b = userService.checkIdForMplsCreation(olm);
			if (b == true) {
				MplsUser user = userService.getUserForMplsCreation(olm, "mplsuser");
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewMplsStatus.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		if (tableName.equals("MPLSModification")) {
			boolean b = userService.checkIdForMplsModification(olm);
			if (b == true) {
				MplsUser user = userService.getUserForMplsCreation(olm, "mplsmoduser");
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewMplsStatus.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		if (tableName.equals("MPLSDeletion")) {
			boolean b = userService.checkIdForMplsDeletion(olm);
			if (b == true) {
				MplsUser user = userService.getUserForMplsDeletion(olm);
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewMplsUserDeletion.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		
		if (tableName.equals("MPLSPwd")) {
			boolean b = userService.checkUidForMplsPwd(olm);
			if (b == true) {
				MplsUser user = userService.getUserForMplsPwdReset(olm);
				request.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/checkAndViewMplsUserPwdSystem.jsp").forward(request,
						response);
			} else if (b == false) {
				String str = "Record not found...";
				request.setAttribute("errori", str);
				getServletContext().getRequestDispatcher("/checkstatus.jsp")
						.forward(request, response);
			}
		}
		
		///////////////////////////////////////////////////////////////////////
	}
}
