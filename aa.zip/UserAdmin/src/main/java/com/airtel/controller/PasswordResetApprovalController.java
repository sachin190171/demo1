package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;
import main.java.com.airtel.utility.StringUtility;

@WebServlet(urlPatterns = "/passwordresetsuccess")
public class PasswordResetApprovalController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("Password Reset Approval Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String remedyticket = request.getParameter("rticket");
		String password = request.getParameter("password");
		String name = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println("System help desk person name==>" + name);
		System.out.println(remedyticket);
		System.out.println(status);
		System.out.println(olmid);
		String nms = StringUtility.checkNUllForSpace(request
				.getParameter("eci"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("alcatel"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("huawei"))
				+ StringUtility
						.checkNUllForSpace(request.getParameter("ciena"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("nortel"))
				+ StringUtility
						.checkNUllForSpace(request.getParameter("tejas"))
				+ StringUtility.checkNUllForSpace(request.getParameter("adr"));
		String email = userService.getUserDetailsForPasswordResetForManager(olmid)
				.getEmail_id();
		String id = "A1CCAAWG";
		if (status.equals("approve")){
			b = userService.changePasswordBySystem(status, olmid, name, 1, nms,remedyticket,password);
			String msg = "Hi<br>";
			msg += "<br><b>Your NMS Password Reset Request has been Approved at System Level.  </b><br>";
			msg += "<br><b>To get any information regarding your request, contact System Team.  </b><br>";
			msg += "<br><b>Ph: 0124-4282445  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
		}
		if (status.equals("rejected")){
			userService.changePasswordBySystem(status, olmid, name, 1, nms,remedyticket,password);
			String msg = "Hi<br>";
			msg += "<br><b>Your NMS Password Reset Request has been Rejected at System Level.  </b><br>";
			msg += "<br><b>To get any information regarding your request, contact System Team.  </b><br>";
			msg += "<br><b>Ph: 0124-4282445  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
		}
		if (status.equals("progress")) {
			userService.changePasswordBySystem(status, olmid, name, 1, nms,remedyticket,password);
		}
		if (b == true) {
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUserListForPasswordReset(olmid, 1);
			if (listi.size() == 0)
				request.setAttribute("passwordrequest",
						"NO PENDING PASSWORD RESET USER REQUEST FOUND..");
			System.out.println(listi);
			request.setAttribute("pendingpasswordreset", listi);
			request.getRequestDispatcher("/WEB-INF/jsp/systemHelpDeskLogin.jsp")
					.forward(request, response);
		}
		if (b == false)
			request.getRequestDispatcher("/WEB-INF/jsp/systemHelpDeskLogin.jsp")
					.forward(request, response);
		System.out.println("some problem occur");
	}

}
