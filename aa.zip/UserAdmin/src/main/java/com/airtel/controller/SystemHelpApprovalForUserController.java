package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;
import main.java.com.airtel.utility.StringUtility;

public class SystemHelpApprovalForUserController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		String nms;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("SystemHelpApprovalForUser Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String caption = request.getParameter("action");
		String rticket = request.getParameter("rticket");
		String email = userService.getUserDetails(olmid).getEmail_id();
		String id = "A1CCAAWG";
		nms = StringUtility.checkNUllForSpace(request.getParameter("cen"))
				+ StringUtility.checkNUllForSpace(request.getParameter("eci"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("alcatel"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("huawei"))
				+ StringUtility
						.checkNUllForSpace(request.getParameter("ciena"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("nortel"))
				+ StringUtility
						.checkNUllForSpace(request.getParameter("tejas"))
				+ StringUtility.checkNUllForSpace(request.getParameter("adr"));

		String name = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println("System help desk person name==>" + name);
		System.out.println(caption);
		System.out.println(status);
		System.out.println(olmid);
		System.out.println("NMS VALUE IS =======>" + nms);
		if (status.equals("approve")) {

			System.out.println("NMS VALUE IS =======>" + nms);
			b = userService.changeUserStatusForSystem(status, olmid, name, nms,
					rticket);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation has been Approved on System level.  </b><br>";
			msg += "<br><b>To get any information regarding your request, contact System Team.  </b><br>";
			msg += "<br><b>Ph: 0124-4282445  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
		}
		if (status.equals("rejected")) {
			userService.changeUserStatusForSystem(status, olmid, name, nms,
					rticket);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation has been Rejected on System level.  </b><br>";
			msg += "<br><b>To get any information regarding your request, contact System Team.  </b><br>";
			msg += "<br><b>Ph: 0124-4282445  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
		}
		if (status.equals("progress")) {

			System.out.println("NMS VALUE IS =======>" + nms);
			userService.changeUserStatusForSystem(status, olmid, name, nms,
					rticket);
		}
		if (b == true) {
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUnactivatedUserForHelpDesk(1, 1, 0);
			System.out.println(listi);
			session.setAttribute("pending", listi);
			request.getRequestDispatcher("/WEB-INF/jsp/systemHelpDeskLogin.jsp")
					.forward(request, response);
		}
		if (b == false)
			request.getRequestDispatcher("/WEB-INF/jsp/systemHelpDeskLogin.jsp")
					.forward(request, response);
		System.out.println("some problem occur");
	}

}
