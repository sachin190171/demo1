package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/TacCreationUserForHod")
public class TacUserCreaForHodController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IManagerService managerService = new ManagerService();
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("Tac User CreaFor Hod Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		// String caption = request.getParameter("action");
		String adminName = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println(status);
		System.out.println(olmid);
		String id=(String)session.getAttribute("id");
		String to= userService.getUserForTacCreation(olmid, "tacuser").getEmail();
		
		if (status.equals("approve")){
			b = userService.changeTacUserStatusForHOD(status, olmid, adminName, "tacuser");
			
			
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation on TACACS has been Approved on HOD level. </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);
		//	String msg1 = "Hi<br>";
//			msg1 += "<br><b>You have a Tacacs Account Creation/Modification request in your bin. </b><br>";
//			msg1 += "<br>";
//			msg1 += "<br>Thank you";
//			msg1 += "<br>Portal Development Team";
//			msg1 += "<br>PH: 0124-4381378";
//			SendEmail.sendMail(email, msg1, id);
		}
		if (status.equals("rejected")){
			userService.changeTacUserStatusForHOD(status, olmid, adminName, "tacuser");
			
			
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation on TACACS has been Rejected on HOD level. </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);	
		}
		if (b == true) {
			List<TacUser> list = new ArrayList<TacUser>();
			list = userService.getAllPendingTacCreation(0, olmid);
			List<TacUser> list1 = new ArrayList<TacUser>();
			list1 = userService.getAllPendingTacCreationForHOD(1, olmid,0,"tacuser");
			if (list.size() == 0 && list1.size() == 0) {
				request.setAttribute("tacpending", "No Request Found......");
			}
			request.setAttribute("taclist", list);
			request.setAttribute("taclistforHod", list1);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
		}
		if (b == false) {
			System.out.println("some problem occured..");
			request.getRequestDispatcher("/WEB-INF/jsp/mgrSucsessLogin.jsp")
					.forward(request, response);
		}

	}

}
