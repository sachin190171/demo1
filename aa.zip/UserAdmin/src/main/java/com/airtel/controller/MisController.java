package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

@WebServlet(urlPatterns = "/getmisdetails")
public class MisController extends HttpServlet {

	private static final long serialVersionUID = 112L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		System.out.println("Mis controller called");
		HttpSession session = request.getSession(false);
		String action = request.getParameter("requestfor");
		String frmDate = request.getParameter("frmdate");
		String toDate = request.getParameter("todate");
		System.out.println(action);
		System.out.println(frmDate);
		System.out.println(toDate);
		if (action.equals("Deletion")) {
			List<NewUser> list = new ArrayList<NewUser>();
			list = userService.getMisData(frmDate, toDate);
			if(list.size()==0){
				request.setAttribute("error", "NO RECORD FOUND....");
			}
			request.setAttribute("deleted", list);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/misdetails.jsp").forward(request, response);

		}
		if (action.equals("Pwd")) {
			List<NewUser> list = new ArrayList<NewUser>();
			list = userService.getMisDataForPwd(frmDate, toDate);
			if(list.size()==0){
				request.setAttribute("error", "NO RECORD FOUND....");
			}
			request.setAttribute("password", list);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/misdetails.jsp").forward(request, response);

		}
		if (action.equals("Creation")) {
			List<NewUser> list = new ArrayList<NewUser>();
			list = userService.getMisData(action, frmDate, toDate);
			if(list.size()==0){
				request.setAttribute("error", "NO RECORD FOUND....");
			}
			request.setAttribute("creation", list);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/misdetails.jsp").forward(request, response);

		}
		if (action.equals("Modification")) {
			List<NewUser> list = new ArrayList<NewUser>();
			list = userService.getMisData(action, frmDate, toDate);
			if(list.size()==0){
				request.setAttribute("error", "NO RECORD FOUND....");
			}
			request.setAttribute("modified", list);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/misdetails.jsp").forward(request, response);

		}

	}
}
