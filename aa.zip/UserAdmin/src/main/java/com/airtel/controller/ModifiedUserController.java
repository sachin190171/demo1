package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/modifiedUserdetails")
public class ModifiedUserController extends HttpServlet {
	private static final long serialVersionUID = 1234L;
	NewUser nUser;
	PrintWriter out;
	IUserService userService = new UserService();

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		out = response.getWriter();
		// out.println("Invalid Login");
		System.out.println("User modification controller");
		String olm = request.getParameter("olmid");
		boolean flag = userService.checkIdForModification(olm);
		System.out.println("getting flag value ");
		nUser = mapUser(request, response);
		String email = userService.getMgrEmailId(nUser.getState(),
				request.getParameter("manager"));
		if (flag == true) {
			System.out.println("Duplicate Entry");
			System.out.println("inside delete and entered block");
			userService.deleteExistingUserFromModification(nUser, olm);
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your form has been Sucessfully submitted')");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			String msg = "Hi<br>";
			msg += "<br><b>You have a NMS Account Modification  request in your bin.  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, olm);
		//	request.setAttribute("error", "Your olm id is already registered");
			// getServletContext().getRequestDispatcher("/BasicLogin.jsp")
			// .forward(request, response);
		} else {
			
			boolean flag1 =userService.addUserInModification(nUser);
			if(flag1==true){
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your form has been Sucessfully submitted')");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			String msg = "Hi<br>";
			msg += "<br><b>You have a NMS Account Modification  request in your bin.  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, olm);

			System.out.println("User Entred successfully");
			}else{
				out.println("<html>");
				out.println("<head>");
				out.println("<script type = 'text/javascript'>");
				out.println("window.alert('Your form has not been submitted')");
				out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
				out.println("</script>");
				out.println("</head>");
				out.println("</html>");

				System.out.println("User Entred successfully");
			}
		}

	}

	public NewUser mapUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		NewUser user = new NewUser();
		user.setOlm_id(request.getParameter("olmid"));
		user.setRequestfor(request.getParameter("requestfor"));
		user.setUstype(request.getParameter("ustype"));
		user.setU_belongs(request.getParameter("u_belongs"));
		user.setPurpose(request.getParameter("purpose"));
		user.setState(request.getParameter("state"));
		user.setManager(request.getParameter("manager"));
		user.setVd_details(request.getParameter("vd_details"));
		user.setReason(request.getParameter("reason"));
		user.setOs(request.getParameter("os"));
		user.setEmail_id(request.getParameter("email_id"));
		user.setVendor(request.getParameter("vendor"));
		user.setFirst_name(request.getParameter("first_name"));
		user.setLast_name(request.getParameter("last_name"));
		user.setStreet_name(request.getParameter("street_name"));
		user.setC_number(request.getParameter("c_number"));
		user.setUt_name(request.getParameter("ut_name"));
		user.setDesignation(request.getParameter("designation"));
		user.setUuid(request.getParameter("first_name")
				+ request.getParameter("c_number"));
		user.setApplicationAccess(request.getParameterValues("app_access"));
		user.setEci(request.getParameterValues("eci"));
		user.setAlcatel(request.getParameterValues("alcatel"));
		user.setHuawei(request.getParameterValues("huawei"));
		user.setCiena(request.getParameterValues("ciena"));
		user.setNortel(request.getParameterValues("nortel"));
		user.setTejas(request.getParameterValues("tejas"));
		user.setAdr(request.getParameterValues("adr"));
		user.setUser_id(request.getParameter("user_id"));
		user.setRef_id(request.getParameter("ref_id"));

		System.out.println(user);

		return user;
	}

}
