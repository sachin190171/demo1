package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/createMpls")
public class MplsCreationController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	IUserService userservice = new UserService();

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("MPLS Creation Controller called");

		String olm = request.getParameter("olmid").trim();
		userservice.checkMplsUserOlm(olm);
		MplsUser user = mapUser(request, response);
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		boolean var = userservice.checkForMplsCreation(olm);
		
		String email = userservice.getMgrEmailId(user.getDept(),
				user.getMgrname());

		if (var == true) {
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your Olm id has already been registered')");
			out.println("setTimeout(function(){window.location.href='mplscreation.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			// getServletContext().getRequestDispatcher(
			// "/tacscreation.jsp").forward(request,
			// response);
		} else {
			if (user.getRights().contains("Write")) {
				String hod = user.getHod();
				System.out.println("hod name==>" + hod + "name");
				if (hod == "" || hod == null) {
					System.out.println("when HOD name is null");
					System.out.println("first if block");
					response.setContentType("text/html");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('HOD Name could not be Blank.')");
					out.println("setTimeout(function(){window.location.href='mplscreation.jsp'},20);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
					request.setAttribute("msg", "Please Select HOD Name.");
					// RequestDispatcher dispatch = getServletContext()
					// .getRequestDispatcher("/tacscreation.jsp");
					// dispatch.forward(request, response);
				} else {
					boolean val = userservice.checkMplsUserOlm(olm);
					if (val == false) {
						boolean flag = userservice.submitMplsCreateRequest(user);

						if (flag == true) {
							System.out.println("record insert");
							out.println("<html>");
							out.println("<head>");
							out.println("<script type = 'text/javascript'>");
							out.println("window.alert('Your request has been Submitted')");
							out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
							out.println("</script>");
							out.println("</head>");
							out.println("</html>");

							String msg = "Hi<br>";
							msg += "<br><b>You have a MPLS Account Creation request in your bin. </b><br>";
							msg += "<br><b>URL for Portal: </b>";
							msg += "<br><b>https://172.30.1.99:8443/UserAdmin/   ( Supported on Google Chrome with disabled proxy )  </b><br>";
							msg += "<br>";
							msg += "<br>Thank you";
							msg += "<br>Portal Development Team";
							msg += "<br>PH: 0124-4381378";
							SendEmail.sendMail(email, msg, olm);

//							getServletContext().getRequestDispatcher(
//									"/BasicLogin.jsp").forward(request,
//									response);
						} else {

							System.out.println("record not insert");
							out.println("<html>");
							out.println("<head>");
							out.println("<script type = 'text/javascript'>");
							out.println("window.alert('Your request has not been Submitted')");
							out.println("setTimeout(function(){window.location.href='mplscreation.jsp'},10);");
							out.println("</script>");
							out.println("</head>");
							out.println("</html>");
//							getServletContext().getRequestDispatcher(
//									"/tacscreation.jsp").forward(request,
//									response);
						}
					} else {
						out.println("<html>");
						out.println("<head>");
						out.println("<script type = 'text/javascript'>");
						out.println("window.alert('DUPLICATE OLMID')");
						out.println("setTimeout(function(){window.location.href='mplscreation.jsp'},10);");
						out.println("</script>");
						out.println("</head>");
						out.println("</html>");
					}
				}
			} else if (user.getRights().equals("Read")) {
				boolean flag = userservice.submitMplsCreateRequest(user);
				if (flag == true) {
					System.out.println("record insert");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('Your request has been Submitted')");
					out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");

					String msg = "Hi<br>";
					msg += "<br><b>You have a IP/MPLS Account Creation request in your bin. </b><br>";
					msg += "<br><b>URL for Portal: </b>";
					msg += "<br><b>https://172.30.1.99:8443/UserAdmin/   ( Supported on Google Chrome with disabled proxy )  </b><br>";
					msg += "<br>";
					msg += "<br>Thank you";
					msg += "<br>Portal Development Team";
					msg += "<br>PH: 0124-4381378";
					SendEmail.sendMail(email, msg, olm);
//					getServletContext().getRequestDispatcher("/BasicLogin.jsp")
//							.forward(request, response);
				} else {

					System.out.println("record not insert");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('Your request has not been Submitted')");
					out.println("setTimeout(function(){window.location.href='mplscreation.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
//					getServletContext().getRequestDispatcher(
//							"/tacscreation.jsp").forward(request, response);
				}
			}
		}
	}

	public MplsUser mapUser(HttpServletRequest request,
			HttpServletResponse response) {
		MplsUser user = new MplsUser();
		user.setOlm_id(request.getParameter("olmid"));
		user.setRef_id(request.getParameter("ref_id"));
		user.setRequest(request.getParameter("requestfor"));
		user.setUsType(request.getParameter("ustype"));
		user.setUsBelong(request.getParameter("u_belongs"));
		user.setPurpose(request.getParameter("purpose"));
		user.setAcReqType(request.getParameter("access"));
		user.setDept(request.getParameter("state"));
		user.setMgrname(request.getParameter("manager"));
		user.setRights(request.getParameter("rights"));
		user.setHod(request.getParameter("hod"));
		user.setVendor(request.getParameter("vd_details"));
		user.setFname(request.getParameter("first_name"));
		user.setLname(request.getParameter("last_name"));
		user.setLocation(request.getParameter("street_name"));
		user.setContact(request.getParameter("c_number"));
		user.setEmail(request.getParameter("email_id"));
		user.setDesig(request.getParameter("designation"));
		user.setHost(request.getParameter("hostName1"));
		System.out.println(request.getParameter("hostName1"));
		user.setIp(request.getParameter("ipaddress1"));
		System.out.println(request.getParameter("ipaddress1"));
		user.setCat(request.getParameter("cat1"));
		System.out.println(request.getParameter("cat1"));
		user.setSumm(request.getParameter("summary"));
		return user;
	}
}
