package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;
import main.java.com.airtel.utility.StringUtility;

@WebServlet(urlPatterns = "/TacCreationUserForSystem")
public class TacSystemApprovalForCreationController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("TacSystem Approval For Creation Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String ticket = request.getParameter("ticket");
		String pwd = request.getParameter("Password");
		String to = userService.getUserForTacCreation(olmid, "tacuser")
				.getEmail();

		String name = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println("System help desk person name==>" + name);
		System.out.println(status);
		System.out.println(olmid);
		String id = "B0097268";
		if (status.equals("approve")) {

			b = userService.changeTacUserStatusForSystem(status, olmid, name,
					ticket, pwd);

			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation on TACACS has been Approved on TAC System level. </b><br>";
			msg += "<br><b>For any queries regarding your request, cantact Tacacs System Team.</b><br>";
			msg += "<br><b>Ph: 9810050958 </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);
		}
		if (status.equals("rejected")) {
			userService.changeTacUserStatusForSystem(status, olmid, name,
					ticket, pwd);

			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation on TACACS has been Rejected on TAC System level. </b><br>";
			msg += "<br><b>For any queries regarding your request, cantact Tacacs System Team.</b><br>";
			msg += "<br><b>Ph: 9810050958 </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);
		}
		if (status.equals("pending")) {

			userService.changeTacUserStatusForSystem(status, olmid, name,
					ticket, pwd);
		}
		if (b == true) {

			System.out.println("inside if block");
			List<TacUser> list = new LinkedList<TacUser>();

			list = userService.getAllPendingTacCreationForSystem(1, 1, 0);
			request.setAttribute("pendingrequest", list);
			if (list.size() == 0) {
				request.setAttribute("usernopendingforsystem",
						"NO PENDING USER REQUEST FOUND..");
			}
			list = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/TacSystem.jsp").forward(request, response);

		}
		if (b == false)
			request.getRequestDispatcher("/WEB-INF/jsp/TacSystem.jsp").forward(
					request, response);
		System.out.println("some problem occur");
	}

}
