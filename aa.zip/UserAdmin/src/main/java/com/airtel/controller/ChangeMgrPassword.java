package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.ManagerService;

@WebServlet(urlPatterns = "/changemamgerpwd")
public class ChangeMgrPassword extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 12L;
	IManagerService managerService = new ManagerService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		IManagerService mService = new ManagerService();
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("Change Mgr Passwordcontroller called");
		String olmid = (String) session.getAttribute("id");
		System.out.println(olmid);
		String oldPwd = request.getParameter("oldpwd");
		String nPwd = request.getParameter("pwd");
		System.out.println(oldPwd);
		System.out.println(nPwd);
		b = mService.changeMgrPwd(olmid, oldPwd, nPwd);
		if (b == true) {
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your Password sucessfully changed')");
			out.println("setTimeout(function(){window.location.href='mgrlogout.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
		} else {
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your Password Not changed Please Enter The Correct Current Password')");
			out.println("setTimeout(function(){window.location.href='changepwd.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");

		}

	}

}
