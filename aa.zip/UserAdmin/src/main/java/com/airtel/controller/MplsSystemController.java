package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

@WebServlet(urlPatterns = "/getMplsUserDetailsForSystem")
public class MplsSystemController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	String caption;
	String value;
	String olmid;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String olm;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		System.out.println(" MPLS System Controller called");
		HttpSession session = request.getSession(false);
		caption = request.getParameter("action");
		System.out.println(caption);
		value = request.getParameter("action");
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
		System.out.println(olmid);
		System.out.println("called");
		if (caption.equals("Pending User Request")) {
			System.out.println("inside if block");
			List<MplsUser> list = new LinkedList<MplsUser>();
			list = userService.getAllPendingMplsCreationForSystem(1, 1, 0);
			request.setAttribute("pendingrequest", list);
			List<MplsUser> mlist = new LinkedList<MplsUser>();
			///mlist = userService.getAllPendingTacModificationForSystem(1, 1, 0);
			mlist = userService.getAllPendingMplsModificationForSystem(1, 1, 0);

			request.setAttribute("ModificationPendingRequest", mlist);
			List<MplsUser> dlist = new LinkedList<MplsUser>();
		//	dlist = userService.getAllPendingTacDeletionForSystem(1, 0);
			dlist = userService.getAllPendingMplsDeletionForSystem(1, 0);

			request.setAttribute("DeletionPendingRequest", dlist);
			
			List<MplsUser> plist = new LinkedList<MplsUser>();
		//	plist = userService.getAllPendingTacPwdForSystem(1, 0);
			plist = userService.getAllPendingMplsPwdForSystem(1, 0);

			request.setAttribute("PwdPendingRequest", plist);
			if (list.size() == 0 && mlist.size() == 0 && dlist.size() == 0
					&& plist.size() == 0) {
				request.setAttribute("usernopendingforsystem",

				"NO PENDING USER REQUEST FOUND..");

			}
			list = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsSystem.jsp").forward(request, response);
		}
		if (caption.equals("IN Progress User Request")) {
			List<MplsUser> list = new LinkedList<MplsUser>();
			list = userService.getAllPendingMplsCreationForSystem(1, 1, 3);
			List<MplsUser> mlist = new LinkedList<MplsUser>();
			mlist = userService.getAllPendingMplsModificationForSystem(1, 1, 3);
			request.setAttribute("ModificationProgress", mlist);
			List<MplsUser> dlist = new LinkedList<MplsUser>();
			dlist = userService.getAllPendingMplsDeletionForSystem(1, 3);
			request.setAttribute("deleteProgress", dlist);
			List<MplsUser> plist = new LinkedList<MplsUser>();
			plist = userService.getAllPendingMplsPwdForSystem(1, 3);
			request.setAttribute("pwdProgress", plist);

			request.setAttribute("progress", list);
			System.out.println("inside progress block");
			System.out.println(list.size());
			if (list.size() == 0 && mlist.size() == 0 && dlist.size() == 0
					&& plist.size() == 0) {
				request.setAttribute("usernopendingforsystem",
						"NO IN PROGRESS USER REQUEST FOUND..");
			}
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsSystem.jsp").forward(request, response);
		}
		
		
		if (caption.equals("Created User List")) {
			List<MplsUser> list = new LinkedList<MplsUser>();
			list = userService.getAllPendingMplsCreationForSystem(1, 1, 1);
			List<MplsUser> mlist = new LinkedList<MplsUser>();
			mlist = userService.getAllPendingMplsModificationForSystem(1, 1, 1);
			request.setAttribute("mcreate", mlist);
			List<MplsUser> dlist = new LinkedList<MplsUser>();
			dlist = userService.getAllPendingMplsDeletionForSystem(1, 1);
			request.setAttribute("dcreate", dlist);
			List<MplsUser> plist = new LinkedList<MplsUser>();
			plist = userService.getAllPendingMplsPwdForSystem(1, 1);
			request.setAttribute("pcreate", plist);

			request.setAttribute("ccreate", list);
			System.out.println("inside progress block");
			System.out.println(list.size());
			
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsSystem.jsp").forward(request, response);
		}
		
		

		if (caption.equals("view detail ")) {
			System.out.println("inside Mpls system  view for creation");
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsCreation(
					olmid.substring(1, olmid.length()).trim(), "mplsuser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsUserForSystem.jsp").forward(request,
					response);
		}
		if (caption.equals("view details ")) {
			System.out.println("inside MPLS system  view for creation");
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsCreation(
					olmid.substring(1, olmid.length()).trim(), "mplsuser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsUserForSystem.jsp").forward(request,
					response);
		}
		if (caption.equals("view detail's ")) {
			System.out.println("inside MPLS system  view for modification");
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsCreation(
					olmid.substring(1, olmid.length()).trim(), "mplsmoduser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsModUserForSystem.jsp").forward(
					request, response);
		}
		if (caption.equals("Fetch all details ")) {
			System.out.println("inside MPLS system  view for System");
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsPwdReset(olmid.substring(1,
					olmid.length()).trim());
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsUserForPwdResetSystem.jsp").forward(
					request, response);
		}
//		if (caption.equals("view details ")) {
//			System.out.println("inside Tac system  view for modification");
//			TacUser user = new TacUser();
//			user = userService.getUserForTacCreation(
//					olmid.substring(1, olmid.length()).trim(), "tacmoduser");
//			session.setAttribute("User", user);
//			getServletContext().getRequestDispatcher(
//					"/WEB-INF/jsp/viewTacModUserForSystem.jsp").forward(
//					request, response);
//		}
		if (caption.equals("Get details ")) {
			System.out.println("inside Mpls system  view for deletion");
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsDeletion(olmid.substring(1,
					olmid.length()).trim());
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
				"/WEB-INF/jsp/viewMplsDelForSystem.jsp").forward(request,
					response);
		}

		if (caption.equals("Log Out")) {
			if (session != null) {
				String system = (String) session.getAttribute("mplssystem");
				System.out.println(session.getAttribute("mplssystem"));
				session.removeAttribute(system);
				// session.removeAttribute("user");
				// session.invalidate();

			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}

	}

}
