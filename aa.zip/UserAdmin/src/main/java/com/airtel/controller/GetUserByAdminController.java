package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.service.UserService;

public class GetUserByAdminController extends HttpServlet {

	private static final long serialVersionUID = 112L;

	String caption;
	String value;
	String olmid;
	IManagerService managerService = new ManagerService();
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String olm;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		System.out.println("GetUserByAdmin controller called");
		HttpSession session = request.getSession(false);
		caption = request.getParameter("action");
		System.out.println(caption);
		value = request.getParameter("action");
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
		if (caption.equals("Pending User Request")) {

			System.out.println("inside if block");
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUnactivatedUserForAdmin(0, 1);
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllModifiedUserForAdmin(0, 1);
			System.out.println(listi);
			request.setAttribute("pending", listi);
			request.setAttribute("modifiedpending", list);
			if (listi.size() == 0 && list.size() == 0) {
				request.setAttribute("usernopending",
						"NO PENDING USER REQUEST FOUND");
			}
			listi = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/userdetailsforadmin.jsp").forward(request,
					response);
		}
		if (caption.equals("Created User List")) {
			System.out.println("inside if block");
			List<NewUser> alist = new LinkedList<NewUser>();
			alist = userService.getAllUnactivatedUserForAdmin(1, 1);
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllModifiedUserForAdmin(1, 1);
			System.out.println(alist);
			request.setAttribute("approved", alist);
			request.setAttribute("modifiedapproved", list);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/userdetailsforadmin.jsp").forward(request,
					response);

		}
		if (caption.equals("view details ")) {
			System.out.println("inside admin view details block");
			NewUser user = new NewUser();
			user = userService
					.getUserDetails(olmid.substring(1, olmid.length()));
			session.setAttribute("User", user);
			System.out.println(user.getEci());
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewUserForAdminActvation.jsp").forward(
					request, response);

		}
		if (caption.equals("view detail's ")) {
			System.out.println("inside admin view details block");
			NewUser user = new NewUser();
			user = userService
					.getUserDetailsForModification(olmid.substring(1, olmid.length()));
			session.setAttribute("User", user);
			System.out.println(user.getEci());
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewmodifieduserforadmin.jsp").forward(
					request, response);

		}
		if (caption.equals("Log Out")) {
			if (session != null)
			{
				String olmi = (String) session.getAttribute("olm");
				System.out.println(session.getAttribute("olm"));
				session.removeAttribute(olmi);
			//	session.invalidate();
			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}
	}
}
