package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.Manager;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.utility.PasswordEncDe;

public class ManagerController extends HttpServlet {
	private static final long serialVersionUID = 123455L;
	Manager manager = new Manager();
	IManagerService mservice = new ManagerService();
	boolean flag = false;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession();
		System.out.println("manager controller start");
		manager.setOlmId(request.getParameter("olm"));
		String olm = request.getParameter("olm");
		manager.setFirstName(request.getParameter("first_name"));
		manager.setLastName(request.getParameter("last_name"));
		manager.setFullName(request.getParameter("first_name") + " "
				+ request.getParameter("last_name"));
		manager.setDepartment(request.getParameter("department"));
		manager.setEmailId(request.getParameter("email_id"));
		System.out.println(request.getParameter("email_id"));
		System.out.println(request.getParameter("department"));
		System.out.println(request.getParameter("password"));
		manager.setPassword(PasswordEncDe.EncryptText(request
				.getParameter("password")));

		System.out.println("getting all data from frontend");
		try {
			System.out.println("inside try block");
			if (mservice.getOlm_id(request.getParameter("olm")) == true) {
				flag = mservice.submitManager(manager);
				System.out.println(flag);
				request.getRequestDispatcher("/WEB-INF/jsp/mgrsucesssignup.jsp")
						.forward(request, response);
			} else {
				System.out.println("invalid credentials");
				int st = mservice.addMgrForActiveAndReject(olm);
				System.out.println(st);
				if (st == 4) {
					mservice.submitManagerForRejected(manager, olm);
					System.out.println("YOUR MANAGER STATUS===>" + st);
					request.getRequestDispatcher(
							"/WEB-INF/jsp/mgrsucesssignup.jsp").forward(
							request, response);
				} else {
					request.setAttribute("error",
							"Your OlmId is already Registered");
					request.setAttribute("login", "Please Enter correct id");
					request.getRequestDispatcher("/ManagerSignUp.jsp").forward(
							request, response);
				}
			}
			System.out.println("successfully added manager");
			System.out.println(flag);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// response.sendRedirect("index.jsp");

	}

}
