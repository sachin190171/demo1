package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/MplsPwdResetForMgr")
public class MplsPwdResetApprovalController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IManagerService managerService = new ManagerService();
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out
				.println("MPLS Password Reset Manager Approval controller called");
		String status = request.getParameter("status");

		String uid = request.getParameter("uid");

		String id = (String) session.getAttribute("olid");
		System.out.println("id>>>>>>>>>>>>>>>>>>>" + id);
		String mgrName = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println(status);

		System.out.println(uid);

		MplsUser user = userService.getUserForMplsPwdReset(uid);
		String to = user.getEmail();
		String email ="Divya.verma@airtel.com";
		if (status.equals("approve")) {
			b = userService.approvalMplsPwdForManager(uid, 1, id);

			String msg = "Hi <br>";
			msg += "<br><b>Your Request has been Approved at Manager Level and your TOKEN ID is:</b><br>";
			msg += "<font color=red>" + uid + "</font>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";

			SendEmail.sendMail(to, msg, id);
			String msg1 = "Hi<br>";
			msg1 += "<br><b>You have a MPLS/IP Account Password Reset request in your bin. </b><br>";
			msg1 += "<br>";
			msg1 += "<br>Thank you";
			msg1 += "<br>Portal Development Team";
			msg1 += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg1, id);
		}
		if (status.equals("rejected")) {
			userService.approvalMplsPwdForManager(uid, 2, id);

			String msg = "Hi <br>";
			msg += "<br><b>Your Request has been Rejected at Manager Level and your TOKEN ID is:</b><br>";
			msg += "<font color=red>" + uid + "</font>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";

			SendEmail.sendMail(to, msg, id);
		}
		if (b == true) {
			List<MplsUser> listi = new LinkedList<MplsUser>();
			listi = userService.getAllPendingMplsPwdReset(0, id);

			System.out.println(listi);
			request.setAttribute("mplspwduser", listi);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsManager.jsp").forward(request,
					response);
		}
		if (b == false) {
			System.out.println("some problem occur");
			request.getRequestDispatcher("/WEB-INF/jsp/MplsManager.jsp")
					.forward(request, response);
		}

	}
}
