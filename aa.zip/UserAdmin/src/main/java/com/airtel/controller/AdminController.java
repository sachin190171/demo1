package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.Manager;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.ManagerService;

public class AdminController extends HttpServlet {

	private static final long serialVersionUID = 112L;

	String caption;
	String value;
	String olmid;
	IManagerService managerService = new ManagerService();
	

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String olm;
		List<Manager> listi = null;
		List<Manager> alist = null;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		System.out.println("admin controller called");
		HttpSession session = request.getSession(false);
		System.out.println(session);
		caption = request.getParameter("action");
		System.out.println(caption);
		value = request.getParameter("action");
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
		if (caption.equals("Pending Manager Request")) {

			System.out.println("inside if block");
			listi = new LinkedList<Manager>();
			listi = managerService.getAllManager(0);
			System.out.println(listi);
			Set<Manager> list = new HashSet<Manager>(listi);
			request.setAttribute("Pending", listi);
			listi = null;
			System.out.println(list);
			if(list.size()==0)
				request.setAttribute("mgrnopending", "NO PENDING MANAGER REQUEST");
			getServletContext()
					.getRequestDispatcher("/WEB-INF/jsp/viewmng.jsp").forward(
							request, response);
		}
		if (caption.equals("Created Manager List")) {
			System.out.println("inside if block");
			alist = new LinkedList<Manager>();
			alist = managerService.getAllManager(1);
			System.out.println(alist);
			request.setAttribute("Approved", alist);
			System.out.println(alist);
			getServletContext()
					.getRequestDispatcher("/WEB-INF/jsp/viewmng.jsp").forward(
							request, response);

		}
		if (caption.equals("view details ")) {
			System.out.println("inside manager id if");
			Manager man = new Manager();
			man = managerService.getmanager(olmid.substring(1, olmid.length()));
			session.setAttribute("manager", man);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewManager.jsp").forward(request, response);

		}
		if (caption.equals("Log Out")) {
			if (session != null) {
				String olmi = (String) session.getAttribute("olm");
				System.out.println(session.getAttribute("olm"));
				session.removeAttribute(olmi);
				// session.invalidate();

			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}
	}
}
