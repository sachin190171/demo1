package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.MplsUser;

import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/MplsDeletion")
public class MplsDelUserForManagerApproval extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IManagerService managerService = new ManagerService();
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("MPLS Deletion Manager Approval controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");

		String id = (String) session.getAttribute("olid");
		System.out.println("id" + id);
		String mgrName = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println(status);
		System.out.println(olmid);
	//	String to = userService.getUserForTacDeletion(olmid).getEmail();
		String to = userService.getUserForMplsDeletion(olmid).getEmail();

		String email = "Ishwar1.Pandav@airtel.com";
		if (status.equals("approve")) {

			b = userService.updateTacUserDelForManager(id, 1);
			b = userService.updateMplsUserDelForManager(id, 1);

			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Deletion has been Approved on Manager level. </b><br>";

			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);
			String msg1 = "Hi<br>";
			msg1 += "<br><b>You have a Tacacs Account Deletion request in your bin. </b><br>";
			msg1 += "<br>";
			msg1 += "<br>Thank you";
			msg1 += "<br>Portal Development Team";
			msg1 += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg1, id);
		}
		if (status.equals("rejected")) {
			userService.updateTacUserDelForManager(id, 2);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Deletion has been Rejected on Manager level. </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);

		}
		if (b == true) {
			List<TacUser> listi = new LinkedList<TacUser>();
			listi = userService.getAllPendingTacDeletion(0, id);
			System.out.println(listi);
			request.setAttribute("tacdeluser", listi);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
		}
		if (b == false) {
			System.out.println("some problem occur");
			request.getRequestDispatcher("/WEB-INF/jsp/MplsManager.jsp")
					.forward(request, response);
		}

	}

}
