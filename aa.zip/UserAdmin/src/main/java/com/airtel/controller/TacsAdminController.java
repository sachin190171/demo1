package main.java.com.airtel.controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;


@WebServlet(urlPatterns="/getTacUserDetailsForAdmin")
public class TacsAdminController extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		IUserService userService = new UserService();
		String olmid = null;
		HttpSession session = request.getSession(false);
		response.setContentType("text/html");

		// out.println("Invalid Login");
		System.out.println("TacsAdmin controller called");
		String caption = request.getParameter("action");
		String value = request.getParameter("action");
		String id = (String) session.getAttribute("id");
		System.out.println(id);
		System.out.println(caption);
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
		System.out.println(caption);
		System.out.println(olmid);
		if (caption.equals("Pending User Request")) {
			List<TacUser> listi = new LinkedList<TacUser>();
			List<NewUser> list = new LinkedList<NewUser>();
			List<NewUser> mlist = new LinkedList<NewUser>();
		//	listi = userService.getAllUser(0, id);
			list = userService.getAllUserFromDeleted(0, id);
			mlist = userService.getAllUserFromModified(0, id);
			if (listi.size() == 0 && list.size() == 0 && mlist.size() == 0) {
				request.setAttribute("zeropending",
						"NO PENDING REQUEST AVAILABLE..");
			}
			request.setAttribute("pending", listi);
			request.setAttribute("deletedpending", list);
			request.setAttribute("modifiedpending", mlist);
			listi = null;
			list = null;
			mlist = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
		}
		
	}

}
