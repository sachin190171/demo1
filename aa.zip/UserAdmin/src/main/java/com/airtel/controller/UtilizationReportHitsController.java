package main.java.com.airtel.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter(urlPatterns = "/")
public class UtilizationReportHitsController implements Filter {

	
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

		System.out.println("init block called");

	}

	
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub

		System.out.println("dofilter block called");
		System.out.println(request.getRemoteAddr());
		System.out.println(request.getRemoteHost());
		Timestamp time = new Timestamp(new Date().getTime());
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/utilization", "root", "mysql");
			System.out.println(con);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("select max(id) as id  from utilTable");
			System.out.println(rs);
			int id = 0;
			while (rs.next()) {
				id = rs.getInt("id");
				id = id + 1;
			}
			rs.close();
			stmt = con.createStatement();
			stmt.execute("insert into utilTable values('" + id + "','USER ADMIN','"
					+ request.getRemoteAddr() + "', '" + time + "')");
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		request.getRequestDispatcher("BasicLogin.jsp").forward(request,
				response);

	}

	
	public void destroy() {
		// TODO Auto-generated method stub

		System.out.println("destroy block called");

	}

}
