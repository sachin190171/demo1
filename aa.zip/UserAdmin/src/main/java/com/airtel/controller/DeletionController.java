package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/deleteuser")
public class DeletionController extends HttpServlet {

	/**
	 * 
	 */
	NewUser nUser;
	PrintWriter out;
	IUserService userService = new UserService();
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		System.out.println("Deletion Controller called");
		out = response.getWriter();
		String olm = request.getParameter("olmid");
		String fname = request.getParameter("first_name");
		String lname = request.getParameter("last_name");
		System.out.println(olm);
		System.out.println(fname);
		System.out.println(lname);
		boolean flag = userService.checkIdForUserDelete(olm);
		System.out.println(flag);
		if (flag == true) {

			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('YOUR ACCOUNT DELETION REQUEST ALREADY REGISTERED ')");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			System.out.println("Duplicate Entry For Account Deletin Request");
			request.setAttribute("error", "Your olm id is already registered");
			// getServletContext().getRequestDispatcher("/BasicLogin.jsp").forward(request,
			// response);
		} else {
			nUser = mapUser(request, response);
			userService.addUserInDeltionUser(nUser);
			String email = userService.getMgrEmailId(nUser.getState(),
					request.getParameter("manager"));

			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your form has been Sucessfully submitted')");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			String msg = "Hi<br>";
			msg += "<br><b>You have a NMS Account Deletion  request in your bin.  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, olm);

			System.out.println("User Entred successfully");
		}
	}

	public NewUser mapUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		NewUser user = new NewUser();
		user.setOlm_id(request.getParameter("olmid"));
		user.setRequestfor(request.getParameter("requestfor"));
		user.setUstype(request.getParameter("ustype"));
		user.setU_belongs(request.getParameter("u_belongs"));
		user.setPurpose(request.getParameter("purpose"));
		user.setState(request.getParameter("state"));
		user.setManager(request.getParameter("manager"));
		user.setVd_details(request.getParameter("vd_details"));
		user.setEmail_id(request.getParameter("email_id"));
		user.setVendor(request.getParameter("vendor"));
		user.setFirst_name(request.getParameter("first_name"));
		user.setLast_name(request.getParameter("last_name"));
		user.setStreet_name(request.getParameter("street_name"));
		user.setC_number(request.getParameter("c_number"));
		user.setUt_name(request.getParameter("ut_name"));
		user.setDesignation(request.getParameter("designation"));
		user.setUuid(request.getParameter("first_name")
				+ request.getParameter("c_number"));
		user.setUser_id(request.getParameter("user_id"));
		System.out.println(user);
		return user;
	}

}
