package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.Manager;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.ManagerService;

public class ChangeStatusController extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 12L;
	IManagerService managerService = new ManagerService();
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		IManagerService mService = new ManagerService();
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("change status controller called");
		System.out.println("get dispatch");
		String status = request.getParameter("status");
		String olmid =  request.getParameter("olm");
		String caption=  request.getParameter("action");
		System.out.println(caption);
		System.out.println(status);
		System.out.println(olmid);
		if (status.equals("approve"))
			b = mService.changeStatus(status, olmid);
		if (status.equals("pending"))
			b = mService.changeStatus(status, olmid);
		if (b == true){
			List<Manager> listi = new LinkedList<Manager>();
		listi = managerService.getAllManager(0);
		System.out.println(listi);
		session.setAttribute("pending", listi);
			request.getRequestDispatcher("/WEB-INF/jsp/viewmng.jsp").forward(
					request, response);
		}
		if (b == false){
			System.out.println("some problem occur");
			request.getRequestDispatcher("/WEB-INF/jsp/admin.jsp").forward(
					request, response);
		}
			
	}

}
