


package main.java.com.airtel.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

public class ManagerFunctionController extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		IUserService userService = new UserService();
		String olmid = null;
		HttpSession session = request.getSession(false);
		response.setContentType("text/html");
		
		// out.println("Invalid Login");
		System.out.println("ManagerFunction controller called");
		String caption = request.getParameter("action");
		String value = request.getParameter("action");
		String id = (String) session.getAttribute("id");
		System.out.println("value of id is >>>>>>>"+id);
		System.out.println(caption);
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
		
		if (caption.equals("Pending User Request")) {
			List<NewUser> listi = new LinkedList<NewUser>();
			List<NewUser> list = new LinkedList<NewUser>();
			List<NewUser> mlist = new LinkedList<NewUser>();
			listi = userService.getAllUser(0, id);
			list = userService.getAllUserFromDeleted(0, id);
			mlist  = userService.getAllUserFromModified(0, id);
			if (listi.size() == 0&&list.size()==0&&mlist.size()==0) {
				request.setAttribute("zeropending",
						"NO PENDING REQUEST AVAILABLE..");
			}
			request.setAttribute("pending", listi);
			request.setAttribute("deletedpending", list);
			request.setAttribute("modifiedpending", mlist);
			listi = null;
			list = null;
			mlist = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
		}
		if (caption.equals("TACACS Pending User Request")) {

			List<TacUser> mlist = new ArrayList<TacUser>();
			mlist = userService.getAllPendingTacModification(0, id);
			List<TacUser> list = new ArrayList<TacUser>();
			list = userService.getAllPendingTacCreation(0, id);
			List<TacUser> list1 = new ArrayList<TacUser>();
			list1 = userService.getAllPendingTacCreationForHOD(1, id, 0,
					"tacuser");

			List<TacUser> dlist = new ArrayList<TacUser>();
			dlist = userService.getAllPendingTacDeletion(0, id);

			List<TacUser> list3 = new ArrayList<TacUser>();
			list3 = userService.getAllPendingTacCreationForHOD(1, id, 0,
					"tacmoduser");
			List<TacUser> plist = new ArrayList<TacUser>();
			plist = userService.getAllPendingTacPwdReset(0, id);

			if (list.size() == 0 && list1.size() == 0 && mlist.size() == 0
					&& list3.size() == 0 && dlist.size() == 0
					&& plist.size() == 0) {
				request.setAttribute("tacpending", "No Request Found......");
			}
			request.setAttribute("taclist", list);
			request.setAttribute("taclistforHod", list1);
			request.setAttribute("tacmod", mlist);
			request.setAttribute("tacmodhod", list3);
			request.setAttribute("tacdeluser", dlist);
			request.setAttribute("tacpwduser", plist);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
		}
		if(caption.equals("User Password Reset Request")){
			System.out.println("Inside password pending request");
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllUserListForPasswordReset(id,0);
			if(list.size()==0){
				request.setAttribute("nopendingforpassword",
						"NO PENDING REQUEST AVAILABLE..");
			}
			request.setAttribute("passwordpending", list);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
			
			
			
		}
		if (caption.equals("Created User List")) {
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUser(1, id);
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllUserFromDeleted(1, id);
			List<NewUser> mlist = new LinkedList<NewUser>();
			mlist  = userService.getAllUserFromModified(1, id);
			List<NewUser> pwdlist = new LinkedList<NewUser>();
			pwdlist = userService.getAllUserListForPasswordReset(id,1);
			System.out.println(listi);
			System.out.println(session.getAttribute("id"));
			request.setAttribute("approved", listi);
			request.setAttribute("deletedapproved", list);
			request.setAttribute("modifiedapproved", mlist);
			request.setAttribute("pwdreset", pwdlist);
			listi = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
		}
		if (caption.equals("view details ")) {
			System.out.println("inside manager functional controller view details for creation");
			NewUser user = new NewUser();
			user = userService
					.getUserDetails(olmid.substring(1, olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewUser.jsp").forward(request, response);

		}
		if (caption.equals("Get all details. ")) {
			System.out
					.println("inside manager functional controller view details for creation");
			TacUser user = new TacUser();
			user = userService.getUserForTacDeletion(olmid.substring(1,
					olmid.length()).trim());

			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacDelUsrForManager.jsp").forward(
					request, response);

		}
		if (caption.equals("view detail's ")) {
			System.out.println("inside manager functional controller view details for delete");
			NewUser user = new NewUser();
			user = userService
					.getUserDetailsForDeletion(olmid.substring(1, olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrviewuserfordeletion.jsp").forward(request, response);

		}
		if (caption.equals("view detail's. ")) {
			System.out.println("inside manager functional controller view details for modification");
			NewUser user = new NewUser();
			user = userService
					.getUserDetailsForModification(olmid.substring(1, olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/ViewUserForModified.jsp").forward(request, response);

		}
		if (caption.equals("show detail's ")) {
			System.out.println("inside manager functional controller view details for password reset");
			System.out.println(olmid.substring(1, olmid.length()));
			NewUser user = new NewUser();
			user = userService
					.getUserDetailsForPasswordResetForManager(olmid.substring(1, olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/showPasswordResetDetailsForManager.jsp").forward(request, response);

		}
		if (caption.equals("Get details ")) {
			System.out
					.println("inside manager functional controller view details for tacacs creation ");
			System.out.println(olmid.substring(1, olmid.length()));
			TacUser user = new TacUser();
			user = userService.getUserForTacCreation(
					olmid.substring(1, olmid.length()).trim(), "tacuser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacUserForManager.jsp").forward(request,
					response);

		}
		if (caption.equals("Fetch details ")) {
			System.out
					.println("inside manager functional controller view details for tacacs password reset ");
			System.out.println(olmid.substring(1, olmid.length()));
			TacUser user = new TacUser();
			user = userService.getUserForTacPwdReset(
					olmid.substring(1, olmid.length()).trim());
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacuserForPwdReset.jsp").forward(request,
					response);

		}


		if (caption.equals("Get All details ")) {
			System.out
					.println("inside manager functional controller view details for tacacs modification ");
			System.out.println(olmid.substring(1, olmid.length()));
			TacUser user = new TacUser();
			user = userService.getUserForTacCreation(
					olmid.substring(1, olmid.length()).trim(), "tacmoduser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacModUserForHod.jsp").forward(request,
					response);

		}

		if (caption.equals("Get detail ")) {
			System.out
					.println("inside manager functional controller view details for tacacs modification ");
			System.out.println(olmid.substring(1, olmid.length()));
			TacUser user = new TacUser();
			user = userService.getUserForTacCreation(
					olmid.substring(1, olmid.length()).trim(), "tacmoduser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacModUserForManager.jsp").forward(
					request, response);

		}

		if (caption.equals("Get detail's ")) {
			System.out
					.println("inside manager functional controller view details for tacacs creation ");
			System.out.println(olmid.substring(1, olmid.length()));
			TacUser user = new TacUser();
			user = userService.getUserForTacCreation(
					olmid.substring(1, olmid.length()).trim(), "tacuser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacUserForHod.jsp").forward(request,
					response);

		}
		if (caption.equals("Log Out")) {
			if (session != null) {
				String olmi = (String) session.getAttribute("id");
				System.out.println("LOG OUT ==>" + session.getAttribute("id"));
				session.removeAttribute(olmi);
				// session.invalidate();

			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}

	}
}
