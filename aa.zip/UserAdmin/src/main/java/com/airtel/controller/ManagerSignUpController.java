
package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.java.com.airtel.model.Manager;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.ManagerService;


public class ManagerSignUpController extends HttpServlet {
	private static final long serialVersionUID = 123455L;
	Manager manager = new Manager();
	IManagerService mservice = new ManagerService();
	String olm_id;
	boolean flag = false;
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		System.out.println("inside try block");
		manager = (Manager)request.getAttribute("manager");
		System.out.println(manager);
		 olm_id = manager.getOlmId();
		try{
			System.out.println( olm_id);
			System.out.println("inside try block");
			System.out.println("hello");
			System.out.println("successfully added manager");
			if(flag == true){
				System.out.println("hello");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		

			

			// response.sendRedirect("index.jsp");

		}

	
}
