package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/modifiedTacsUser")
public class TacsModificationController extends HttpServlet {
	IUserService userservice = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		System.out.println("modified controller called");
		TacUser user = mapUser(request, response);
		PrintWriter out = response.getWriter();

		boolean var = userservice.checkForTacModification(request
				.getParameter("olmid"));
		String email = userservice.getMgrEmailId(user.getDept(),
				user.getOlm_id());

		if (var == true) {

			boolean check = userservice.addanddeleteUserModTac(request
					.getParameter("olmid"));
			if (check == true) {

				if (user.getRights().equals("Write")) {
					String hod = user.getHod();
					System.out.println("hod name===>" + hod + "name");
					System.out.println("inside write permission block");
					if (hod == "" || hod == null) {
						System.out.println("when HOD name is null");
						System.out.println("first if block");
						response.setContentType("text/html");
						out.println("<html>");
						out.println("<head>");
						out.println("<script type = 'text/javascript'>");
						out.println("window.alert('HOD Name could not be Blank.')");
						out.println("setTimeout(function(){window.location.href='tacsmodification.jsp'},20);");
						out.println("</script>");
						out.println("</head>");
						out.println("</html>");

						request.setAttribute("msg", "Please Select HOD Name.");
						// RequestDispatcher dispatch = getServletContext()
						// .getRequestDispatcher("/tacscreation.jsp");
						// dispatch.forward(request, response);
					}

					else {
						boolean flag = userservice
								.submitTacModifiedRequest(user);
						if (flag == true) {
							System.out.println("record insert");
							out.println("<html>");
							out.println("<head>");
							out.println("<script type = 'text/javascript'>");
							out.println("window.alert('Your request has been Submitted')");
							out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
							out.println("</script>");
							out.println("</head>");
							out.println("</html>");
							String msg = "Hi<br>";
							msg += "<br><b>You have a Tacacs Account Modification request in your bin. </b><br>";
							msg += "<br><b>URL for Portal: </b>";
							msg += "<br><b>https://172.30.1.99:8443/UserAdmin/   ( Supported on Google Chrome with disabled proxy )  </b><br>";
							msg += "<br>";
							msg += "<br>Thank you";
							msg += "<br>Portal Development Team";
							msg += "<br>PH: 0124-4381378";
							SendEmail.sendMail(email, msg, user.getOlm_id());

							// getServletContext().getRequestDispatcher(
							// "/BasicLogin.jsp").forward(request, response);
						} else {

							System.out.println("record not insert");
							out.println("<html>");
							out.println("<head>");
							out.println("<script type = 'text/javascript'>");
							out.println("window.alert('Your request has not been Submitted')");
							out.println("setTimeout(function(){window.location.href='tacmodification.jsp'},10);");
							out.println("</script>");
							out.println("</head>");
							out.println("</html>");
//							getServletContext().getRequestDispatcher(
//									"/tacscreation.jsp").forward(request,
//									response);
						}
					}

				}
				if (user.getRights().equals("Read")) {
					System.out.println("inside read block ");
					boolean flag = userservice.submitTacModifiedRequest(user);
					if (flag == true) {
						System.out.println("record insert");
						out.println("<html>");
						out.println("<head>");
						out.println("<script type = 'text/javascript'>");
						out.println("window.alert('Your request has been Submitted')");
						out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
						out.println("</script>");
						out.println("</head>");
						out.println("</html>");
						
						String msg = "Hi<br>";
						msg += "<br><b>You have a Tacacs Account Modification request in your bin. </b><br>";
						msg += "<br><b>URL for Portal: </b>";
						msg += "<br><b>https://172.30.1.99:8443/UserAdmin/   ( Supported on Google Chrome with disabled proxy )  </b><br>";
						msg += "<br>";
						msg += "<br>Thank you";
						msg += "<br>Portal Development Team";
						msg += "<br>PH: 0124-4381378";
						SendEmail.sendMail(email, msg, user.getOlm_id());

						// getServletContext().getRequestDispatcher(
						// "/BasicLogin.jsp").forward(request, response);
					} else {

						System.out.println("record not insert");
						out.println("<html>");
						out.println("<head>");
						out.println("<script type = 'text/javascript'>");
						out.println("window.alert('Your request has not been Submitted')");
						out.println("setTimeout(function(){window.location.href='tacmodification.jsp'},10);");
						out.println("</script>");
						out.println("</head>");
						out.println("</html>");
						// getServletContext().getRequestDispatcher(
						// "/tacmodification.jsp").forward(request, response);
					}
				}

			}

		} else {
			if (user.getRights().equals("Write")) {
				String hod = user.getHod();
				System.out.println("hod name===>" + hod + "name");
				System.out.println("inside write permission block");
				if (hod == "" || hod == null) {
					System.out.println("when HOD name is null");
					System.out.println("first if block");
					response.setContentType("text/html");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('HOD Name could not be Blank.')");
					out.println("setTimeout(function(){window.location.href='tacsmodification.jsp'},20);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
					request.setAttribute("msg", "Please Select HOD Name.");
					// RequestDispatcher dispatch = getServletContext()
					// .getRequestDispatcher("/tacscreation.jsp");
					// dispatch.forward(request, response);
				}

				else {
					boolean flag = userservice.submitTacModifiedRequest(user);
					if (flag == true) {
						System.out.println("record insert");
						out.println("<html>");
						out.println("<head>");
						out.println("<script type = 'text/javascript'>");
						out.println("window.alert('Your request has been Submitted')");
						out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
						out.println("</script>");
						out.println("</head>");
						out.println("</html>");
						String msg = "Hi<br>";
						msg += "<br><b>You have a Tacacs Account Modification request in your bin. </b><br>";
						msg += "<br>";
						msg += "<br>Thank you";
						msg += "<br>Portal Development Team";
						msg += "<br>PH: 0124-4381378";
						SendEmail.sendMail(email, msg, user.getOlm_id());

						// getServletContext().getRequestDispatcher(
						// "/BasicLogin.jsp").forward(request, response);
					} else {

						System.out.println("record not insert");
						out.println("<html>");
						out.println("<head>");
						out.println("<script type = 'text/javascript'>");
						out.println("window.alert('Your request has not been Submitted')");
						out.println("setTimeout(function(){window.location.href='tacmodification.jsp'},10);");
						out.println("</script>");
						out.println("</head>");
						out.println("</html>");
//						getServletContext().getRequestDispatcher(
//								"/tacscreation.jsp").forward(request, response);
					}
				}

			}
			if (user.getRights().equals("Read")) {
				System.out.println("inside read block ");
				boolean flag = userservice.submitTacModifiedRequest(user);
				if (flag == true) {
					System.out.println("record insert");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('Your request has been Submitted')");
					out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
					String msg = "Hi<br>";
					msg += "<br><b>You have a Tacacs Account Modification request in your bin. </b><br>";
					msg += "<br>";
					msg += "<br>Thank you";
					msg += "<br>Portal Development Team";
					msg += "<br>PH: 0124-4381378";
					SendEmail.sendMail(email, msg, user.getOlm_id());

					// getServletContext().getRequestDispatcher(
					// "/BasicLogin.jsp").forward(request, response);
				} else {

					System.out.println("record not insert");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('Your request has not been Submitted')");
					out.println("setTimeout(function(){window.location.href='tacmodification.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
					// getServletContext().getRequestDispatcher(
					// "/tacmodification.jsp").forward(request, response);
				}
			}
		}

	}

	public TacUser mapUser(HttpServletRequest request,
			HttpServletResponse response) {
		TacUser user = new TacUser();
		user.setOlm_id(request.getParameter("olmid"));
		user.setRef_id(request.getParameter("ref_id"));
		user.setRequest(request.getParameter("requestfor"));
		user.setUsType(request.getParameter("ustype"));
		user.setUsBelong(request.getParameter("u_belongs"));
		user.setPurpose(request.getParameter("purpose"));
		user.setAcReqType(request.getParameter("access"));
		user.setDept(request.getParameter("state"));
		user.setMgrname(request.getParameter("manager"));
		user.setRights(request.getParameter("rights"));
		user.setHod(request.getParameter("hod"));
		user.setVendor(request.getParameter("vd_details"));
		user.setFname(request.getParameter("first_name"));
		user.setLname(request.getParameter("last_name"));
		user.setLocation(request.getParameter("street_name"));
		user.setContact(request.getParameter("c_number"));
		user.setEmail(request.getParameter("email_id"));
		user.setDesig(request.getParameter("designation"));
		user.setHost(request.getParameter("hostName1"));
		user.setIp(request.getParameter("ipaddress1"));
		user.setCat(request.getParameter("cat1"));
		user.setSumm(request.getParameter("summary"));
		return user;
	}

}
