package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/passwordresetapprove")
public class PasswordResetApprovalByManagerController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out
				.println("Password Reset Approval By Manager Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String uuid = request.getParameter("uuid");
		String id = (String) session.getAttribute("id");
		String email = "tngnoc.systemshelpdesk@airtel.com";
		String to = userService.getUserDetailsForPasswordResetForManager(uuid)
				.getEmail_id();
		System.out.println("value of user email==>"+to);
		if (status.equals("approve")) {
			b = userService.changePasswordByManager(status, olmid, uuid);
			String msg = "Hi <br>";
			msg += "<br><b>Your NMS Password Reset Request has been Approved at Manager Level and your TOKEN ID is:</b><br>";
			msg += "<font color=red>" + uuid + "</font>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";

			SendEmail.sendMail(to, msg, id);
			String msg1 = "Hi <br>";
			msg += "<br><b>You have a NMS Account Password Reset  request in your bin.</b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";

			SendEmail.sendMail(email, msg, id);

		}
		if (status.equals("rejected")) {
			userService.changePasswordByManager(status, olmid, uuid);
			String msg = "Hi <br>";
			msg += "<br><b>Your NMS Password Reset Request has been Rejected at Manager Level and your TOKEN ID is:</b><br>";
			msg += "<font color=red>" + uuid + "</font>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";

			SendEmail.sendMail(to, msg, id);
		}
		if (b == true) {
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUserListForPasswordReset(olmid, 0);
			if (listi.size() == 0)
				request.setAttribute("passwordrequest",
						"NO PENDING PASSWORD RESET USER REQUEST FOUND..");
			System.out.println(listi);
			request.setAttribute("pendingpasswordreset", listi);
			request.getRequestDispatcher("/WEB-INF/jsp/mgrSucsessLogin.jsp")
					.forward(request, response);
		}
		if (b == false)
			request.getRequestDispatcher("/WEB-INF/jsp/mgrSucsessLogin.jsp")
					.forward(request, response);
		System.out.println("some problem occur");
	}

}
