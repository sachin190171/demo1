package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/TacModificationUserForSystem")
public class TacModUserApprovalSystemController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("TacSystem Approval For Creation Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String ticket = request.getParameter("ticket");
		String pwd = request.getParameter("Password");
		String from = "B0097268";
		String to = userService.getUserForTacCreation(olmid, "tacmoduser")
				.getEmail();
		String mgrMail = userService.getMgrEmailId(userService
				.getUserForTacCreation(olmid, "tacmoduser").getDept(),
				userService.getUserForTacCreation(olmid, "tacmoduser")
						.getMgrname());

		String name = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println("System help desk person name==>" + name);
		System.out.println(status);
		System.out.println(olmid);
		if (status.equals("approve")) {

			b = userService.changeTacUserModStatusForSystem(status, olmid,
					name, ticket, pwd);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Modification has been Approved on System level. </b><br>";
			msg += "<br><b>For any queries regarding your request, cantact Tacacs System Team.</b><br>";
			msg += "<br><b>Ph: 9810050958 </b><br>";

			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, from);
			System.out.println("Email send tac user successfully for modification");
			String msg1 = "Hi<br>";
			msg1 += "<br><b>The TACACS Account "+olmid+" for which Modification request has been raised is successfully modified.</b><br>";
			msg1 += "<br><b>To get any information regarding the request, contact System Team.  </b><br>";
			msg1 += "<br><b>Ph: 9810050958 </b><br>";

			msg1 += "<br>";
			msg1 += "<br>Thank you";
			msg1 += "<br>Portal Development Team";
			msg1 += "<br>PH: 0124-4381378";
			SendEmail.sendMail(mgrMail, msg1, from);

		}
		if (status.equals("rejected")) {
			userService.changeTacUserModStatusForSystem(status, olmid, name,
					ticket, pwd);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Modification has been Rejected on System level. </b><br>";
			msg += "<br><b>For any queries regarding your request, cantact Tacacs System Team.</b><br>";
			msg += "<br><b>Ph: 9810050958 </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, from);
			
			System.out.println("Email send tac user successfully for modification");
			String msg1 = "Hi<br>";
			msg1 += "<br><b>The TACACS Account "+olmid+" for which Modification request has been raised is not modified.</b><br>";
			msg1 += "<br><b>To get any information regarding the request, contact System Team.  </b><br>";
			msg1 += "<br><b>Ph: 9810050958 </b><br>";

			msg1 += "<br>";
			msg1 += "<br>Thank you";
			msg1 += "<br>Portal Development Team";
			msg1 += "<br>PH: 0124-4381378";
			SendEmail.sendMail(mgrMail, msg1, from);

		}
		if (status.equals("pending")) {

			userService.changeTacUserModStatusForSystem(status, olmid, name,
					ticket, pwd);
		}
		if (b == true) {

			System.out.println("inside if block");
			List<TacUser> list = new LinkedList<TacUser>();

			list = userService.getAllPendingTacModificationForSystem(1, 1, 0);
			request.setAttribute("ModificationPendingRequest", list);
			if (list.size() == 0) {
				request.setAttribute("usernopendingforsystem",
						"NO PENDING USER REQUEST FOUND..");
			}
			list = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/TacSystem.jsp").forward(request, response);

		}
		if (b == false)
			request.getRequestDispatcher("/WEB-INF/jsp/TacSystem.jsp").forward(
					request, response);
		System.out.println("some problem occur");
	}

}
