package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.Manager;
import main.java.com.airtel.model.User;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.PasswordEncDe;

public class BasicLoginController extends HttpServlet {
	private static final long serialVersionUID = 123455L;
	IUserService userService = new UserService();
	IManagerService managerService = new ManagerService();
	User user;
	Manager manager;
	int role;
	String userName;
	String password;
	int status;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		System.out.println("basic login controller");
		HttpSession session = request.getSession();
		String name = request.getParameter("user");

		String pass = request.getParameter("password");
		String enpass = PasswordEncDe.EncryptText(pass);
		System.out.println(enpass);
		System.out.println(PasswordEncDe.DecryptText(enpass));
		if (name == null || pass == null) {
			System.out.println("invalid credentials");
			System.out.println("first if block");
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('User Name or Password could not be blank.')");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			request.setAttribute("msg",
					"User Name or Password could not be null.");
			RequestDispatcher dispatch = getServletContext()
					.getRequestDispatcher("/BasicLogin.jsp");
			System.out.println(dispatch);
			dispatch.forward(request, response);
		}
		if (name.equals("") || pass.equals("")) {
			System.out.println("invalid credentials");
			System.out.println("second if block");
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('User Name or Password could not be blank.')");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			request.setAttribute("msg",
					"User Name or Password could not be null");
			RequestDispatcher dispatch = getServletContext()
					.getRequestDispatcher("/BasicLogin.jsp");
			System.out.println(dispatch);
			dispatch.forward(request, response);
		}
		user = userService.getManager(name, pass);
		manager = managerService.getmanager(name);
		status = user.getRm_status();
		userName = user.getUserName();
		password = user.getPassword();
		role = user.getRole();
		System.out.println(userName);
		System.out.println(role);
		System.out.println(status);
		System.out.println(password);
		if (name.equals(userName) && pass.equals(password)) {
			if (role == 1 && status == 2) {
				if (session.getAttribute(user.getUserName()) == null) {
				System.out.println("Admin login page");
				session.setAttribute("fname", manager.getFirstName());
				session.setAttribute("lname", manager.getLastName());
				session.setAttribute("olm", user.getUserName());
				session.setAttribute(user.getUserName(), user.getUserName());
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/adminSuccessLogin.jsp").forward(request,
						response);
			}
				else {
					System.out.println((user.getUserName()));
					System.out.println("inside else block");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('YOU ARE ALREADY LOGGED IN')");
					out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
				}
			}

		}
		if (name.equals(userName) && pass.equals(password)) {
			if (role == 2 && status == 3) {
				if (session.getAttribute(user.getUserName()) == null) {
				System.out.println("System help desk page");
				session.setAttribute("fname", manager.getFirstName());
				session.setAttribute("lname", manager.getLastName());
				session.setAttribute(user.getUserName(), user.getUserName());
				session.setAttribute("system", user.getUserName());
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/systemHelpDeskLogin.jsp").forward(
						request, response);
			}else {
				System.out.println((user.getUserName()));
				System.out.println("inside else block");
				out.println("<html>");
				out.println("<head>");
				out.println("<script type = 'text/javascript'>");
				out.println("window.alert('YOU ARE ALREADY LOGGED IN')");
				out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
				out.println("</script>");
				out.println("</head>");
				out.println("</html>");
			}
			}

		}
		if (name.equals(userName) && pass.equals(password)) {
			if (role == 3 && status == 3) {
				if (session.getAttribute(user.getUserName()) == null) {
					System.out.println("Tacacs Admin Page");
					session.setAttribute("fname", manager.getFirstName());
					session.setAttribute("lname", manager.getLastName());
					session.setAttribute(user.getUserName(), user.getUserName());
					session.setAttribute("tacsystem", user.getUserName());
					getServletContext().getRequestDispatcher(
							"/WEB-INF/jsp/TacSystem.jsp").forward(
							request, response);
				} else {
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('YOU ARE ALREADY LOGGED IN')");
					out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
				}
			}

		}
		
		if (name.equals(userName) && pass.equals(password)) {
			if (role == 4 && status == 4) {
				if (session.getAttribute(user.getUserName()) == null) {
					System.out.println("MPLS Admin Page");
					session.setAttribute("fname", manager.getFirstName());
					session.setAttribute("lname", manager.getLastName());
					session.setAttribute(user.getUserName(), user.getUserName());
					session.setAttribute("mplssystem", user.getUserName());
					getServletContext().getRequestDispatcher(
							"/WEB-INF/jsp/MplsSystem.jsp").forward(
							request, response);
				} else {
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('YOU ARE ALREADY LOGGED IN')");
					out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
				}
			}

		}
		
		////////////////////////////
		
		if (name.equals(userName) && pass.equals(password)) {
			if (role == 4 && status == 5) {
				//////////////////////////////////////
				
				if (session.getAttribute(user.getUserName()) == null) {
					System.out.println("MPLS Manager's Page");
					System.out.println(manager.getFullName());
					session.setAttribute("username", manager.getFullName());
					session.setAttribute(user.getUserName(),user.getUserName());
					session.setAttribute("olid", manager.getOlmId());								
					getServletContext().getRequestDispatcher(
							"/WEB-INF/jsp/MplsManager.jsp").forward(
							request, response);
				} else {
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('YOU ARE ALREADY LOGGED IN')");
					out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
				}
			}

		}
		
		////////////////////////////
		if (name.equals(userName) && pass.equals(password) && status == 0) {
			System.out.println("YOUR ACCOUNT HAS NOT ACTIVATED");

			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your Account Has Not Activated')");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			// RequestDispatcher dispatch = getServletContext()
			// .getRequestDispatcher("/WEB-INF/jsp/notsucesslogin.jsp");
			// dispatch.forward(request, response);

		} else {
			System.out.println("login");

			try {
				System.out.println("correct password");

				if (name.equals(userName) && pass.equals(password) && role == 0
						&& status == 1) {
					
					System.out.println("inside correct If E>>>>>>>>>>>>>>>");
					if (session.getAttribute(user.getUserName()) == null) {
					System.out.println(manager.getFullName());
					session.setAttribute("username", manager.getFullName());
					session.setAttribute(user.getUserName(),
							user.getUserName());
					session.setAttribute("id", manager.getOlmId());
					getServletContext().getRequestDispatcher(
							"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(
							request, response);
					// getServletContext().getRequestDispatcher(
					// "/WEB-INF/jsp/managerlogin.jsp").forward(
					// request, response);

				}else {
					System.out.println((user.getUserName()));
					System.out.println("inside else block");
					out.println("<html>");
					out.println("<head>");
					out.println("<script type = 'text/javascript'>");
					out.println("window.alert('YOU ARE ALREADY LOGGED IN')");
					out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
					out.println("</script>");
					out.println("</head>");
					out.println("</html>");
				}
				}
			} catch (Exception e) {
				e.printStackTrace();

			}

			if (!name.equals(userName) || !pass.equals(password)) {
				System.out.println("login.java 2");
				out.println("<html>");
				out.println("<head>");
				out.println("<script type = 'text/javascript'>");
				out.println("window.alert('Please Enter Correct Username or Password')");
				out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
				out.println("</script>");
				out.println("</head>");
				out.println("</html>");

				// request.setAttribute("msg",
				// "Please enter correct username or password");
				RequestDispatcher dis = getServletContext()
						.getRequestDispatcher("/BasicLogin.jsp");
				dis.include(request, response);

			}

			// response.sendRedirect("index.jsp");
			if (request.getSession().getAttribute("user") != null) {
				out.println("<html>");
				out.println("<head>");
				out.println("<script type = 'text/javascript'>");
				out.println("window.alert('YOU ARE ALREADY LOGGED IN')");
				out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
				out.println("</script>");
				out.println("</head>");
				out.println("</html>");
			}

		}
	}

}
