package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;
import main.java.com.airtel.utility.StringUtility;

@WebServlet(urlPatterns = "/modifiedUserforsystem")
public class ModifiedUserBySystemController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("Modified User By System Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String caption = request.getParameter("action");
		String rticket = request.getParameter("rticket");
		String uuid = request.getParameter("uuid");
		String name = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println("System help desk person name==>" + name);
		System.out.println(caption);
		System.out.println(status);
		System.out.println(olmid);
		String nms = StringUtility.checkNUllForSpace(request
				.getParameter("eci"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("alcatel"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("huawei"))
				+ StringUtility
						.checkNUllForSpace(request.getParameter("ciena"))
				+ StringUtility.checkNUllForSpace(request
						.getParameter("nortel"))
				+ StringUtility
						.checkNUllForSpace(request.getParameter("tejas"))
				+ StringUtility.checkNUllForSpace(request.getParameter("adr"));
		String email = userService.getUserDetailsForModification(olmid)
				.getEmail_id();
		String mgrMail = userService.getMgrEmailId(userService
				.getUserDetailsForModification(olmid).getState(), userService
				.getUserDetailsForModification(olmid).getManager());
		String id="A1CCAAWG";
		if (status.equals("approve")){
			b = userService.modifiedUserStatusForSystem(status, olmid, name,
					nms,rticket,uuid);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Modification has been Approved on System level.  </b><br>";
			msg += "<br><b>To get any information regarding your request, contact System Team.  </b><br>";
			msg += "<br><b>Ph: 0124-4282445  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
			
			System.out.println("email send successfully...");
			String msg1 = "Hi<br>";
			msg1 += "<br><b>The Account "+userService
					.getUserDetailsForModification(olmid)+" for which Modification request has been raised is successfully modified.</b><br>";
			msg1 += "<br><b>To get any information regarding the request, contact System Team.  </b><br>";
			msg1 += "<br><b>Ph: 0124-4282445  </b><br>";
			msg1 += "<br>";
			msg1 += "<br>Thank you";
			msg1 += "<br>Portal Development Team";
			msg1 += "<br>PH: 0124-4381378";
			SendEmail.sendMail(mgrMail, msg1, id);
		}
		if (status.equals("rejected")){
			userService.modifiedUserStatusForSystem(status, olmid, name, nms,rticket,uuid);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Modification has been Rejected on System level.  </b><br>";
			msg += "<br><b>To get any information regarding your request, contact System Team.  </b><br>";
			msg += "<br><b>Ph: 0124-4282445  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
			
			System.out.println("email send successfully...");
			String msg1 = "Hi<br>";
			msg1 += "<br><b>The Account "+userService
					.getUserDetailsForModification(olmid)+" for which Modification request has been raised is not modified.</b><br>";
			msg1 += "<br><b>To get any information regarding the request, contact System Team.  </b><br>";
			msg1 += "<br><b>Ph: 0124-4282445  </b><br>";
			msg1 += "<br>";
			msg1 += "<br>Thank you";
			msg1 += "<br>Portal Development Team";
			msg1 += "<br>PH: 0124-4381378";
			SendEmail.sendMail(mgrMail, msg1, id);
		}
		if (status.equals("progress")) {
			userService.modifiedUserStatusForSystem(status, olmid, name, nms,rticket,uuid);
		}
		if (b == true) {
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUnactivatedUserForHelpDesk(1, 1, 0);
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllUserFromDeletedForSystem(1, 0,0);
			List<NewUser> mlist = new LinkedList<NewUser>();
			mlist = userService.getAllModifiedUserForHelpDesk(1, 1, 0);
			System.out.println(listi);
			session.setAttribute("pendingrequest", listi);
			request.setAttribute("deletedpending", list);
			request.setAttribute("modifiedpending", mlist);
			request.getRequestDispatcher("/WEB-INF/jsp/systemHelpDeskLogin.jsp")
					.forward(request, response);
		}
		if (b == false)
			request.getRequestDispatcher("/WEB-INF/jsp/systemHelpDeskLogin.jsp")
					.forward(request, response);
		System.out.println("some problem occur");
	}

}
