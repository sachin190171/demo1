package main.java.com.airtel.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

@WebServlet(urlPatterns = "/getMplsUserDetailsForMplsManager")
public class MplsManagerController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
			IUserService userService = new UserService();
		String olmid = null;
		HttpSession session = request.getSession(false);
		response.setContentType("text/html");
		
		// out.println("Invalid Login");
		System.out.println("MPLS ManagerFunction controller called");
		String caption = request.getParameter("action");
		String value = request.getParameter("action");
		String id = (String) session.getAttribute("olid");
		System.out.println("id>>>>>"+id);
		System.out.println(id);
		System.out.println(caption);
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			System.out.println("ar>>>>>>>>>>>"+ar[0]);
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
			if (caption.equals("Pending User Request")) {
				List<MplsUser> listpen = new LinkedList<MplsUser>();
				List<MplsUser> mlist = new ArrayList<MplsUser>();
				listpen = userService.getAllPendingMplsCreation(0, id);
				mlist = userService.getAllPendingMplsCreationForHOD(1, id, 0,
						"mplsuser");
				
				if (listpen.size() == 0 && mlist.size() == 0) {
					System.out.println("size of pending list is>>>>>>>>"+listpen.size());
						request.setAttribute("zeropending",
								"NO PENDING REQUEST AVAILABLE ..");
					
						getServletContext().getRequestDispatcher(
								"/WEB-INF/jsp/MplsManager.jsp").forward(request,
								response);
				}
					else if(mlist.size() != 0) {
						//request.setAttribute("pending", listpen);
						request.setAttribute("taclistforHod", mlist);
						System.out.println("<<<<<<<<<<<<<<<<<<<<<<aya nhi isme mlist not zero " +mlist.size());
						getServletContext().getRequestDispatcher(
								"/WEB-INF/jsp/MplsManager.jsp").forward(request,
								response);
					}
					else if(listpen.size() != 0) {
						request.setAttribute("pending", listpen);
						//request.setAttribute("taclistforhod", mlist);
						listpen = null;
						getServletContext().getRequestDispatcher(
								"/WEB-INF/jsp/MplsManager.jsp").forward(request,
								response);
					}
					/*listpen = null;
					mlist = null;
					*//*getServletContext().getRequestDispatcher(
							"/WEB-INF/jsp/MplsManager.jsp").forward(request,
							response);*/
				}
			
			if (caption.equals("view details ")) {
				System.out.println("inside MPLS manager functional controller view details for creation");
				MplsUser user = new MplsUser();
				user = userService.getMplsUserDetails(olmid.substring(1, olmid.length()));

				session.setAttribute("MplsUser", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/viewMplsUserFrManager.jsp").forward(request, response);

			}
			
	/////////////////////// Password reset request ///////////////////////////		
			
		if (caption.equals("Password Reset Request")) {
			List<MplsUser> plist = new ArrayList<MplsUser>();
			System.out.println("Inside MPLS password pending request");			
			plist = userService.getAllPendingMplsPwdReset(0,id);

			if(plist.size()==0){
				request.setAttribute("nopendingforpassword",
						"NO PENDING REQUEST AVAILABLE..");
			
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/MplsManager.jsp").forward(request,
						response);
			}
			
			else{
				request.setAttribute("passwordpending", plist);
					
			}
			plist = null;
			
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsManager.jsp").forward(request,
					response);
		}
		
		////////////////////////////////////// show password reset details /////////////
		if (caption.equals("show details ")) {
				System.out
					.println("inside MPLS manager functional controller view details for MPLS password reset ");
			System.out.println(olmid.substring(1, olmid.length()));
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsPwdReset(
					olmid.substring(1, olmid.length()).trim());
			session.setAttribute("User", user);//change MplsUser to User by abhishek maurya
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsuserForPwdReset.jsp").forward(request,
					response);

		}
		////////////////////////////////////// for deletion request  //////////////////////////////////////////////
		if (caption.equals("User Deletion Request")) {

			List<MplsUser> dlist = new ArrayList<MplsUser>();
			System.out.println("Inside MPLS password DELETION request");			
			dlist = userService.getAllPendingMplsDeletion(0,id);

			if(dlist.size()==0){
				request.setAttribute("nopendingfordeletion",
						"NO PENDING REQUEST AVAILABLE..");
			}
			else
			{
				request.setAttribute("deletedpending", dlist);
					
			}
			dlist = null;
			
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsManager.jsp").forward(request,
					response);
		}
		if (caption.equals("view detail's ")) {
			System.out
					.println("inside manager functional controller view details for creation");
			
			System.out.println(olmid.substring(1, olmid.length()));

			MplsUser user = new MplsUser();
			user = userService.getUserForMplsDeletion(olmid.substring(1,olmid.length()).trim());

			session.setAttribute("User", user); //change MplsUser to User by abhishek maurya
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsDelUsrFrMngr.jsp").forward(
					request, response);
		}
			
///////////////////////////////////////>>>>>>>>>>>>>WORKING HERE  user modification request>>>>>>>>////////////////////////////////////////////////////////
		if (caption.equals("User Modification Request")) {
			System.out.println("Modification has reached");
			List<MplsUser> mlist = new ArrayList<MplsUser>();
			mlist = userService.getAllPendingMplsModification(0, id);
			System.out.println("tttttttttttyyyyyyyy");
			List<MplsUser> nlist = new ArrayList<MplsUser>();
			nlist = userService.getAllPendingMplsCreationForHOD(1, id,0,
					"mplsmoduser");
			System.out.println("tttttttttttyyyyyyyy"+nlist);
			if(mlist.size()==0 && nlist.size()==0){
				request.setAttribute("nopendingformodification",
						"NO PENDING REQUEST AVAILABLE..");
			
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/MplsManager.jsp").forward(request,
						response);
			
			}
			else if (mlist.size() !=0)
			{
				request.setAttribute("mplsmod", mlist);	
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/MplsManager.jsp").forward(request,
						response);
			
			}
			else if (nlist.size() !=0)
			{
				request.setAttribute("tacmodhod", nlist);	
			
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/MplsManager.jsp").forward(request,
						response);
			}
			/*mlist = null;
			nlist = null;

			*/
		}
		
		
		
	/////////////////////// get details of the user modification details ////////////////// 	
		
		if (caption.equals("Get detail ")) {
			System.out
					.println("inside manager functional controller view details for MPLS modification ");
			System.out.println(olmid.substring(1, olmid.length()));
			MplsUser user = new MplsUser();
			
			
			user = userService.getUserForMplsCreation(
					olmid.substring(1, olmid.length()).trim(), "mplsmoduser");
			//session.setAttribute("MplsUser", user);
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher
			(	"/WEB-INF/jsp/viewMplsModUserForManager.jsp").forward(
					request, response);

		}
		////////////////////////////// HOD HOD HOD HOD HOD ///////////////////////////////////////////////////////////
		
		/*if (caption.equals("Pending User Request")) {

			List<MplsUser> mlist = new ArrayList<MplsUser>();
			mlist = userService.getAllPendingMplsCreationForHOD(1, id, 0,
					"mplsuser");
				
			if(mlist.size()==0){
				request.setAttribute("nopendingformodification",
						"NO PENDING REQUEST AVAILABLE..");
			}
			else
			{
				request.setAttribute("taclistforhod", mlist);	
			}
			mlist = null;
			
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsManager.jsp").forward(request,
					response);
		}
*/
		
		/*if (caption.equals("User Modification Request")) {
			List<MplsUser> mlist = new ArrayList<MplsUser>();
			mlist = userService.getAllPendingMplsCreationForHOD(1, id,0,
					"mplsmoduser");
				
			if(mlist.size()==0){
				request.setAttribute("nopendingformodification",
						"NO PENDING REQUEST AVAILABLE..");
			}
			else
			{
				request.setAttribute("tacmodhod", mlist);	
			}
			mlist = null;
			
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/MplsManager.jsp").forward(request,
					response);
		}*/
		
		if (caption.equals("Get detail's ")) {
			System.out.println("inside new HOD manager controller view details for MPLS/IP creation ");
			System.out.println(olmid.substring(1, olmid.length()));
		
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsCreation(
					olmid.substring(1, olmid.length()).trim(), "mplsuser");
			System.out.println("userr>>>>>>>"+user);
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsUserForHod.jsp").forward(request,
					response);
		}
		if (caption.equals("Get All details ")) {
			System.out.println("inside HOD manager controller view details for MPLS/IP Modification ");
			System.out.println(olmid.substring(1, olmid.length()));
		
			MplsUser user = new MplsUser();
			user = userService.getUserForMplsCreation(
					olmid.substring(1, olmid.length()).trim(), "mplsmoduser");
			session.setAttribute("User", user);
			
			System.out.println(">>>>>>>>>> hod modification"+user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewMplsModUserForHod.jsp").forward(request,
					response);
		}
		
		
		/////////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////
		if (caption.equals("Get details ")) {
				System.out.println("inside MPLS manager controller view details for MPLS/IP creation ");
				System.out.println(olmid.substring(1, olmid.length()));
			
				MplsUser user = new MplsUser();
				user = userService.getUserForMplsCreation(
						olmid.substring(1, olmid.length()).trim(), "mplsuser");
				session.setAttribute("MplsUser", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/viewMplsUserForManager.jsp").forward(request,
						response);
			}
			
			if (caption.equals("Fetch details ")) {
				System.out
						.println("inside MPLS manager controller view details for MPLS password reset ");
				System.out.println(olmid.substring(1, olmid.length()));
				MplsUser user = new MplsUser();
			user = userService.getUserForMplsPwdReset(
						olmid.substring(1, olmid.length()).trim());
				session.setAttribute("User", user);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/viewMplsuserForPwdReset.jsp").forward(request,
						response);

			}
////////////////////////////////////////////////////////
			if (caption.equals("Created User List")) {
				List<MplsUser> listpen = new LinkedList<MplsUser>();
				listpen = userService.getAllMplsUser(1, id);
				
				List<MplsUser> dlist = new LinkedList<MplsUser>();
				dlist = userService.getMplsUserFromDeleted(1, id);
				
				List<MplsUser> mlist = new LinkedList<MplsUser>();
				mlist  = userService.getMplsUserFromModified(1, id);
				
				List<MplsUser> plist = new LinkedList<MplsUser>();
				plist = userService.getMplsUserListForPasswordReset(id,1);
				
				
				System.out.println(listpen);
				System.out.println(session.getAttribute("olid"));
				request.setAttribute("approved", listpen);
				request.setAttribute("deletedapproved", dlist);
				request.setAttribute("modifiedapproved", mlist);
				request.setAttribute("pwdreset", plist);
				listpen = null;
				getServletContext().getRequestDispatcher(
						"/WEB-INF/jsp/MplsManager.jsp").forward(request,
						response);
			}
			
		if (caption.equals("Log Out")) {
			if (session != null) {
				String olmi = (String) session.getAttribute("olid");
				System.out.println("LOG OUT ==>" + session.getAttribute("olid"));
				session.removeAttribute(olmi);
				// session.invalidate();

			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}
		
	}
}
	
