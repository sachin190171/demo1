package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

public class SuccessLoginController extends HttpServlet {
	private static final long serialVersionUID = 1234L;
	NewUser nUser;
	PrintWriter out;
    IUserService userService = new UserService(); 
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession();
		nUser = mapUser(request, response);
		userService.addUser(nUser);
		

	}

	public NewUser mapUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		NewUser user = new NewUser();
		user.setFirst_name(request.getParameter("first_name"));
		user.setC_number(request.getParameter("c_number"));
		user.setUuid(request.getParameter("first_name")+request.getParameter("c_number"));
		user.setLast_name(request.getParameter("last_name"));
		user.setStreet_name(request.getParameter("street_name"));
		user.setState(request.getParameter("state"));
		user.setManager(request.getParameter("manager"));
		user.setRequestfor(request.getParameter("requestfor"));
		user.setUstype(request.getParameter("ustype"));
		user.setUser_id(request.getParameter("user_id"));
		user.setEmail_id(request.getParameter("email_id"));
		user.setU_belongs(request.getParameter("u_belongs"));
		user.setUt_name(request.getParameter("ut_name"));
		user.setVd_details(request.getParameter("vd_details"));
		user.setDesignation(request.getParameter("designation"));
		user.setPurpose(request.getParameter("purpose"));
		user.setApplicationAccess(request.getParameterValues("app_access"));
		user.setEci(request.getParameterValues("eci"));
		user.setAlcatel(request.getParameterValues("alcatel"));
		user.setHuawei(request.getParameterValues("huawei"));
		user.setCiena(request.getParameterValues("ciena"));
		user.setNortel(request.getParameterValues("nortel"));
		user.setTejas(request.getParameterValues("tejas"));
		user.setAdr(request.getParameterValues("adr"));

		System.out.println(user);

		return user;
	}

}
