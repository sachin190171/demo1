package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/TacCreationUser")
public class ManagerApprovalForTacUser extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IManagerService managerService = new ManagerService();
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("Manager Approval For TacUser controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String right = request.getParameter("rights"); 
		String id = (String)session.getAttribute("id");
		String to= userService.getUserForTacCreation(olmid, "tacuser").getEmail();
		System.out.println("email to==>"+to);
		System.out.println("id"+id);
		String mgrName = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println(status);
		System.out.println(olmid);
		if (status.equals("approve")){
			b = userService.changeTacUserStatusForManager(status, olmid,
					mgrName,right,"tacuser");
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation on TACACS has been Approved on Manager level. </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);	
		}
		if (status.equals("rejected")){
			userService.changeTacUserStatusForManager(status, olmid, mgrName,right,"tacuser");
			
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation on TACACS has been Rejected on Manager level. </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(to, msg, id);	
			
		}
		if (b == true) {
			List<TacUser> listi = new LinkedList<TacUser>();
			listi = userService.getAllPendingTacCreation(0,id);
			System.out.println(listi);
			request.setAttribute("taclist", listi);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mgrSucsessLogin.jsp").forward(request,
					response);
		}
		if (b == false) {
			System.out.println("some problem occur");
			request.getRequestDispatcher("/WEB-INF/jsp/mgrSucsessLogin.jsp")
					.forward(request, response);
		}

	}

}
