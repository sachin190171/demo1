package main.java.com.airtel.controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/UserdeletionStatus")
public class  DeleteUserByManagerController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		IUserService userService = new UserService();
		Boolean b = false;
		response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("Delete User By Manager Controller called");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String id = (String)session.getAttribute("id");
		System.out.println(status);
		System.out.println(olmid);
		String email = userService.getUserDetailsForDeletion(olmid).getEmail_id();
		String sysemail= "tngnoc.systemshelpdesk@airtel.com";
		if (status.equals("approve")){
		b = userService.changeUserStatusForDeletion(status, olmid);
		String msg = "Hi<br>";
		msg += "<br><b>Your request for Account Deletion has been Approved on Manager level.  </b><br>";
		msg += "<br>";
		msg += "<br>Thank you";
		msg += "<br>Portal Development Team";
		msg += "<br>PH: 0124-4381378";
		SendEmail.sendMail(email, msg, id);
		String msg1 = "Hi<br>";
		msg1 += "<br><b>you have a NMS Account Deletion  request in your bin.  </b><br>";
		msg += "<br>";
		msg1 += "<br>Thank you";
		msg1 += "<br>Portal Development Team";
		msg1 += "<br>PH: 0124-4381378";
		SendEmail.sendMail(sysemail, msg1, id);
		}
		else if(status.equals("rejected")){
			userService.changeUserStatus(status, olmid);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Deletion has been Rejected on Manager level.  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
		}
		if (b == true) {
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUser(0,id);
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllUserFromDeleted(0, id);
			System.out.println(listi);
			request.setAttribute("pending", listi);
			request.setAttribute("deletedpending", list);
			request.getRequestDispatcher("/WEB-INF/jsp/mgrSucsessLogin.jsp")
					.forward(request, response);
		}
		if (b == false){
			System.out.println("some problem occur");
		request.getRequestDispatcher("/WEB-INF/jsp/mgrSucsessLogin.jsp")
				.forward(request, response);
		}
	}

}

