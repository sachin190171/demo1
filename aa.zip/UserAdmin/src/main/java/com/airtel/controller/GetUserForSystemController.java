package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

public class GetUserForSystemController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	String caption;
	String value;
	String olmid;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String olm;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		System.out.println(" GetUserForSystem controller called");
		HttpSession session = request.getSession(false);
		caption = request.getParameter("action");
		System.out.println(caption);
		value = request.getParameter("action");
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
		System.out.println(olmid);
		if (caption.equals("Pending User Request")) {
			System.out.println("inside if block");
			List<NewUser> listi = new LinkedList<NewUser>();
			List<NewUser> dlist = new LinkedList<NewUser>();
			listi = userService.getAllUnactivatedUserForHelpDesk(1, 1, 0);
			dlist = userService.getAllUserFromDeletedForSystem(1,0,0);
			List<NewUser> mlist = new LinkedList<NewUser>();
			mlist = userService.getAllModifiedUserForHelpDesk(1, 1, 0);
			System.out.println(listi);
			request.setAttribute("pendingrequest", listi);
			request.setAttribute("deletedpending", dlist);
			request.setAttribute("modifiedpending", mlist);
			
			if (listi.size() == 0 && dlist.size() == 0
					&& mlist.size() == 0&& dlist.size() == 0) {
				request.setAttribute("usernopendingforsystem",
						"NO PENDING USER REQUEST FOUND..");
			}
			listi = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/systemHelpDeskLogin.jsp").forward(request,
					response);
		}
		if (caption.equals("In Progress User Request")) {
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllUnactivatedUserForHelpDesk(1, 1, 3);
			
			request.setAttribute("progress", list);
			List<NewUser> dlist = new LinkedList<NewUser>();
			dlist = userService.getAllUserFromDeletedForSystem(1,3,3);
			List<NewUser> alist = new LinkedList<NewUser>();
			alist = userService.getAllUserListForPasswordResetForSys(3, 1);
			List<NewUser> mlist = new LinkedList<NewUser>();
			mlist = userService.getAllModifiedUserForHelpDesk(1, 1, 3);
			request.setAttribute("modifiedinprogress", mlist);
			request.setAttribute("pwdprogress", alist);
			request.setAttribute("deleteprogress", dlist);
			if (list.size() == 0 && alist.size() == 0 && mlist.size() == 0&& dlist.size() == 0) {
				request.setAttribute("usernopendingforsystem",
						"NO IN PROGRESS USER REQUEST FOUND..");
			}
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/systemHelpDeskLogin.jsp").forward(request,
					response);
		}
		if (caption.equals("MIS")) {
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/mis.jsp").forward(request,
					response);
		}
		if (caption.equals("Created User List")) {
			List<NewUser> alist = new LinkedList<NewUser>();
			alist = userService.getAllUnactivatedUserForHelpDesk(1, 1, 1);
			List<NewUser> list = new LinkedList<NewUser>();
			list = userService.getAllUserFromDeletedForSystem(1, 1,1);
			List<NewUser> mlist = new LinkedList<NewUser>();
			mlist = userService.getAllModifiedUserForHelpDesk(1, 1, 1);
			List<NewUser> pwdlist = new LinkedList<NewUser>();
			pwdlist = userService.getAllUserListForPasswordResetForSys(1, 1);
			System.out.println(alist);
			request.setAttribute("approvedrequest", alist);
			request.setAttribute("deletedrequest", list);
			request.setAttribute("approvedmodified", mlist);
			request.setAttribute("passwordresetsuccessfully", pwdlist);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/systemHelpDeskLogin.jsp").forward(request,
					response);

		}
		if (caption.equals("Password Reset Request")) {
			List<NewUser> alist = new LinkedList<NewUser>();
			alist = userService.getAllUserListForPasswordResetForSys(0, 1);
			System.out.println(alist);
			if (alist.size() == 0)
				request.setAttribute("passwordrequest",
						"NO PENDING PASSWORD RESET USER REQUEST FOUND..");
			request.setAttribute("pendingpasswordreset", alist);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/systemHelpDeskLogin.jsp").forward(request,
					response);

		}

		if (caption.equals("view details ")) {
			System.out.println("inside manager id if");
			NewUser user = new NewUser();
			user = userService
					.getUserDetails(olmid.substring(1, olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/ViewUserForSystemHelpActivation.jsp")
					.forward(request, response);

		}
		if (caption.equals("view detail's ")) {
			System.out.println("inside manager id if");
			NewUser user = new NewUser();
			user = userService.getUserDetailsForDeletion(olmid.substring(1,
					olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/systemviewuserfordelete.jsp").forward(
					request, response);

		}
		if (caption.equals("view detail's. ")) {
			System.out.println("inside manager id if");
			NewUser user = new NewUser();
			user = userService.getUserDetailsForModification(olmid.substring(1,
					olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewUserBySystemForModified.jsp").forward(
					request, response);

		}
		if (caption.equals("show detail's ")) {
			System.out.println("inside manager id if");
			NewUser user = new NewUser();
			user = userService.getUserDetailsForPasswordReset(olmid.substring(
					1, olmid.length()));
			session.setAttribute("User", user);
			session.setAttribute("app", user.getApplicationAccess());
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/passwordReset.jsp")
					.forward(request, response);

		}
		if (caption.equals("Log Out")) {
			if (session != null) {
				String system = (String) session.getAttribute("system");
				System.out.println(session.getAttribute("system"));
				session.removeAttribute(system);
				//session.removeAttribute("user");
				//session.invalidate();

			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}
	}
}
