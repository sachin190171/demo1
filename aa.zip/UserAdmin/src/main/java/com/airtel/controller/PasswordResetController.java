package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;
import main.java.com.airtel.utility.StringUtility;

@WebServlet(urlPatterns = "/passwordreset")
public class PasswordResetController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	IUserService userService = new UserService();
	NewUser user;
	Random r = new Random();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		System.out.println("password reset controller called sucessfully");
		int i = r.nextInt(99999) + 100;
		String id = request.getParameter("olmid");
		String manager = request.getParameter("manager");
		String uuid = id + "_" + i;
		user = mapUser(request, response);
		boolean b = userService.checkIdForUserPasswordReset(uuid);
		String email = userService.getMgrEmailId(user.getState(),
				manager);
		
		System.out.println("email id==>"+email);
		System.out.println("Olm id==>"+id);

		if (b == false) {
			System.out
					.println("inside false block in password reset contrller");
			userService.addUserInPasswordReset(user, uuid);
			
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your Request For Password change Has Been Accepted And Your Ticket ID Is "
					+ "  " + uuid + "' )");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			String msg = "Hi<br>";
			msg += "<br><b>You have a NMS Password Reset request in your bin.  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);

		} else {
			System.out.println("inside true block in password reset contrller");
			userService.addUserInPasswordReset(user, uuid);
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Your Request For Password change Has Been Accepted And Your Ticket ID Is "
					+ "  " + uuid + "' )");
			out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");

		}

	}

	public NewUser mapUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		NewUser user = new NewUser();
		String nms = null;
		user.setOlm_id(request.getParameter("olmid"));
		user.setNms_id(request.getParameter("nmsid"));
		user.setState(request.getParameter("state"));
		user.setEmail_id(request.getParameter("emailid"));
		user.setManager(request.getParameter("manager"));
		user.setApplicationAccess(request.getParameterValues("app_access"));
		user.setEci(request.getParameterValues("eci"));
		user.setAlcatel(request.getParameterValues("alcatel"));
		user.setHuawei(request.getParameterValues("huawei"));
		user.setCiena(request.getParameterValues("ciena"));
		user.setNortel(request.getParameterValues("nortel"));
		user.setTejas(request.getParameterValues("tejas"));
		user.setAdr(request.getParameterValues("adr"));
		nms = StringUtility.checkNUllForNms(StringUtility
				.getStringForNotNull(request.getParameterValues("eci")))
				+ StringUtility.checkNUllForNms(StringUtility
						.getStringForNotNull(request
								.getParameterValues("alcatel")))
				+ StringUtility.checkNUllForNms(StringUtility
						.getStringForNotNull(request
								.getParameterValues("huawei")))
				+ StringUtility.checkNUllForNms(StringUtility
						.getStringForNotNull(request
								.getParameterValues("ciena")))
				+ StringUtility.checkNUllForNms(StringUtility
						.getStringForNotNull(request
								.getParameterValues("nortel")))
				+ StringUtility.checkNUllForNms(StringUtility
						.getStringForNotNull(request
								.getParameterValues("tejas")))
				+ StringUtility
						.checkNUllForNms(StringUtility
								.getStringForNotNull(request
										.getParameterValues("adr")));
		user.setNms(nms);
		System.out.println(user);

		return user;
	}

}
