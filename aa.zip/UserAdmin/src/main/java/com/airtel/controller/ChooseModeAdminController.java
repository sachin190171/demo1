package main.java.com.airtel.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.ManagerService;

public class ChooseModeAdminController extends HttpServlet {

	private static final long serialVersionUID = 112L;

	String caption;
	String value;
	String olmid;
	IManagerService managerService = new ManagerService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		System.out.println("ChooseModeAdminController called");
		HttpSession session = request.getSession(false);
		caption = request.getParameter("action");
		System.out.println(caption);
		if (caption.equals("RM REQUEST")) {

			getServletContext()
					.getRequestDispatcher("/WEB-INF/jsp/admin.jsp").forward(
							request, response);
		}
		if (caption.equals("USERS REQUEST")) {

			getServletContext()
					.getRequestDispatcher("/WEB-INF/jsp/userdetailsforadmin.jsp").forward(
							request, response);
		}
		if (caption.equals("Log Out")) {
			if (session != null){
				String olmi = (String) session.getAttribute("olm");
				System.out.println("inside admin logout value==>"+session.getAttribute("olm"));
				session.removeAttribute(olmi);
				//session.invalidate();
			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}
		
	}
}
