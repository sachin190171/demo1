package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.service.IManagerService;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.ManagerService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

public class AdminApprovalForUserController extends HttpServlet {

	private static final long serialVersionUID = 12L;
	IManagerService managerService = new ManagerService();
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Boolean b = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		HttpSession session = request.getSession(false);
		System.out.println("AdminApprovalForUserControllerr called");
		System.out.println("get dispatch");
		String status = request.getParameter("status");
		String olmid = request.getParameter("olm");
		String caption = request.getParameter("action");
		String adminName = (String) session.getAttribute("fname") + " "
				+ (String) session.getAttribute("lname");
		System.out.println(caption);
		System.out.println(status);
		System.out.println(olmid);
		String id = "B0068755";
		String email = userService.getUserDetails(olmid).getEmail_id();
		String sysemail = "tngnoc.systemshelpdesk@airtel.com";
		if (status.equals("approve")) {
			b = userService.changeUserStatusForAdmin(status, olmid, adminName);
			
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation has been Approved on Admin level.  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
			String msg1 = "Hi<br>";
			msg1 += "<br><b>You have a NMS Account Creation  request in your bin.  </b><br>";
			msg1 += "<br>";
			msg1 += "<br>Thank you";
			msg1 += "<br>Portal Development Team";
			msg1+= "<br>PH: 0124-4381378";
			SendEmail.sendMail(sysemail, msg1, id);
		}
		if (status.equals("rejected")) {
			userService.changeUserStatusForAdmin(status, olmid, adminName);
			String msg = "Hi<br>";
			msg += "<br><b>Your request for Account Creation has been Rejected on Admin level.  </b><br>";
			msg += "<br>";
			msg += "<br>Thank you";
			msg += "<br>Portal Development Team";
			msg += "<br>PH: 0124-4381378";
			SendEmail.sendMail(email, msg, id);
		}
		if (b == true) {
			List<NewUser> listi = new LinkedList<NewUser>();
			listi = userService.getAllUnactivatedUserForAdmin(1, 0);
			System.out.println(listi);
			session.setAttribute("pending", listi);
			request.getRequestDispatcher("/WEB-INF/jsp/userdetailsforadmin.jsp")
					.forward(request, response);
		}
		if (b == false) {
			System.out.println("some problem occur");
			request.getRequestDispatcher("/WEB-INF/jsp/userdetailsforadmin.jsp")
					.forward(request, response);
		}

	}

}
