package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import main.java.com.airtel.model.NewUser;
import main.java.com.airtel.model.TacUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;

@WebServlet(urlPatterns = "/getTacUserDetailsForSystem")
public class TacsSystemController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	String caption;
	String value;
	String olmid;
	IUserService userService = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String olm;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// out.println("Invalid Login");
		System.out.println(" TacsSystem Controller called");
		HttpSession session = request.getSession(false);
		caption = request.getParameter("action");
		System.out.println(caption);
		value = request.getParameter("action");
		System.out.println(value);
		if (value != null) {
			String[] ar = value.split("of");
			for (int i = 0; i < ar.length; i++) {
				if (i == 0)
					caption = ar[0];
				if (i == 1)
					olmid = ar[1];
			}
		}
		System.out.println(olmid);
		System.out.println("called");
		if (caption.equals("Pending User Request")) {
			System.out.println("inside if block");
			List<TacUser> list = new LinkedList<TacUser>();
			list = userService.getAllPendingTacCreationForSystem(1, 1, 0);
			request.setAttribute("pendingrequest", list);
			List<TacUser> mlist = new LinkedList<TacUser>();
			mlist = userService.getAllPendingTacModificationForSystem(1, 1, 0);
			request.setAttribute("ModificationPendingRequest", mlist);
			List<TacUser> dlist = new LinkedList<TacUser>();
			dlist = userService.getAllPendingTacDeletionForSystem(1, 0);
			request.setAttribute("DeletionPendingRequest", dlist);
			List<TacUser> plist = new LinkedList<TacUser>();
			plist = userService.getAllPendingTacPwdForSystem(1, 0);
			request.setAttribute("PwdPendingRequest", plist);
			if (list.size() == 0 && mlist.size() == 0 && dlist.size() == 0
					&& plist.size() == 0) {
				request.setAttribute("usernopendingforsystem",

				"NO PENDING USER REQUEST FOUND..");

			}
			list = null;
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/TacSystem.jsp").forward(request, response);
		}
		if (caption.equals("IN Progress User Request")) {
			List<TacUser> list = new LinkedList<TacUser>();
			list = userService.getAllPendingTacCreationForSystem(1, 1, 3);
			List<TacUser> mlist = new LinkedList<TacUser>();
			mlist = userService.getAllPendingTacModificationForSystem(1, 1, 3);
			request.setAttribute("ModificationProgress", mlist);
			List<TacUser> dlist = new LinkedList<TacUser>();
			dlist = userService.getAllPendingTacDeletionForSystem(1, 3);
			request.setAttribute("deleteProgress", dlist);
			List<TacUser> plist = new LinkedList<TacUser>();
			plist = userService.getAllPendingTacPwdForSystem(1, 3);
			request.setAttribute("pwdProgress", plist);

			request.setAttribute("progress", list);
			System.out.println("inside progress block");
			System.out.println(list.size());
			if (list.size() == 0 && mlist.size() == 0 && dlist.size() == 0
					&& plist.size() == 0) {
				request.setAttribute("usernopendingforsystem",
						"NO IN PROGRESS USER REQUEST FOUND..");
			}
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/TacSystem.jsp").forward(request, response);
		}
		
		
		if (caption.equals("Created User List")) {
			List<TacUser> list = new LinkedList<TacUser>();
			list = userService.getAllPendingTacCreationForSystem(1, 1, 1);
			List<TacUser> mlist = new LinkedList<TacUser>();
			mlist = userService.getAllPendingTacModificationForSystem(1, 1, 1);
			request.setAttribute("mcreate", mlist);
			List<TacUser> dlist = new LinkedList<TacUser>();
			dlist = userService.getAllPendingTacDeletionForSystem(1, 1);
			request.setAttribute("dcreate", dlist);
			List<TacUser> plist = new LinkedList<TacUser>();
			plist = userService.getAllPendingTacPwdForSystem(1, 1);
			request.setAttribute("pcreate", plist);

			request.setAttribute("ccreate", list);
			System.out.println("inside progress block");
			System.out.println(list.size());
			
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/TacSystem.jsp").forward(request, response);
		}
		
		

		if (caption.equals("view detail ")) {
			System.out.println("inside Tac system  view for creation");
			TacUser user = new TacUser();
			user = userService.getUserForTacCreation(
					olmid.substring(1, olmid.length()).trim(), "tacuser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/ViewTacUserForSystem.jsp").forward(request,
					response);
		}
		if (caption.equals("view details ")) {
			System.out.println("inside Tac system  view for creation");
			TacUser user = new TacUser();
			user = userService.getUserForTacCreation(
					olmid.substring(1, olmid.length()).trim(), "tacuser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/ViewTacUserForSystem.jsp").forward(request,
					response);
		}
		if (caption.equals("view detail's ")) {
			System.out.println("inside Tac system  view for modification");
			TacUser user = new TacUser();
			user = userService.getUserForTacCreation(
					olmid.substring(1, olmid.length()).trim(), "tacmoduser");
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacModUserForSystem.jsp").forward(
					request, response);
		}
		if (caption.equals("Fetch all details ")) {
			System.out.println("inside Tac system  view for System");
			TacUser user = new TacUser();
			user = userService.getUserForTacPwdReset(olmid.substring(1,
					olmid.length()).trim());
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacUserForPwdResetSystem.jsp").forward(
					request, response);
		}
//		if (caption.equals("view details ")) {
//			System.out.println("inside Tac system  view for modification");
//			TacUser user = new TacUser();
//			user = userService.getUserForTacCreation(
//					olmid.substring(1, olmid.length()).trim(), "tacmoduser");
//			session.setAttribute("User", user);
//			getServletContext().getRequestDispatcher(
//					"/WEB-INF/jsp/viewTacModUserForSystem.jsp").forward(
//					request, response);
//		}
		if (caption.equals("Get details ")) {
			System.out.println("inside Tac system  view for deletion");
			TacUser user = new TacUser();
			user = userService.getUserForTacDeletion(olmid.substring(1,
					olmid.length()).trim());
			session.setAttribute("User", user);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/jsp/viewTacDelForSystem.jsp").forward(request,
					response);
		}

		if (caption.equals("Log Out")) {
			if (session != null) {
				String system = (String) session.getAttribute("tacsystem");
				System.out.println(session.getAttribute("tacsystem"));
				session.removeAttribute(system);
				// session.removeAttribute("user");
				// session.invalidate();

			}
			getServletContext().getRequestDispatcher("/BasicLogin.jsp")
					.forward(request, response);
		}

	}

}
