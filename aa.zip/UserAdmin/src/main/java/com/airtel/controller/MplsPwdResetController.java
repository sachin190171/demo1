package main.java.com.airtel.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.java.com.airtel.model.MplsUser;
import main.java.com.airtel.service.IUserService;
import main.java.com.airtel.service.UserService;
import main.java.com.airtel.utility.SendEmail;

@WebServlet(urlPatterns = "/MplsPwdReset")
public class MplsPwdResetController extends HttpServlet {

	IUserService userservice = new UserService();

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		System.out.println("MPLS Password reset controller called");
		MplsUser user = mapUser(request, response);
		PrintWriter out = response.getWriter();
		Random r = new Random();
		int i = r.nextInt(99999) + 100;
		String id = request.getParameter("olmid");
		String uid = id + "_" + i;
		System.out.println("token number is==>" + uid);
		
		String email= userservice.getMgrEmailId(user.getDept(), user.getOlm_id());

		boolean var = userservice.checkUidForMplsPwd(uid);

		if (var == true) {

			System.out.println("duplicate token id found");
			out.println("<html>");
			out.println("<head>");
			out.println("<script type = 'text/javascript'>");
			out.println("window.alert('Duplicate token id found')");
			out.println("setTimeout(function(){window.location.href='mplspwdreset.jsp'},10);");
			out.println("</script>");
			out.println("</head>");
			out.println("</html>");
			
			
			
		//	getServletContext().getRequestDispatcher("/mplspwdreset.jsp")
		//			.forward(request, response);
			

		} else {
			boolean flag = userservice.submitMplsPwdResetRequest(uid, user);

			if (flag == true) {
				System.out.println("Record has been updated succesfully ");
				out.println("<html>");
				out.println("<head>");
				out.println("<script type = 'text/javascript'>");
			//	out.println("window.alert('Your request has been Submitted')");
				out.println("window.alert('Your Request For MPLS Password change Has Been Accepted And Your Ticket ID Is "
						+ "  " + uid + "' )");

				out.println("setTimeout(function(){window.location.href='BasicLogin.jsp'},10);");
				out.println("</script>");
				out.println("</head>");
				out.println("</html>");
				
				String msg = "Hi<br>";
				msg += "<br><b>You have a MPLS Account Password Reset request in your bin. </b><br>";
				msg += "<br>";
				msg += "<br>Thank you";
				msg += "<br>Portal Development Team";
				msg += "<br>PH: 0124-4381378";
				SendEmail.sendMail(email, msg, user.getOlm_id());
				/*getServletContext().getRequestDispatcher("/BasicLogin.jsp")
						.forward(request, response);
*/
			} else {
				System.out.println("Request has not been inserted");
				out.println("<html>");
				out.println("<head>");
				out.println("<script type = 'text/javascript'>");
				out.println("window.alert('Your request has been Submitted')");
				out.println("setTimeout(function(){window.location.href='mplspwdreset.jsp'},10);");
				out.println("</script>");
				out.println("</head>");
				out.println("</html>");
				getServletContext().getRequestDispatcher("/mplspwdreset.jsp")
						.forward(request, response);
			}

		}

	}

	public MplsUser mapUser(HttpServletRequest request,
			HttpServletResponse response) {
		MplsUser  user = new MplsUser();
		user.setOlm_id(request.getParameter("olmid"));
		user.setRequest(request.getParameter("requestfor"));
		user.setUsType(request.getParameter("ustype"));
		user.setUsBelong(request.getParameter("u_belongs"));
		user.setPurpose(request.getParameter("purpose"));
		user.setAcReqType(request.getParameter("access"));
		user.setDept(request.getParameter("state"));
		user.setMgrname(request.getParameter("manager"));
		user.setDesig(request.getParameter("designation"));
		user.setEmail(request.getParameter("email"));
		return user;
	}

}





